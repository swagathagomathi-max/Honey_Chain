export type Role = 'ADMIN' | 'BEEKEEPER' | 'PROCESSOR' | 'QUALITY_INSPECTOR' | 'DISTRIBUTOR' | 'CUSTOMER';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  phone?: string;
  organization?: string;
  location?: string;
  avatar?: string;
  hasGiTag?: boolean;
  giTagNumber?: string;
  giTagName?: string;
  giTagCertificateUrl?: string;
  giTagVerified?: boolean;
  baseCostPerKg?: number;
  createdAt: string;
}

export type HoneyType = 'Wildflower' | 'Acacia' | 'Eucalyptus' | 'Mustard' | 'Multifloral' | 'Sidr' | 'Lavender' | 'Clover' | 'Other';

export type BatchStatus = 'HARVESTED' | 'PROCESSING' | 'PROCESSED' | 'INSPECTED_PASSED' | 'INSPECTED_FAILED' | 'PACKAGED' | 'COMPLETED';

export type QualityGrade = 'A' | 'B' | 'C';

export interface HoneyBatch {
  id: string;
  apiaryId: string;
  apiaryName: string;
  beekeeperId: string;
  beekeeperName: string;
  harvestDate: string;
  location: string;
  latitude: number;
  longitude: number;
  hiveCount: number;
  honeyType: HoneyType;
  floralSource: string;
  quantity: number;
  remainingQuantity: number;
  harvestMethod: string;
  temperature: number;
  moisturePercentage: number;
  notes: string;
  imageUrl?: string;
  hasGiTag: boolean;
  giTagName?: string;
  giTagNumber?: string;
  giTagVerified?: boolean;
  costPerKg: number;
  status: BatchStatus;
  qualityGrade?: QualityGrade;
  blockchainTxId: string;
  createdAt: string;
}

export interface ProcessingRecord {
  id: string;
  batchId: string;
  processorId: string;
  processorName: string;
  processingDate: string;
  facilityName: string;
  processingMethod: string;
  filtrationMethod: string;
  heatingTemperature: number;
  processingDurationMinutes: number;
  quantityBeforeKg: number;
  quantityAfterKg: number;
  storageContainer: string;
  storageTemperature: number;
  notes: string;
  blockchainTxId: string;
  createdAt: string;
}

export interface InspectionRecord {
  id: string;
  batchId: string;
  inspectorId: string;
  inspectorName: string;
  inspectionDate: string;
  moisturePercentage: number;
  phLevel: number;
  colorPfund: string;
  aroma: string;
  taste: string;
  purityTestResult: string;
  adulterationTestResult: string;
  microbialTestResult: string;
  qualityGrade: QualityGrade;
  inspectionResult: 'PASSED' | 'FAILED' | 'PENDING';
  certificateNumber: string;
  remarks: string;
  blockchainTxId: string;
  createdAt: string;
}

export interface Product {
  id: string;
  batchId: string;
  trackingId: string;
  productName: string;
  honeyType: string;
  floralSource: string;
  brandName: string;
  netQuantityGrams: number;
  totalUnits: number;
  packagingDate: string;
  expiryDate: string;
  packageType: string;
  mrp: number;
  qualityGrade: string;
  qrCodeUrl: string;
  harvesterName: string;
  harvesterGiVerified: boolean;
  apiaryLocation: string;
  status: 'IN_STOCK' | 'SHIPPED' | 'DELIVERED';
  blockchainTxId: string;
  createdAt: string;
}

export interface Checkpoint {
  id: string;
  timestamp: string;
  location: string;
  coordinates: [number, number]; // [lat, lng]
  status: string;
  note: string;
  temperature?: number;
}

export type TransportStatus = 'PREPARING' | 'IN_TRANSIT' | 'DELIVERED' | 'DELAYED';

export interface DistributionRecord {
  id: string;
  batchId: string;
  productId: string;
  trackingId: string;
  distributorId: string;
  distributorName: string;
  carrierName: string;
  sourceLocation: string;
  sourceCoords: [number, number];
  destinationLocation: string;
  destinationCoords: [number, number];
  transportMethod: string;
  dispatchDate: string;
  expectedDeliveryDate: string;
  actualDeliveryDate?: string;
  storageTemperature: number;
  quantityUnits: number;
  transportStatus: TransportStatus;
  notes: string;
  checkpoints: Checkpoint[];
  blockchainTxId: string;
  createdAt: string;
}

export interface BlockchainTransaction {
  id: string;
  batchId: string;
  productId?: string;
  trackingId?: string;
  action: string;
  actor: {
    id: string;
    name: string;
    role: string;
    organization?: string;
  };
  timestamp: string;
  data: Record<string, any>;
  dataHash: string;
}

export interface BlockchainBlock {
  index: number;
  timestamp: string;
  transaction: BlockchainTransaction;
  previousHash: string;
  hash: string;
  nonce: number;
  merkleRoot: string;
}

export interface NotificationItem {
  id: string;
  userId?: string;
  role?: string;
  title: string;
  message: string;
  type: 'BATCH_CREATED' | 'PROCESSING_UPDATE' | 'INSPECTION_UPDATE' | 'PRODUCT_PACKAGED' | 'DISTRIBUTION_UPDATE' | 'GI_VERIFIED' | 'BLOCKCHAIN_ALERT';
  batchId?: string;
  productId?: string;
  trackingId?: string;
  read: boolean;
  timestamp: string;
}

export interface GiCertificate {
  id: string;
  beekeeperId: string;
  beekeeperName: string;
  giName: string;
  registrationNumber: string;
  region: string;
  issuingAuthority: string;
  certificateFileUrl: string;
  validUntil: string;
  verified: boolean;
  verifiedAt?: string;
  verifiedBy?: string;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  role: string;
  action: string;
  entityType: string;
  entityId: string;
  details: string;
}

export interface DashboardMetrics {
  totalUsers: number;
  totalBeekeepers: number;
  totalBatches: number;
  totalProducts: number;
  totalBlockchainTransactions: number;
  pendingQualityInspections: number;
  deliveredBatches: number;
  verifiedProducts: number;
}

export interface DashboardCharts {
  monthlyProduction: { month: string; quantityKg: number }[];
  batchesByStatus: { status: string; count: number }[];
  productionByHoneyType: { honeyType: string; quantityKg: number }[];
  inspectionResults: {
    passed: number;
    failed: number;
    gradeA: number;
    gradeB: number;
    gradeC: number;
  };
}
