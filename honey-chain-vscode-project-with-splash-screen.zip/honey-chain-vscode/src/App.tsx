import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { NotificationProvider, useNotifications } from './context/NotificationContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { BatchProvenanceModal } from './components/BatchProvenanceModal';
import { QRCodeModal } from './components/QRCodeModal';
import { AuthPage } from './pages/AuthPage';
import { HoneyChainLogo } from './components/HoneyChainLogo';
import { AdminDashboard } from './pages/AdminDashboard';
import { BeekeeperModule } from './pages/BeekeeperModule';
import { BatchManagement } from './pages/BatchManagement';
import { ProcessingModule } from './pages/ProcessingModule';
import { InspectionModule } from './pages/InspectionModule';
import { PackagingModule } from './pages/PackagingModule';
import { DistributionModule } from './pages/DistributionModule';
import { BlockchainPage } from './pages/BlockchainPage';
import { PublicVerifyPage } from './pages/PublicVerifyPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { UserProfilePage } from './pages/UserProfilePage';
import { Product } from './types';
import { X, Bell, Sparkles } from 'lucide-react';

function AppContent() {
  const { user, isLoading } = useAuth();
  const { toasts, dismissToast } = useNotifications();
  const [showSplash, setShowSplash] = useState(true);

  // Show the Honey Chain welcome screen for five seconds on startup.
  useEffect(() => {
    const splashTimer = window.setTimeout(() => {
      setShowSplash(false);
    }, 5000);

    return () => window.clearTimeout(splashTimer);
  }, []);

  // Tab State
  const [activeTab, setActiveTab] = useState<string>('batches');
  const [verifyCode, setVerifyCode] = useState<string>('HC-PROD-9021');
  const [selectedBatchId, setSelectedBatchId] = useState<string | null>(null);
  const [selectedQrProduct, setSelectedQrProduct] = useState<Product | null>(null);
  const [targetTrackId, setTargetTrackId] = useState<string | undefined>(undefined);

  // Check URL path or hash for direct public verification (e.g. from QR code scan)
  useEffect(() => {
    const handleUrlRouting = () => {
      const path = window.location.pathname;
      const hash = window.location.hash;

      if (path.startsWith('/verify/')) {
        const code = path.replace('/verify/', '');
        if (code) {
          setVerifyCode(decodeURIComponent(code));
          setActiveTab('verify');
        }
      } else if (hash.startsWith('#verify-')) {
        const code = hash.replace('#verify-', '');
        if (code) {
          setVerifyCode(decodeURIComponent(code));
          setActiveTab('verify');
        }
      }
    };

    handleUrlRouting();
    window.addEventListener('hashchange', handleUrlRouting);
    return () => window.removeEventListener('hashchange', handleUrlRouting);
  }, []);

  // Update default tab based on logged-in role
  useEffect(() => {
    if (user && activeTab === 'batches') {
      if (user.role === 'ADMIN') setActiveTab('admin');
      else if (user.role === 'BEEKEEPER') setActiveTab('harvest');
      else if (user.role === 'PROCESSOR') setActiveTab('processing');
      else if (user.role === 'QUALITY_INSPECTOR') setActiveTab('inspection');
      else if (user.role === 'DISTRIBUTOR') setActiveTab('distribution');
    }
  }, [user]);

  if (showSplash) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center overflow-hidden bg-gradient-to-br from-[#FFFDF7] via-[#FFF4D6] to-[#FDE68A] px-6">
        <div className="relative w-full max-w-2xl text-center">
          <div className="absolute inset-0 mx-auto my-auto h-64 w-64 rounded-full bg-amber-300/30 blur-3xl" />
          <div className="relative flex flex-col items-center rounded-[2rem] border border-amber-200/80 bg-white/70 px-6 py-12 shadow-2xl shadow-amber-900/10 backdrop-blur-sm sm:px-12">
            <div className="mb-8 animate-[fadeIn_700ms_ease-out_both]">
              <HoneyChainLogo size="xl" showSubtitle={false} className="justify-center" />
            </div>
            <p className="max-w-lg text-sm font-semibold uppercase tracking-[0.18em] text-emerald-900 sm:text-base">
              Blockchain Honey Traceability
            </p>
            <h1 className="mt-4 text-2xl font-black tracking-tight text-stone-900 sm:text-4xl">
              Every Drop Has a Story
            </h1>
            <p className="mt-3 max-w-md text-sm leading-6 text-stone-600 sm:text-base">
              From hive to home, follow the journey of trusted honey.
            </p>
            <div className="mt-10 h-1.5 w-40 overflow-hidden rounded-full bg-amber-100">
              <div className="h-full w-full origin-left animate-[splashProgress_5s_linear_forwards] rounded-full bg-gradient-to-r from-amber-400 to-emerald-700" />
            </div>
            <p className="mt-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-stone-500">
              Secure • Transparent • Traceable
            </p>
          </div>
        </div>
        <style>{`
          @keyframes splashProgress {
            from { transform: scaleX(0); }
            to { transform: scaleX(1); }
          }
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px) scale(0.98); }
            to { opacity: 1; transform: translateY(0) scale(1); }
          }
        `}</style>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FFFDF7] flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs font-mono text-stone-500">Connecting to Honey Chain Blockchain Node...</p>
        </div>
      </div>
    );
  }

  // Allow unauthenticated visitors to view the public QR verification page!
  if (!user && activeTab !== 'verify') {
    return <AuthPage />;
  }

  return (
    <div className="min-h-screen bg-[#FDFBF7] flex flex-col antialiased text-stone-900 font-sans selection:bg-amber-200">
      {/* Top Navbar */}
      <Navbar
        onOpenVerify={() => {
          setActiveTab('verify');
          setVerifyCode('HC-PROD-9021');
        }}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar (shown when user is logged in, or hidden on public verification) */}
        {user && (
          <Sidebar
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            className="hidden md:flex"
          />
        )}

        {/* Main Content Viewport */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
          {activeTab === 'admin' && (
            <AdminDashboard
              onSelectBatch={(id) => setSelectedBatchId(id)}
              onOpenProductQR={(prod) => setSelectedQrProduct(prod)}
            />
          )}

          {activeTab === 'batches' && (
            <BatchManagement
              onSelectBatch={(id) => setSelectedBatchId(id)}
            />
          )}

          {activeTab === 'harvest' && (
            <BeekeeperModule
              onSelectBatch={(id) => setSelectedBatchId(id)}
            />
          )}

          {activeTab === 'processing' && (
            <ProcessingModule
              onSelectBatch={(id) => setSelectedBatchId(id)}
            />
          )}

          {activeTab === 'inspection' && (
            <InspectionModule
              onSelectBatch={(id) => setSelectedBatchId(id)}
            />
          )}

          {activeTab === 'packaging' && (
            <PackagingModule
              onOpenProductQR={(prod) => setSelectedQrProduct(prod)}
              onSelectBatch={(id) => setSelectedBatchId(id)}
              onNavigateTracking={(trkId) => {
                setTargetTrackId(trkId);
                setActiveTab('distribution');
              }}
            />
          )}

          {activeTab === 'distribution' && (
            <DistributionModule
              initialTrackId={targetTrackId}
            />
          )}

          {activeTab === 'blockchain' && (
            <BlockchainPage />
          )}

          {activeTab === 'verify' && (
            <PublicVerifyPage
              initialCode={verifyCode}
              onNavigateHome={() => setActiveTab(user ? (user.role === 'ADMIN' ? 'admin' : 'batches') : 'batches')}
            />
          )}

          {activeTab === 'notifications' && (
            <NotificationsPage
              onSelectBatch={(id) => setSelectedBatchId(id)}
              onNavigateTracking={(trkId) => {
                setTargetTrackId(trkId);
                setActiveTab('distribution');
              }}
            />
          )}

          {activeTab === 'profile' && (
            <UserProfilePage />
          )}
        </main>
      </div>

      {/* Real-time WebSocket Toasts Container */}
      <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className="pointer-events-auto bg-stone-900/95 backdrop-blur-md text-white p-4 rounded-2xl shadow-2xl border border-amber-500/30 flex items-start justify-between gap-3 animate-in slide-in-from-bottom-5 duration-200"
          >
            <div className="flex items-start gap-2.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 mt-1 animate-ping shrink-0" />
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-bold block">
                  Blockchain Live Event
                </span>
                <h5 className="font-bold text-xs text-stone-100">{toast.title}</h5>
                <p className="text-[11px] text-stone-300 mt-0.5 line-clamp-2">{toast.message}</p>
              </div>
            </div>
            <button
              onClick={() => dismissToast(toast.id)}
              className="text-stone-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>

      {/* Batch Full Provenance Modal */}
      {selectedBatchId && (
        <BatchProvenanceModal
          batchId={selectedBatchId}
          onClose={() => setSelectedBatchId(null)}
          onOpenProductQR={(prod) => setSelectedQrProduct(prod)}
        />
      )}

      {/* Product QR Code Modal */}
      {selectedQrProduct && (
        <QRCodeModal
          product={selectedQrProduct}
          onClose={() => setSelectedQrProduct(null)}
          onNavigateVerify={(prodId) => {
            setVerifyCode(prodId);
            setActiveTab('verify');
          }}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <NotificationProvider>
        <AppContent />
      </NotificationProvider>
    </AuthProvider>
  );
}
