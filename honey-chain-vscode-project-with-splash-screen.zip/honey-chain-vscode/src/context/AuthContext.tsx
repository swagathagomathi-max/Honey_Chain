import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Role } from '../types';
import { api, getStoredToken, setStoredToken, removeStoredToken } from '../services/api';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (data: Partial<User> & { password: string }) => Promise<void>;
  logout: () => void;
  updateProfile: (data: any) => Promise<User>;
  quickDemoLogin: (role: Role) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const DEMO_CREDENTIALS: Record<Role, { email: string; pass: string; title: string; subtitle: string; icon: string }> = {
  ADMIN: {
    email: 'admin@honeychain.io',
    pass: 'admin123',
    title: 'Elena Rostova',
    subtitle: 'System Administrator & Quality Board',
    icon: '👑'
  },
  BEEKEEPER: {
    email: 'beekeeper@honeychain.io',
    pass: 'beekeeper123',
    title: 'Darius Thorne',
    subtitle: 'High Alpine Harvester (GI Verified)',
    icon: '🐝'
  },
  PROCESSOR: {
    email: 'processor@honeychain.io',
    pass: 'processor123',
    title: 'Marcus Vance',
    subtitle: 'Cold-Extraction Processing Plant',
    icon: '⚙️'
  },
  QUALITY_INSPECTOR: {
    email: 'inspector@honeychain.io',
    pass: 'inspector123',
    title: 'Dr. Aris Thorne',
    subtitle: 'ISO 17025 Certified Melissopalynologist',
    icon: '🔬'
  },
  DISTRIBUTOR: {
    email: 'distributor@honeychain.io',
    pass: 'distributor123',
    title: 'Kaelen Vance',
    subtitle: 'Cold-Chain IoT Logistics Director',
    icon: '🚚'
  },
  CUSTOMER: {
    email: 'customer@honeychain.io',
    pass: 'customer123',
    title: 'Sophia Chen',
    subtitle: 'Verified Honey Connoisseur & Buyer',
    icon: '🍯'
  }
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(getStoredToken());
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchUser = async () => {
      const stored = getStoredToken();
      if (!stored) {
        setIsLoading(false);
        return;
      }
      try {
        const userData = await api.getMe();
        setUser(userData);
      } catch (err) {
        console.warn('Failed to restore session:', err);
        removeStoredToken();
        setToken(null);
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    };

    fetchUser();
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      const res = await api.login({ email, password });
      setStoredToken(res.token);
      setToken(res.token);
      setUser(res.user);
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (data: Partial<User> & { password: string }) => {
    setIsLoading(true);
    try {
      const res = await api.register(data);
      setStoredToken(res.token);
      setToken(res.token);
      setUser(res.user);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    removeStoredToken();
    setToken(null);
    setUser(null);
  };

  const updateProfile = async (data: any): Promise<User> => {
    const updated = await api.updateProfile(data);
    setUser(updated);
    return updated;
  };

  const quickDemoLogin = async (role: Role) => {
    const cred = DEMO_CREDENTIALS[role];
    if (cred) {
      await login(cred.email, cred.pass);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isLoading,
        login,
        register,
        logout,
        updateProfile,
        quickDemoLogin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
