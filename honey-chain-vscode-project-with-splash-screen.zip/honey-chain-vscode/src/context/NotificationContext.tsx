import React, { createContext, useContext, useState, useEffect } from 'react';
import { NotificationItem } from '../types';
import { api } from '../services/api';
import { wsClient } from '../services/websocket';

interface ToastItem {
  id: string;
  title: string;
  message: string;
  type: string;
  timestamp: string;
}

interface NotificationContextType {
  notifications: NotificationItem[];
  unreadCount: number;
  isLoading: boolean;
  toasts: ToastItem[];
  markAsRead: (id: string) => Promise<void>;
  markAllAsRead: () => Promise<void>;
  dismissToast: (id: string) => void;
  refreshNotifications: () => Promise<void>;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const refreshNotifications = async () => {
    try {
      const items = await api.getNotifications();
      setNotifications(items);
      const unread = items.filter(n => !n.read).length;
      setUnreadCount(unread);
    } catch (err) {
      console.warn('Could not fetch notifications:', err);
    }
  };

  useEffect(() => {
    refreshNotifications();

    // Connect to WebSocket
    wsClient.connect();

    // Subscribe to WS events
    const unsubscribe = wsClient.subscribe((event) => {
      if (event.type === 'NEW_NOTIFICATION') {
        const notif: NotificationItem = event.payload;
        setNotifications((prev) => [notif, ...prev]);
        setUnreadCount((prev) => prev + 1);

        // Show live toast
        const newToast: ToastItem = {
          id: `toast-${Date.now()}-${Math.random()}`,
          title: notif.title,
          message: notif.message,
          type: notif.type,
          timestamp: notif.timestamp,
        };

        setToasts((prev) => [newToast, ...prev.slice(0, 4)]);

        // Auto dismiss after 6 seconds
        setTimeout(() => {
          dismissToast(newToast.id);
        }, 6000);
      }
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const markAsRead = async (id: string) => {
    try {
      await api.markNotificationAsRead(id);
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, read: true } : n))
      );
      setUnreadCount((prev) => Math.max(0, prev - 1));
    } catch (err) {
      console.error('Failed to mark notification read:', err);
    }
  };

  const markAllAsRead = async () => {
    try {
      await api.markAllNotificationsAsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
      setUnreadCount(0);
    } catch (err) {
      console.error('Failed to mark all read:', err);
    }
  };

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        isLoading,
        toasts,
        markAsRead,
        markAllAsRead,
        dismissToast,
        refreshNotifications,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};
