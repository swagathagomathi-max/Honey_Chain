import React from 'react';
import { Product } from '../types';
import { X, Download, ExternalLink, Printer, ShieldCheck } from 'lucide-react';

interface QRCodeModalProps {
  product: Product;
  onClose: () => void;
  onNavigateVerify: (id: string) => void;
}

export const QRCodeModal: React.FC<QRCodeModalProps> = ({ product, onClose, onNavigateVerify }) => {
  const downloadQR = () => {
    const link = document.createElement('a');
    link.download = `HONEY-CHAIN-QR-${product.id}.png`;
    link.href = product.qrCodeUrl;
    link.click();
  };

  const printLabel = () => {
    const printWindow = window.open('', '', 'width=600,height=700');
    if (!printWindow) return;
    printWindow.document.write(`
      <html>
        <head>
          <title>Honey Chain Product Label - ${product.id}</title>
          <style>
            body { font-family: sans-serif; text-align: center; padding: 20px; }
            .label { border: 2px dashed #f59e0b; padding: 20px; border-radius: 12px; max-width: 380px; margin: auto; }
            h2 { color: #b45309; margin-bottom: 4px; }
            p { font-size: 13px; color: #4b5563; margin: 4px 0; }
            img { width: 220px; height: 220px; margin: 15px 0; }
            .badge { display: inline-block; background: #ecfdf5; color: #047857; font-weight: bold; padding: 4px 10px; border-radius: 20px; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="label">
            <h2>${product.brandName}</h2>
            <p><strong>${product.productName}</strong></p>
            <p>Type: ${product.honeyType} | Net: ${product.netQuantityGrams}g</p>
            <div class="badge">Grade ${product.qualityGrade} • Blockchain Verified</div>
            <br/>
            <img src="${product.qrCodeUrl}" alt="Honey Chain QR" />
            <p style="font-family: monospace; font-size: 12px;">TRACK ID: ${product.trackingId}</p>
            <p style="font-size: 11px; color: #9ca3af;">Scan with phone camera to view farm-to-table blockchain journey</p>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
    }, 250);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-md w-full border border-stone-200 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-amber-500 to-amber-600 text-stone-950 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-stone-950" />
            <h3 className="font-bold text-sm font-['Outfit']">Public Traceability QR Code</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-amber-600 text-stone-950 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 text-center space-y-4">
          <div>
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-700 bg-amber-100 px-2.5 py-0.5 rounded-full">
              Product ID: {product.id}
            </span>
            <h4 className="text-lg font-bold text-stone-900 mt-2 font-['Outfit']">
              {product.productName}
            </h4>
            <p className="text-xs text-stone-500">
              {product.brandName} • {product.netQuantityGrams}g • Grade {product.qualityGrade}
            </p>
          </div>

          {/* QR Code Container */}
          <div className="relative inline-block p-4 rounded-2xl bg-amber-50 border-2 border-amber-200 shadow-inner">
            <img
              src={product.qrCodeUrl}
              alt="Honey Chain Product QR Code"
              className="w-56 h-56 mx-auto rounded-xl shadow-sm"
            />
            <div className="mt-2 text-[11px] font-mono text-stone-600 font-semibold">
              Track ID: <span className="text-amber-800">{product.trackingId}</span>
            </div>
          </div>

          <p className="text-xs text-stone-600 max-w-xs mx-auto">
            Customers can scan this QR code with any smartphone to verify the apiary, beekeeper GI certificate, lab tests, and blockchain history.
          </p>

          {/* Actions */}
          <div className="flex items-center justify-center gap-2 pt-2">
            <button
              onClick={downloadQR}
              className="flex items-center gap-1.5 px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-semibold transition-colors"
            >
              <Download className="w-4 h-4 text-stone-600" />
              Download PNG
            </button>

            <button
              onClick={printLabel}
              className="flex items-center gap-1.5 px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-semibold transition-colors"
            >
              <Printer className="w-4 h-4 text-stone-600" />
              Print Jar Label
            </button>

            <button
              onClick={() => {
                onClose();
                onNavigateVerify(product.id);
              }}
              className="flex items-center gap-1.5 px-3 py-2 bg-amber-500 hover:bg-amber-600 text-stone-950 rounded-xl text-xs font-bold transition-colors shadow-sm"
            >
              <ExternalLink className="w-4 h-4" />
              Test Verify
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
