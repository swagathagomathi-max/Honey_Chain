import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
}

export const HoneyChainLogo: React.FC<LogoProps> = ({
  className = '',
  size = 'md',
  showSubtitle = true,
}) => {
  const dimensionMap = {
    sm: { box: 36, titleSize: 'text-base', subSize: 'text-[9px]' },
    md: { box: 44, titleSize: 'text-xl', subSize: 'text-[11px]' },
    lg: { box: 64, titleSize: 'text-2xl', subSize: 'text-xs' },
    xl: { box: 88, titleSize: 'text-3xl', subSize: 'text-sm' },
  };

  const current = dimensionMap[size];

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Visual Emblem styled after the Honey Chain Badge */}
      <div
        className="relative shrink-0 rounded-2xl p-1 bg-gradient-to-b from-amber-300 via-amber-500 to-amber-700 shadow-md shadow-amber-900/20"
        style={{ width: current.box, height: current.box }}
      >
        <div className="w-full h-full rounded-[14px] bg-gradient-to-b from-[#0b3b24] via-[#052e1b] to-[#021b10] flex items-center justify-center overflow-hidden relative border border-amber-300/40">
          {/* Honeycomb background pattern */}
          <div className="absolute inset-0 opacity-20 pointer-events-none bg-[radial-gradient(#f59e0b_1px,transparent_1px)] [background-size:6px_6px]" />

          <svg
            viewBox="0 0 100 100"
            className="w-full h-full relative z-10 drop-shadow"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Blockchain glowing circuit ring */}
            <circle cx="50" cy="50" r="38" stroke="#F59E0B" strokeWidth="1.5" strokeDasharray="3 3" opacity="0.7" />

            {/* Blockchain cubes with lock symbols */}
            {/* Top Cube */}
            <rect x="44" y="8" width="12" height="12" rx="2.5" fill="#F59E0B" stroke="#FEF3C7" strokeWidth="1" />
            <path d="M48 14h4v3h-4z M49 14v-2a1 1 0 012 0v2" stroke="#78350F" strokeWidth="0.8" fill="none" />

            {/* Left Top Cube */}
            <rect x="14" y="24" width="11" height="11" rx="2.5" fill="#F59E0B" stroke="#FEF3C7" strokeWidth="1" />
            <path d="M18 29h3v3h-3z M18.5 29v-1.5a1 1 0 012 0v1.5" stroke="#78350F" strokeWidth="0.8" fill="none" />

            {/* Right Top Cube */}
            <rect x="75" y="24" width="11" height="11" rx="2.5" fill="#F59E0B" stroke="#FEF3C7" strokeWidth="1" />
            <path d="M79 29h3v3h-3z M79.5 29v-1.5a1 1 0 012 0v1.5" stroke="#78350F" strokeWidth="0.8" fill="none" />

            {/* Left Bottom Cube */}
            <rect x="14" y="65" width="11" height="11" rx="2.5" fill="#F59E0B" stroke="#FEF3C7" strokeWidth="1" />
            <path d="M18 70h3v3h-3z M18.5 70v-1.5a1 1 0 012 0v1.5" stroke="#78350F" strokeWidth="0.8" fill="none" />

            {/* Right Bottom Cube */}
            <rect x="75" y="65" width="11" height="11" rx="2.5" fill="#F59E0B" stroke="#FEF3C7" strokeWidth="1" />
            <path d="M79 70h3v3h-3z M79.5 70v-1.5a1 1 0 012 0v1.5" stroke="#78350F" strokeWidth="0.8" fill="none" />

            {/* Connecting Circuit Lines */}
            <line x1="50" y1="20" x2="50" y2="30" stroke="#FBBF24" strokeWidth="1.2" />
            <line x1="25" y1="30" x2="35" y2="38" stroke="#FBBF24" strokeWidth="1.2" />
            <line x1="75" y1="30" x2="65" y2="38" stroke="#FBBF24" strokeWidth="1.2" />
            <line x1="25" y1="70" x2="35" y2="62" stroke="#FBBF24" strokeWidth="1.2" />
            <line x1="75" y1="70" x2="65" y2="62" stroke="#FBBF24" strokeWidth="1.2" />

            {/* Central Honeycomb Frame */}
            <polygon
              points="50,30 68,40 68,60 50,70 32,60 32,40"
              fill="rgba(245, 158, 11, 0.15)"
              stroke="#FBBF24"
              strokeWidth="2"
            />

            {/* Amber Honey Jar */}
            <path
              d="M38 48 C38 42, 62 42, 62 48 C62 58, 59 64, 50 64 C41 64, 38 58, 38 48 Z"
              fill="url(#honeyJarGrad)"
            />
            {/* Honey Jar Cloth Cap & String */}
            <ellipse cx="50" cy="45" rx="10" ry="3.5" fill="#FDE68A" stroke="#B45309" strokeWidth="0.8" />
            <line x1="42" y1="46" x2="58" y2="46" stroke="#92400E" strokeWidth="1" strokeDasharray="1 1" />

            {/* Wooden Honey Dipper */}
            <line x1="58" y1="32" x2="49" y2="47" stroke="#D97706" strokeWidth="2.5" strokeLinecap="round" />
            <ellipse cx="49" cy="47" rx="3.5" ry="2.5" fill="#F59E0B" />
            {/* Dripping Honey */}
            <circle cx="50" cy="54" r="2.2" fill="#F59E0B" />
            <path d="M50 56 Q50 60 51 61 Q52 60 52 56 Z" fill="#F59E0B" />

            {/* Worker Bee */}
            <g transform="translate(30, 30) scale(0.65)">
              {/* Wings */}
              <ellipse cx="6" cy="2" rx="4" ry="7" transform="rotate(-30 6 2)" fill="#BAE6FD" opacity="0.85" />
              <ellipse cx="14" cy="1" rx="4" ry="7" transform="rotate(30 14 1)" fill="#BAE6FD" opacity="0.85" />
              {/* Body */}
              <ellipse cx="10" cy="8" rx="4.5" ry="6.5" fill="#F59E0B" />
              {/* Stripes */}
              <path d="M6 7h8 M6 9h8 M7 11h6" stroke="#1F2937" strokeWidth="1.2" strokeLinecap="round" />
              {/* Head */}
              <circle cx="10" cy="2.5" r="2.5" fill="#1F2937" />
              {/* Antennae */}
              <path d="M9 1L7 -1 M11 1L13 -1" stroke="#1F2937" strokeWidth="0.7" />
            </g>

            {/* Jasmine Flower Accent */}
            <circle cx="63" cy="57" r="2" fill="#FBBF24" />
            <ellipse cx="63" cy="54" rx="1.5" ry="2.5" fill="#FFFFFF" opacity="0.9" />
            <ellipse cx="63" cy="60" rx="1.5" ry="2.5" fill="#FFFFFF" opacity="0.9" />
            <ellipse cx="60" cy="57" rx="2.5" ry="1.5" fill="#FFFFFF" opacity="0.9" />
            <ellipse cx="66" cy="57" rx="2.5" ry="1.5" fill="#FFFFFF" opacity="0.9" />

            <defs>
              <linearGradient id="honeyJarGrad" x1="50" y1="42" x2="50" y2="64" gradientUnits="userSpaceOnUse">
                <stop stopColor="#FBBF24" />
                <stop offset="0.6" stopColor="#D97706" />
                <stop offset="1" stopColor="#B45309" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>

      {/* Brand Typography */}
      <div>
        <div className="flex items-center gap-1.5">
          <span className={`font-black tracking-tight font-['Outfit'] text-amber-500 drop-shadow-sm ${current.titleSize}`}>
            Honey
          </span>
          <span className={`font-black tracking-tight font-['Outfit'] text-stone-900 ${current.titleSize}`}>
            Chain
          </span>
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse ml-0.5" title="Decentralized Network Active" />
        </div>
        {showSubtitle && (
          <div className="flex items-center gap-1.5 text-stone-500 font-medium tracking-wide">
            <span className="w-2.5 h-[1.5px] bg-amber-400" />
            <span className={`italic font-['Outfit'] ${current.subSize} text-amber-800/80`}>
              Every Drop Has a Story
            </span>
            <span className="w-2.5 h-[1.5px] bg-amber-400" />
          </div>
        )}
      </div>
    </div>
  );
};
