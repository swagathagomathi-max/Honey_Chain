import React, { useState, useEffect } from 'react';
import { HoneyBatch, ProcessingRecord, InspectionRecord, Product, DistributionRecord, BlockchainBlock } from '../types';
import { api } from '../services/api';
import {
  X,
  ShieldCheck,
  CheckCircle2,
  Calendar,
  MapPin,
  Thermometer,
  Droplets,
  Layers,
  Cpu,
  FileCheck2,
  Package,
  Truck,
  Link as LinkIcon,
  Award,
  Hash
} from 'lucide-react';

interface BatchProvenanceModalProps {
  batchId: string;
  onClose: () => void;
  onOpenProductQR?: (product: Product) => void;
}

export const BatchProvenanceModal: React.FC<BatchProvenanceModalProps> = ({
  batchId,
  onClose,
  onOpenProductQR
}) => {
  const [data, setData] = useState<{
    batch: HoneyBatch;
    processingRecords: ProcessingRecord[];
    inspectionRecords: InspectionRecord[];
    products: Product[];
    distributionRecords: DistributionRecord[];
    blockchainBlocks: BlockchainBlock[];
  } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDetails = async () => {
      try {
        const res = await api.getBatchDetails(batchId);
        setData(res);
      } catch (err) {
        console.error('Failed to load batch history:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchDetails();
  }, [batchId]);

  if (loading) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-sm">
        <div className="bg-white p-8 rounded-3xl text-center space-y-3">
          <div className="w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs font-mono text-stone-600">Querying Blockchain Ledger & Lineage...</p>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-sm">
        <div className="bg-white p-6 rounded-2xl text-center space-y-3 max-w-sm">
          <p className="text-sm text-stone-800">Batch history not found.</p>
          <button onClick={onClose} className="px-4 py-2 bg-stone-100 rounded-xl text-xs font-semibold">
            Close
          </button>
        </div>
      </div>
    );
  }

  const { batch, processingRecords, inspectionRecords, products, distributionRecords, blockchainBlocks } = data;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full border border-stone-200 shadow-2xl my-8 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-5 bg-gradient-to-r from-stone-900 via-stone-800 to-stone-900 text-white flex items-center justify-between border-b border-stone-700">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-bold bg-amber-950/80 px-2 py-0.5 rounded-full border border-amber-600/40">
                Blockchain Provenance Record
              </span>
              <span className="text-xs font-mono text-stone-400">
                {blockchainBlocks.length} Blocks Verified
              </span>
            </div>
            <h2 className="text-lg font-bold font-['Outfit'] text-stone-100 mt-1 flex items-center gap-2">
              Batch: <span className="text-amber-400 font-mono">{batch.id}</span>
              {batch.hasGiTag && (
                <span className="px-2 py-0.5 text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-500/40 rounded-full font-sans font-semibold flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  GI Verified Origin
                </span>
              )}
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-stone-700 text-stone-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body - Scrollable */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Quick Summary Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 rounded-2xl bg-amber-50/70 border border-amber-200">
              <span className="text-[10px] uppercase font-mono text-amber-700 font-bold block">Honey Type</span>
              <span className="text-sm font-bold text-stone-900 font-['Outfit']">{batch.honeyType}</span>
              <span className="text-[11px] text-stone-500 block truncate">{batch.floralSource}</span>
            </div>
            <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200">
              <span className="text-[10px] uppercase font-mono text-stone-500 font-bold block">Total Harvest</span>
              <span className="text-sm font-bold text-stone-900 font-['Outfit']">{batch.quantity} kg</span>
              <span className="text-[11px] text-stone-500 block">{batch.hiveCount} Hives</span>
            </div>
            <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200">
              <span className="text-[10px] uppercase font-mono text-stone-500 font-bold block">Moisture & Temp</span>
              <span className="text-sm font-bold text-stone-900 font-['Outfit']">{batch.moisturePercentage}% Moisture</span>
              <span className="text-[11px] text-stone-500 block">{batch.temperature}°C at harvest</span>
            </div>
            <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200">
              <span className="text-[10px] uppercase font-mono text-stone-500 font-bold block">Current Status</span>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full inline-block mt-0.5">
                {batch.status.replace('_', ' ')}
              </span>
              {batch.qualityGrade && (
                <span className="text-[11px] text-stone-600 block mt-0.5">Grade {batch.qualityGrade}</span>
              )}
            </div>
          </div>

          {/* Harvester & Apiary Card */}
          <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-700 flex items-center justify-center font-bold text-lg border border-amber-300">
                🐝
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-sm text-stone-900">{batch.beekeeperName}</h4>
                  <span className="text-[11px] text-stone-500 font-mono">({batch.apiaryName})</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-stone-600 mt-0.5">
                  <MapPin className="w-3.5 h-3.5 text-stone-400" />
                  <span>{batch.location}</span>
                  <span className="font-mono text-[11px] text-stone-400">
                    [{batch.latitude.toFixed(4)}, {batch.longitude.toFixed(4)}]
                  </span>
                </div>
              </div>
            </div>

            {batch.hasGiTag && (
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs">
                <div className="flex items-center gap-1.5 font-bold text-emerald-800">
                  <Award className="w-4 h-4 text-emerald-600" />
                  <span>{batch.giTagName}</span>
                </div>
                <span className="text-[10px] font-mono text-emerald-600 block">
                  Reg No: {batch.giTagNumber}
                </span>
              </div>
            )}
          </div>

          {/* Lifecycle Milestones Timeline */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500 font-mono mb-3">
              Supply Chain Lifecycle Timeline
            </h4>

            <div className="space-y-4 relative before:absolute before:inset-0 before:left-4 before:w-0.5 before:bg-stone-200">
              {/* Step 1: Harvest */}
              <div className="relative pl-10">
                <div className="absolute left-2 top-0.5 w-5 h-5 rounded-full bg-amber-500 text-white flex items-center justify-center text-xs shadow">
                  ✓
                </div>
                <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className="text-amber-700 font-mono">STAGE 1: HARVEST RECORDED</span>
                    <span className="text-stone-400 font-mono">{batch.harvestDate}</span>
                  </div>
                  <p className="text-xs text-stone-700 mt-1">
                    Extracted {batch.quantity}kg of {batch.honeyType} using {batch.harvestMethod}.
                  </p>
                  {batch.notes && (
                    <p className="text-xs text-stone-500 italic mt-1 bg-stone-50 p-2 rounded-lg">
                      "{batch.notes}"
                    </p>
                  )}
                </div>
              </div>

              {/* Step 2: Processing */}
              {processingRecords.map((p) => (
                <div key={p.id} className="relative pl-10">
                  <div className="absolute left-2 top-0.5 w-5 h-5 rounded-full bg-purple-600 text-white flex items-center justify-center text-xs shadow">
                    ✓
                  </div>
                  <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm">
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span className="text-purple-700 font-mono">STAGE 2: COLD-EXTRACTION PROCESSING</span>
                      <span className="text-stone-400 font-mono">{p.processingDate}</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2 text-xs">
                      <div>
                        <span className="text-[10px] text-stone-400 block">Facility</span>
                        <span className="font-semibold text-stone-800">{p.facilityName}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-stone-400 block">Heating Temp</span>
                        <span className="font-semibold text-stone-800">{p.heatingTemperature}°C (Gentle)</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-stone-400 block">Yield</span>
                        <span className="font-semibold text-stone-800">{p.quantityAfterKg}kg ({p.quantityBeforeKg}kg before)</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-stone-400 block">Processor</span>
                        <span className="font-semibold text-stone-800">{p.processorName}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {/* Step 3: Quality Inspection */}
              {inspectionRecords.map((i) => (
                <div key={i.id} className="relative pl-10">
                  <div className={`absolute left-2 top-0.5 w-5 h-5 rounded-full flex items-center justify-center text-xs shadow text-white ${
                    i.inspectionResult === 'PASSED' ? 'bg-emerald-600' : 'bg-rose-600'
                  }`}>
                    ✓
                  </div>
                  <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm">
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span className="text-emerald-700 font-mono">
                        STAGE 3: LAB QUALITY INSPECTION ({i.inspectionResult} - GRADE {i.qualityGrade})
                      </span>
                      <span className="text-stone-400 font-mono">{i.inspectionDate}</span>
                    </div>
                    <div className="mt-2 text-xs space-y-1.5">
                      <div className="flex items-center justify-between p-2 rounded-lg bg-emerald-50 text-emerald-900 border border-emerald-200">
                        <span className="font-semibold font-mono text-[11px]">Cert: {i.certificateNumber}</span>
                        <span className="font-bold">Inspector: {i.inspectorName}</span>
                      </div>
                      <div className="grid grid-cols-3 gap-2 text-xs text-stone-700 pt-1">
                        <div>Moisture: <strong>{i.moisturePercentage}%</strong></div>
                        <div>pH Level: <strong>{i.phLevel}</strong></div>
                        <div>Color: <strong>{i.colorPfund}</strong></div>
                      </div>
                      <p className="text-[11px] text-stone-600">
                        <strong>Purity Analysis:</strong> {i.purityTestResult}
                      </p>
                    </div>
                  </div>
                </div>
              ))}

              {/* Step 4: Packaging & Products */}
              {products.map((prod) => (
                <div key={prod.id} className="relative pl-10">
                  <div className="absolute left-2 top-0.5 w-5 h-5 rounded-full bg-amber-600 text-white flex items-center justify-center text-xs shadow">
                    ✓
                  </div>
                  <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm flex items-center justify-between gap-4">
                    <div>
                      <div className="text-xs font-semibold text-amber-800 font-mono">
                        STAGE 4: PACKAGED PRODUCT MINTED
                      </div>
                      <h5 className="font-bold text-sm text-stone-900 mt-0.5">{prod.productName}</h5>
                      <p className="text-xs text-stone-500">
                        {prod.totalUnits} Units • {prod.netQuantityGrams}g • MRP: ${prod.mrp.toFixed(2)} • Track ID: <span className="font-mono text-stone-800 font-semibold">{prod.trackingId}</span>
                      </p>
                    </div>

                    {onOpenProductQR && (
                      <button
                        onClick={() => onOpenProductQR(prod)}
                        className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-bold rounded-xl border border-amber-200 shrink-0"
                      >
                        View QR Code
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Cryptographic Blockchain Ledger Ledger Proof */}
          <div className="p-4 rounded-2xl bg-stone-900 text-stone-200 border border-stone-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <LinkIcon className="w-4 h-4 text-amber-400" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 font-mono">
                  SHA-256 Blockchain Lineage
                </h4>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-full border border-emerald-800">
                Cryptographically Immutable
              </span>
            </div>

            <div className="space-y-2">
              {blockchainBlocks.map((b) => (
                <div key={b.index} className="p-3 rounded-xl bg-stone-950/70 border border-stone-800 text-xs font-mono">
                  <div className="flex items-center justify-between text-stone-400 text-[11px]">
                    <span className="text-amber-300 font-bold">Block #{b.index}</span>
                    <span>{b.transaction.action}</span>
                    <span>{new Date(b.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                  <div className="mt-1 text-[10px] text-stone-400 truncate">
                    Hash: <span className="text-emerald-400">{b.hash}</span>
                  </div>
                  <div className="text-[10px] text-stone-500 truncate">
                    Prev: {b.previousHash}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-stone-100 border-t border-stone-200 text-right">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-stone-800 hover:bg-stone-900 text-white text-xs font-bold rounded-xl transition-colors"
          >
            Close Provenance Viewer
          </button>
        </div>
      </div>
    </div>
  );
};
