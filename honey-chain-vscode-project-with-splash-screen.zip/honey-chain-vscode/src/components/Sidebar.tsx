import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import {
  LayoutDashboard,
  Layers,
  Sprout,
  Cpu,
  ShieldCheck,
  PackageCheck,
  Truck,
  Link as LinkIcon,
  QrCode,
  Bell,
  UserCheck,
  FileText
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  className?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, className = '' }) => {
  const { user } = useAuth();
  const { unreadCount } = useNotifications();

  // Navigation Items with role guards
  const navItems = [
    {
      id: 'admin',
      label: 'Admin Dashboard',
      icon: LayoutDashboard,
      roles: ['ADMIN'],
      badge: 'Control',
    },
    {
      id: 'batches',
      label: 'Honey Batches',
      icon: Layers,
      roles: ['ADMIN', 'BEEKEEPER', 'PROCESSOR', 'QUALITY_INSPECTOR', 'DISTRIBUTOR', 'CUSTOMER'],
    },
    {
      id: 'harvest',
      label: 'Harvest Module',
      icon: Sprout,
      roles: ['ADMIN', 'BEEKEEPER'],
      badge: user?.role === 'BEEKEEPER' ? 'Harvester' : undefined,
    },
    {
      id: 'processing',
      label: 'Processing Module',
      icon: Cpu,
      roles: ['ADMIN', 'PROCESSOR'],
    },
    {
      id: 'inspection',
      label: 'Quality Inspection',
      icon: ShieldCheck,
      roles: ['ADMIN', 'QUALITY_INSPECTOR'],
    },
    {
      id: 'packaging',
      label: 'Packaging & Products',
      icon: PackageCheck,
      roles: ['ADMIN', 'PROCESSOR'],
    },
    {
      id: 'distribution',
      label: 'Distribution Tracking',
      icon: Truck,
      roles: ['ADMIN', 'DISTRIBUTOR', 'CUSTOMER'],
    },
    {
      id: 'blockchain',
      label: 'Blockchain Ledger',
      icon: LinkIcon,
      roles: ['ADMIN', 'BEEKEEPER', 'PROCESSOR', 'QUALITY_INSPECTOR', 'DISTRIBUTOR', 'CUSTOMER'],
    },
    {
      id: 'verify',
      label: 'QR Verification',
      icon: QrCode,
      roles: ['ADMIN', 'BEEKEEPER', 'PROCESSOR', 'QUALITY_INSPECTOR', 'DISTRIBUTOR', 'CUSTOMER'],
    },
    {
      id: 'notifications',
      label: 'Notification Center',
      icon: Bell,
      roles: ['ADMIN', 'BEEKEEPER', 'PROCESSOR', 'QUALITY_INSPECTOR', 'DISTRIBUTOR', 'CUSTOMER'],
      count: unreadCount,
    },
    {
      id: 'profile',
      label: 'Harvester GI Profile',
      icon: UserCheck,
      roles: ['ADMIN', 'BEEKEEPER', 'PROCESSOR', 'QUALITY_INSPECTOR', 'DISTRIBUTOR', 'CUSTOMER'],
    },
  ];

  const visibleItems = navItems.filter((item) =>
    user ? item.roles.includes(user.role) : true
  );

  return (
    <aside className={`w-64 bg-stone-900 text-stone-200 border-r border-stone-800 flex flex-col justify-between shrink-0 ${className}`}>
      <div className="p-4 space-y-6">
        <div>
          <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400 font-mono px-3">
            Navigation Menu
          </span>
          <nav className="mt-2 space-y-1">
            {visibleItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20'
                      : 'text-stone-300 hover:text-white hover:bg-stone-800/80'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-stone-950' : 'text-amber-400'}`} />
                    <span>{item.label}</span>
                  </div>

                  {item.badge && (
                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded-md font-mono font-bold uppercase ${
                        isActive ? 'bg-stone-950 text-amber-400' : 'bg-stone-800 text-amber-300'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}

                  {item.count !== undefined && item.count > 0 && (
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                        isActive ? 'bg-stone-950 text-rose-300' : 'bg-rose-500 text-white'
                      }`}
                    >
                      {item.count}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Honey Chain Node Footer */}
      <div className="p-4 border-t border-stone-800 bg-stone-950/60">
        <div className="p-3 rounded-xl bg-stone-900/90 border border-stone-800/80 text-xs">
          <div className="flex items-center justify-between mb-1">
            <span className="font-mono text-[10px] text-amber-400 uppercase font-bold">SHA-256 Ledger</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
          </div>
          <p className="text-[11px] text-stone-400 leading-tight">
            Honey provenance secured with cryptographic hashing & local consensus.
          </p>
        </div>
      </div>
    </aside>
  );
};
