import React, { useState } from 'react';
import { HoneyChainLogo } from './HoneyChainLogo';
import { useAuth, DEMO_CREDENTIALS } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { Role } from '../types';
import {
  Bell,
  Search,
  ShieldCheck,
  CheckCircle,
  LogOut,
  User as UserIcon,
  Wifi,
  ChevronDown,
  QrCode,
  Sparkles,
  ExternalLink
} from 'lucide-react';

interface NavbarProps {
  onOpenVerify: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenVerify, activeTab, setActiveTab }) => {
  const { user, logout, quickDemoLogin } = useAuth();
  const { notifications, unreadCount, markAsRead, markAllAsRead } = useNotifications();
  const [showNotifMenu, setShowNotifMenu] = useState(false);
  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [searchCode, setSearchCode] = useState('');

  const handleQuickSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchCode.trim()) return;
    setActiveTab('verify');
    window.location.hash = `verify-${encodeURIComponent(searchCode.trim())}`;
    setSearchCode('');
  };

  const roleColors: Record<Role, { bg: string; text: string; border: string }> = {
    ADMIN: { bg: 'bg-rose-50', text: 'text-rose-700', border: 'border-rose-200' },
    BEEKEEPER: { bg: 'bg-amber-50', text: 'text-amber-800', border: 'border-amber-200' },
    PROCESSOR: { bg: 'bg-purple-50', text: 'text-purple-800', border: 'border-purple-200' },
    QUALITY_INSPECTOR: { bg: 'bg-emerald-50', text: 'text-emerald-800', border: 'border-emerald-200' },
    DISTRIBUTOR: { bg: 'bg-blue-50', text: 'text-blue-800', border: 'border-blue-200' },
    CUSTOMER: { bg: 'bg-stone-100', text: 'text-stone-800', border: 'border-stone-300' },
  };

  const currentRoleStyle = user?.role
    ? roleColors[user.role]
    : { bg: 'bg-stone-100', text: 'text-stone-800', border: 'border-stone-200' };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200 shadow-[0_2px_10px_rgba(0,0,0,0.03)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center gap-6">
          <button
            onClick={() => setActiveTab(user?.role === 'ADMIN' ? 'admin' : 'batches')}
            className="text-left focus:outline-none"
          >
            <HoneyChainLogo size="sm" showSubtitle={true} />
          </button>

          {/* Quick Search for batch/product/tracking code */}
          <form onSubmit={handleQuickSearch} className="hidden md:flex items-center relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 pointer-events-none" />
            <input
              type="text"
              placeholder="Verify Batch / Product / Tracking ID..."
              value={searchCode}
              onChange={(e) => setSearchCode(e.target.value)}
              className="pl-9 pr-20 py-1.5 text-xs bg-stone-100/80 hover:bg-stone-100 focus:bg-white border border-stone-200 focus:border-amber-400 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-400/20 w-64 lg:w-80 transition-all font-mono placeholder:font-sans placeholder:text-stone-400"
            />
            <button
              type="submit"
              className="absolute right-1.5 px-2 py-0.5 bg-amber-500 hover:bg-amber-600 text-stone-950 font-semibold text-[11px] rounded-lg transition-colors"
            >
              Verify
            </button>
          </form>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-3">
          {/* Quick QR Scanner / Lookup Button */}
          <button
            onClick={onOpenVerify}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 text-xs font-bold transition-all shadow-sm shadow-amber-500/20 active:scale-95"
            title="Scan or Verify Honey QR Code"
          >
            <QrCode className="w-4 h-4" />
            <span className="hidden sm:inline">Verify Product</span>
          </button>

          {/* Harvester GI Verified Tag Badge in Navbar */}
          {user?.hasGiTag && (
            <div
              className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-semibold border ${
                user.giTagVerified
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                  : 'bg-amber-50 text-amber-800 border-amber-200'
              }`}
              title={user.giTagVerified ? `GI Certified Origin: ${user.giTagName}` : 'GI Tag Pending Verification'}
            >
              <ShieldCheck className={`w-3.5 h-3.5 ${user.giTagVerified ? 'text-emerald-600' : 'text-amber-500'}`} />
              <span className="text-[11px]">
                {user.giTagVerified ? 'GI Verified' : 'GI Pending'}
              </span>
            </div>
          )}

          {/* Real-time WebSocket connectivity status */}
          <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-stone-100 text-stone-600 text-[11px] font-mono border border-stone-200">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <Wifi className="w-3.5 h-3.5 text-emerald-600" />
            <span>Live Node</span>
          </div>

          {/* Notifications Center Bell with Dropdown */}
          <div className="relative">
            <button
              onClick={() => {
                setShowNotifMenu(!showNotifMenu);
                setShowRoleMenu(false);
                setShowUserMenu(false);
              }}
              className="relative p-2 rounded-xl text-stone-600 hover:text-stone-900 hover:bg-stone-100 transition-colors"
              title="Notifications"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 flex items-center justify-center min-w-4 h-4 px-1 text-[10px] font-bold text-white bg-rose-500 rounded-full animate-bounce">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </button>

            {/* Notifications Menu */}
            {showNotifMenu && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-xl border border-stone-200 p-3 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-stone-100">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-stone-900">Notifications</span>
                    {unreadCount > 0 && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                        {unreadCount} new
                      </span>
                    )}
                  </div>
                  {unreadCount > 0 && (
                    <button
                      onClick={() => markAllAsRead()}
                      className="text-[11px] text-amber-700 hover:text-amber-800 font-medium"
                    >
                      Mark all read
                    </button>
                  )}
                </div>

                <div className="max-h-72 overflow-y-auto space-y-1.5 divide-y divide-stone-100">
                  {notifications.length === 0 ? (
                    <div className="py-6 text-center text-xs text-stone-400">
                      No notifications yet
                    </div>
                  ) : (
                    notifications.slice(0, 6).map((n) => (
                      <div
                        key={n.id}
                        onClick={() => {
                          markAsRead(n.id);
                          if (n.batchId) {
                            setActiveTab('batches');
                          } else if (n.trackingId) {
                            setActiveTab('distribution');
                          }
                          setShowNotifMenu(false);
                        }}
                        className={`pt-2 pb-1 px-2 rounded-xl text-left cursor-pointer transition-colors ${
                          !n.read ? 'bg-amber-50/60 font-medium' : 'hover:bg-stone-50'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <span className="text-xs font-semibold text-stone-900 line-clamp-1">{n.title}</span>
                          <span className="text-[10px] text-stone-400 font-mono shrink-0">
                            {new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-[11px] text-stone-600 line-clamp-2 mt-0.5">{n.message}</p>
                      </div>
                    ))
                  )}
                </div>

                <div className="pt-2 mt-2 border-t border-stone-100 text-center">
                  <button
                    onClick={() => {
                      setActiveTab('notifications');
                      setShowNotifMenu(false);
                    }}
                    className="text-xs text-amber-700 font-semibold hover:underline"
                  >
                    View All Notifications
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Quick Demo Switcher (Role Switcher for testing all 6 user roles easily) */}
          <div className="relative">
            <button
              onClick={() => {
                setShowRoleMenu(!showRoleMenu);
                setShowNotifMenu(false);
                setShowUserMenu(false);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all ${currentRoleStyle.bg} ${currentRoleStyle.text} ${currentRoleStyle.border}`}
            >
              <span>{user?.role?.replace('_', ' ') || 'Switch Role'}</span>
              <ChevronDown className="w-3.5 h-3.5 opacity-60" />
            </button>

            {showRoleMenu && (
              <div className="absolute right-0 mt-2 w-72 bg-white rounded-2xl shadow-xl border border-stone-200 p-2 z-50">
                <div className="px-3 py-2 border-b border-stone-100">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400 block">
                    Quick Role Switcher (Demo Mode)
                  </span>
                  <span className="text-xs text-stone-600">
                    Test full permissions across all 6 roles with 1-click:
                  </span>
                </div>

                <div className="py-1 space-y-1">
                  {(Object.keys(DEMO_CREDENTIALS) as Role[]).map((r) => {
                    const cred = DEMO_CREDENTIALS[r];
                    const isCurrent = user?.role === r;

                    return (
                      <button
                        key={r}
                        onClick={async () => {
                          setShowRoleMenu(false);
                          await quickDemoLogin(r);
                          if (r === 'ADMIN') setActiveTab('admin');
                          else if (r === 'BEEKEEPER') setActiveTab('harvest');
                          else if (r === 'PROCESSOR') setActiveTab('processing');
                          else if (r === 'QUALITY_INSPECTOR') setActiveTab('inspection');
                          else if (r === 'DISTRIBUTOR') setActiveTab('distribution');
                          else setActiveTab('batches');
                        }}
                        className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center justify-between transition-colors ${
                          isCurrent
                            ? 'bg-amber-100/70 text-amber-900 font-bold'
                            : 'hover:bg-stone-50 text-stone-700'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-base">{cred.icon}</span>
                          <div>
                            <div className="font-semibold">{cred.title}</div>
                            <div className="text-[10px] text-stone-400 font-normal">{r.replace('_', ' ')}</div>
                          </div>
                        </div>
                        {isCurrent && <CheckCircle className="w-4 h-4 text-emerald-600" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* User Profile Avatar & Logout */}
          <div className="relative">
            <button
              onClick={() => {
                setShowUserMenu(!showUserMenu);
                setShowNotifMenu(false);
                setShowRoleMenu(false);
              }}
              className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-stone-100 transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-600 to-amber-400 text-stone-950 font-bold flex items-center justify-center text-xs shadow-sm">
                {user?.name ? user.name[0] : 'U'}
              </div>
            </button>

            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-stone-200 p-2 z-50">
                <div className="px-3 py-2 border-b border-stone-100">
                  <div className="font-bold text-xs text-stone-900 truncate">{user?.name}</div>
                  <div className="text-[11px] text-stone-500 font-mono truncate">{user?.email}</div>
                  <div className="mt-1 text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md inline-block">
                    {user?.role.replace('_', ' ')}
                  </div>
                </div>

                <div className="py-1">
                  <button
                    onClick={() => {
                      setActiveTab('profile');
                      setShowUserMenu(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-stone-700 hover:bg-stone-50 transition-colors"
                  >
                    <UserIcon className="w-4 h-4 text-stone-400" />
                    <span>Profile & GI Tag Details</span>
                  </button>

                  <button
                    onClick={() => {
                      logout();
                      setShowUserMenu(false);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-rose-600 hover:bg-rose-50 transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
