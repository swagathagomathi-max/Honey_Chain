import React, { useState } from 'react';
import { DistributionRecord, Checkpoint } from '../types';
import { Truck, MapPin, CheckCircle2, ShieldCheck, Thermometer, Navigation, Calendar, Box, Radio } from 'lucide-react';

interface TrackingMapProps {
  distribution: DistributionRecord;
  className?: string;
}

export const TrackingMap: React.FC<TrackingMapProps> = ({ distribution, className = '' }) => {
  const [selectedCheckpoint, setSelectedCheckpoint] = useState<Checkpoint | null>(
    distribution.checkpoints && distribution.checkpoints.length > 0
      ? distribution.checkpoints[distribution.checkpoints.length - 1]
      : null
  );

  const checkpoints = distribution.checkpoints || [];
  const statusColors: Record<string, string> = {
    PREPARING: 'bg-amber-500 text-amber-950 border-amber-300',
    IN_TRANSIT: 'bg-blue-600 text-white border-blue-400',
    DELIVERED: 'bg-emerald-600 text-white border-emerald-400',
    DELAYED: 'bg-rose-600 text-white border-rose-400',
  };

  // Convert coords to percentage coordinates on visual map canvas
  const minLat = 35.0;
  const maxLat = 50.0;
  const minLng = -125.0;
  const maxLng = -115.0;

  const projectCoords = (lat: number, lng: number) => {
    // Basic normalized projection bounded for US West Coast / route visualization
    const clampedLat = Math.max(minLat, Math.min(maxLat, lat));
    const clampedLng = Math.max(minLng, Math.min(maxLng, lng));
    const y = ((maxLat - clampedLat) / (maxLat - minLat)) * 75 + 12; // 12% to 87%
    const x = ((clampedLng - minLng) / (maxLng - minLng)) * 75 + 12;
    return { x: Math.min(92, Math.max(8, x)), y: Math.min(90, Math.max(10, y)) };
  };

  const originProj = projectCoords(distribution.sourceCoords[0], distribution.sourceCoords[1]);
  const destProj = projectCoords(distribution.destinationCoords[0], distribution.destinationCoords[1]);

  return (
    <div className={`bg-white rounded-2xl border border-stone-200/90 shadow-sm overflow-hidden flex flex-col ${className}`}>
      {/* Header telemetry bar */}
      <div className="bg-stone-900 text-white p-4 flex flex-wrap items-center justify-between gap-3 border-b border-stone-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <Radio className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase font-mono tracking-wider text-amber-400 font-semibold">
                Live IoT Telemetry
              </span>
              <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full uppercase border ${statusColors[distribution.transportStatus] || 'bg-stone-700 text-white'}`}>
                {distribution.transportStatus.replace('_', ' ')}
              </span>
            </div>
            <h4 className="text-sm font-bold font-['Outfit'] text-stone-100">
              Tracking ID: <span className="font-mono text-amber-300">{distribution.trackingId}</span>
            </h4>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="flex items-center gap-1.5 bg-stone-800/80 px-2.5 py-1.5 rounded-lg border border-stone-700">
            <Thermometer className="w-4 h-4 text-sky-400" />
            <span className="text-stone-300">Temp:</span>
            <span className="text-emerald-400 font-semibold">{distribution.storageTemperature}°C</span>
          </div>
          <div className="flex items-center gap-1.5 bg-stone-800/80 px-2.5 py-1.5 rounded-lg border border-stone-700">
            <Truck className="w-4 h-4 text-amber-400" />
            <span className="text-stone-300">Carrier:</span>
            <span className="text-stone-100 font-medium">{distribution.carrierName}</span>
          </div>
        </div>
      </div>

      {/* Visual Route Canvas Map */}
      <div className="relative w-full h-80 bg-gradient-to-br from-stone-900 via-[#0d1e15] to-[#12281b] overflow-hidden select-none border-b border-stone-200">
        {/* Mapbox styled vector grid lines & topological curves */}
        <div className="absolute inset-0 opacity-15 bg-[linear-gradient(to_right,#10b981_1px,transparent_1px),linear-gradient(to_bottom,#10b981_1px,transparent_1px)] bg-[size:32px_32px]" />

        {/* Ambient Map Glow */}
        <div className="absolute top-1/4 left-1/3 w-72 h-72 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none" />
        <div className="absolute bottom-1/4 right-1/4 w-72 h-72 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />

        {/* Map water/terrain styling elements */}
        <div className="absolute top-4 left-4 z-10 bg-stone-950/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-emerald-500/30 text-[11px] font-mono text-emerald-400 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
          Mapbox API Vector Coordinates Engine
        </div>

        <svg className="absolute inset-0 w-full h-full pointer-events-none z-10" viewBox="0 0 100 100" preserveAspectRatio="none">
          {/* Main Transit Corridor Path */}
          <path
            d={`M ${originProj.x} ${originProj.y} Q 40 45 ${destProj.x} ${destProj.y}`}
            fill="none"
            stroke="#f59e0b"
            strokeWidth="0.8"
            strokeDasharray="2 1.5"
            className="animate-pulse"
          />
          {/* Animated Glow Transit Path */}
          <path
            d={`M ${originProj.x} ${originProj.y} Q 40 45 ${destProj.x} ${destProj.y}`}
            fill="none"
            stroke="#10b981"
            strokeWidth="0.4"
            opacity="0.7"
          />
        </svg>

        {/* Origin Pin (Apiary / Harvest) */}
        <div
          className="absolute z-20 -translate-x-1/2 -translate-y-1/2 group cursor-pointer"
          style={{ left: `${originProj.x}%`, top: `${originProj.y}%` }}
        >
          <div className="relative flex items-center justify-center">
            <span className="animate-ping absolute inline-flex h-8 w-8 rounded-full bg-amber-400 opacity-40" />
            <div className="w-8 h-8 rounded-full bg-amber-500 text-stone-950 flex items-center justify-center shadow-lg font-bold border-2 border-white">
              🍯
            </div>
          </div>
          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 bg-stone-900/90 text-white text-[10px] font-medium py-1 px-2 rounded-md shadow-lg whitespace-nowrap border border-stone-700 pointer-events-none">
            Origin: {distribution.sourceLocation.split(',')[0]}
          </div>
        </div>

        {/* Intermediate Checkpoints */}
        {checkpoints.map((cp, idx) => {
          const proj = projectCoords(cp.coordinates[0], cp.coordinates[1]);
          const isLatest = idx === checkpoints.length - 1;
          const isSelected = selectedCheckpoint?.id === cp.id;

          return (
            <div
              key={cp.id}
              onClick={() => setSelectedCheckpoint(cp)}
              className="absolute z-30 -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-transform hover:scale-125"
              style={{ left: `${proj.x}%`, top: `${proj.y}%` }}
            >
              {isLatest && distribution.transportStatus === 'IN_TRANSIT' && (
                <span className="animate-ping absolute inline-flex h-10 w-10 rounded-full bg-sky-400 opacity-60" />
              )}
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center shadow-md border-2 transition-all ${
                  isSelected
                    ? 'bg-sky-500 text-white border-white ring-4 ring-sky-500/30'
                    : isLatest
                    ? 'bg-blue-600 text-white border-sky-300'
                    : 'bg-stone-800 text-emerald-400 border-emerald-500'
                }`}
              >
                <Truck className="w-3.5 h-3.5" />
              </div>
            </div>
          );
        })}

        {/* Destination Pin */}
        <div
          className="absolute z-20 -translate-x-1/2 -translate-y-1/2 group cursor-pointer"
          style={{ left: `${destProj.x}%`, top: `${destProj.y}%` }}
        >
          <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-lg border-2 border-white">
            <MapPin className="w-4 h-4" />
          </div>
          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 bg-stone-900/90 text-white text-[10px] font-medium py-1 px-2 rounded-md shadow-lg whitespace-nowrap border border-stone-700 pointer-events-none">
            Destination: {distribution.destinationLocation.split(',')[0]}
          </div>
        </div>

        {/* Bottom map overlay: Quick Stats */}
        <div className="absolute bottom-3 left-3 right-3 z-20 bg-stone-900/85 backdrop-blur-md p-3 rounded-xl border border-stone-700/80 flex flex-wrap items-center justify-between text-xs text-stone-300 gap-2">
          <div className="flex items-center gap-2">
            <Navigation className="w-4 h-4 text-emerald-400" />
            <span>Route: <strong className="text-white">{distribution.sourceLocation.split(',')[0]}</strong> → <strong className="text-white">{distribution.destinationLocation.split(',')[0]}</strong></span>
          </div>
          <div className="flex items-center gap-3 font-mono text-[11px]">
            <span>Transport: <span className="text-amber-400 font-medium">{distribution.transportMethod}</span></span>
            <span>Checkpoints: <span className="text-sky-400 font-bold">{checkpoints.length}</span></span>
          </div>
        </div>
      </div>

      {/* Checkpoints Timeline Table */}
      <div className="p-4 bg-stone-50 border-t border-stone-200">
        <div className="flex items-center justify-between mb-3">
          <h5 className="text-xs font-bold uppercase tracking-wider text-stone-600 font-mono flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-amber-600" />
            Verified Transit Checkpoints
          </h5>
          <span className="text-xs text-stone-500">
            Expected Delivery: <strong className="text-stone-800">{distribution.expectedDeliveryDate}</strong>
          </span>
        </div>

        <div className="space-y-2.5">
          {checkpoints.map((cp, idx) => {
            const isSelected = selectedCheckpoint?.id === cp.id;
            const isLast = idx === checkpoints.length - 1;

            return (
              <div
                key={cp.id}
                onClick={() => setSelectedCheckpoint(cp)}
                className={`p-3 rounded-xl border transition-all cursor-pointer flex items-start justify-between gap-3 ${
                  isSelected
                    ? 'bg-amber-50/80 border-amber-300 ring-2 ring-amber-400/20 shadow-sm'
                    : 'bg-white border-stone-200/80 hover:border-amber-200'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`mt-0.5 w-6 h-6 rounded-full flex items-center justify-center shrink-0 text-xs font-bold ${
                      isLast
                        ? 'bg-emerald-600 text-white'
                        : 'bg-stone-100 text-stone-600 border border-stone-300'
                    }`}
                  >
                    {idx + 1}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-stone-900">{cp.location}</span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-stone-100 text-stone-600 border border-stone-200">
                        {cp.status}
                      </span>
                    </div>
                    <p className="text-xs text-stone-600 mt-0.5">{cp.note}</p>
                    <div className="flex items-center gap-3 mt-1.5 text-[11px] text-stone-500 font-mono">
                      <span>Coordinates: [{cp.coordinates[0].toFixed(4)}, {cp.coordinates[1].toFixed(4)}]</span>
                      {cp.temperature && <span>Temp: {cp.temperature}°C</span>}
                    </div>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-[11px] font-mono text-stone-500 block">
                    {new Date(cp.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                  <span className="text-[10px] text-stone-400 block">
                    {new Date(cp.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
