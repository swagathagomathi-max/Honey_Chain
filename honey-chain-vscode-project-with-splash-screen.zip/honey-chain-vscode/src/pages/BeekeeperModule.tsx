import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { HoneyBatch, HoneyType } from '../types';
import {
  Sprout,
  Plus,
  ShieldCheck,
  Award,
  Layers,
  MapPin,
  Calendar,
  Thermometer,
  Droplets,
  DollarSign,
  CheckCircle,
  ExternalLink,
  Upload,
  Info
} from 'lucide-react';

interface BeekeeperModuleProps {
  onSelectBatch?: (id: string) => void;
}

export const BeekeeperModule: React.FC<BeekeeperModuleProps> = ({ onSelectBatch }) => {
  const { user, updateProfile } = useAuth();
  const [batches, setBatches] = useState<HoneyBatch[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNewHarvestModal, setShowNewHarvestModal] = useState(false);
  const [showGiModal, setShowGiModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [successBanner, setSuccessBanner] = useState<string | null>(null);

  // New Harvest Form State
  const [apiaryId, setApiaryId] = useState(`AP-CASCADE-0${Math.floor(1 + Math.random() * 8)}`);
  const [apiaryName, setApiaryName] = useState(`${user?.name || 'Artisan'} Alpine Apiary`);
  const [harvestDate, setHarvestDate] = useState(new Date().toISOString().slice(0, 10));
  const [location, setLocation] = useState(user?.location || 'Cascade Mountain Valley, WA');
  const [latitude, setLatitude] = useState('47.7511');
  const [longitude, setLongitude] = useState('-120.7401');
  const [hiveCount, setHiveCount] = useState('32');
  const [honeyType, setHoneyType] = useState<HoneyType>('Wildflower');
  const [floralSource, setFloralSource] = useState('Mountain Heather, Blackberry & Pine Dew');
  const [quantity, setQuantity] = useState('240');
  const [harvestMethod, setHarvestMethod] = useState('Centrifugal cold comb uncapping');
  const [temperature, setTemperature] = useState('22.5');
  const [moisturePercentage, setMoisturePercentage] = useState('16.4');
  const [costPerKg, setCostPerKg] = useState(user?.baseCostPerKg ? user.baseCostPerKg.toString() : '35.0');
  const [notes, setNotes] = useState('Early morning extraction during optimal nectar concentration.');
  const [imageUrl, setImageUrl] = useState('');

  // GI Tag Submission Form State
  const [giName, setGiName] = useState(user?.giTagName || '');
  const [giNumber, setGiNumber] = useState(user?.giTagNumber || '');
  const [giCertUrl, setGiCertUrl] = useState(user?.giTagCertificateUrl || '');
  const [giBasePrice, setGiBasePrice] = useState(user?.baseCostPerKg ? user.baseCostPerKg.toString() : '42.0');

  const fetchBatches = async () => {
    setLoading(true);
    try {
      const all = await api.getBatches({ beekeeperId: user?.id });
      setBatches(all);
    } catch (err) {
      console.error('Failed to load harvests:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBatches();
  }, [user]);

  const handleCreateHarvest = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await api.createHarvest({
        apiaryId,
        apiaryName,
        harvestDate,
        location,
        latitude: parseFloat(latitude),
        longitude: parseFloat(longitude),
        hiveCount: parseInt(hiveCount, 10),
        honeyType,
        floralSource,
        quantity: parseFloat(quantity),
        harvestMethod,
        temperature: parseFloat(temperature),
        moisturePercentage: parseFloat(moisturePercentage),
        notes,
        imageUrl,
        costPerKg: parseFloat(costPerKg)
      });

      setShowNewHarvestModal(false);
      setSuccessBanner(`Batch ${res.batch.id} harvested and registered to Blockchain Block #${res.blockchainBlock.index}!`);
      fetchBatches();
    } catch (err: any) {
      alert('Error creating harvest: ' + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleSubmitGiTag = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await updateProfile({
        hasGiTag: true,
        giTagName: giName,
        giTagNumber: giNumber,
        giTagCertificateUrl: giCertUrl || 'https://honeychain.io/certificates/GI-SUBMITTED.pdf',
        baseCostPerKg: parseFloat(giBasePrice)
      });
      setShowGiModal(false);
      setSuccessBanner('GI Tag Certificate submitted for verification! Your profile now displays the pending GI tag.');
    } catch (err: any) {
      alert('Failed to submit GI Tag: ' + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Harvester Banner */}
      <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 rounded-3xl p-6 text-stone-950 shadow-md flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider font-bold bg-stone-950 text-amber-300 px-2.5 py-0.5 rounded-full">
              Smart Beekeeping Hub
            </span>
            {user?.hasGiTag && (
              <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1 ${
                user.giTagVerified ? 'bg-emerald-950 text-emerald-300' : 'bg-amber-900 text-amber-200'
              }`}>
                <ShieldCheck className="w-3.5 h-3.5" />
                {user.giTagVerified ? 'GI Verified Harvester' : 'GI Certificate Pending Review'}
              </span>
            )}
          </div>
          <h1 className="text-2xl font-black font-['Outfit'] text-white">
            Honey Harvest Management
          </h1>
          <p className="text-xs text-amber-100 max-w-xl mt-1">
            Record extraction parameters, register apiary GPS coordinates, and mint cryptographic blockchain records for each honey batch.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* GI Tag Submission Button */}
          <button
            onClick={() => setShowGiModal(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-white/90 hover:bg-white text-stone-900 text-xs font-bold transition-all shadow-sm"
          >
            <Award className="w-4 h-4 text-amber-600" />
            <span>{user?.hasGiTag ? 'Manage GI Tag' : 'Submit GI Tag'}</span>
          </button>

          {/* New Harvest Button */}
          <button
            onClick={() => setShowNewHarvestModal(true)}
            className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-stone-950 hover:bg-stone-900 text-amber-400 font-bold text-xs uppercase tracking-wider transition-all shadow-lg active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>New Honey Harvest</span>
          </button>
        </div>
      </div>

      {/* Success Notification */}
      {successBanner && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-600" />
            <span>{successBanner}</span>
          </div>
          <button onClick={() => setSuccessBanner(null)} className="font-mono text-xs opacity-60 hover:opacity-100">
            Dismiss
          </button>
        </div>
      )}

      {/* Harvester Profile Trust & Pricing Card (as requested) */}
      <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-2xl">
            🐝
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-sm text-stone-900">{user?.name}</h3>
              {user?.giTagVerified && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                  GI Certified Origin
                </span>
              )}
            </div>
            <p className="text-xs text-stone-500">
              {user?.organization || 'Independent Artisan Apiary'} • {user?.location || 'Mountain Apiary Sanctuary'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-6 text-xs">
          <div>
            <span className="text-[10px] font-mono text-stone-400 block uppercase">Base Harvest Rate</span>
            <span className="text-base font-black font-['Outfit'] text-emerald-700">
              ${user?.baseCostPerKg || 35.00} <span className="text-xs font-normal text-stone-500">/ kg</span>
            </span>
          </div>
          {user?.giTagVerified && (
            <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-[11px]">
              <span className="font-bold block">✨ GI Trust Premium Active</span>
              <span>Can charge higher premium rates due to verified geographical indication.</span>
            </div>
          )}
        </div>
      </div>

      {/* Batches Table */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-stone-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-amber-600" />
            <h3 className="font-bold text-sm text-stone-900 font-['Outfit']">
              My Harvested Batches ({batches.length})
            </h3>
          </div>
          <button
            onClick={fetchBatches}
            className="text-xs text-amber-700 font-semibold hover:underline"
          >
            Refresh List
          </button>
        </div>

        {loading ? (
          <div className="p-8 text-center text-xs text-stone-400 font-mono">
            Loading batches...
          </div>
        ) : batches.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto text-xl">
              🍯
            </div>
            <p className="text-sm font-bold text-stone-700">No honey harvests recorded yet.</p>
            <p className="text-xs text-stone-400 max-w-sm mx-auto">
              Start by logging a new harvest batch to assign a Batch ID, record moisture and hive stats, and mine the initial blockchain block.
            </p>
            <button
              onClick={() => setShowNewHarvestModal(true)}
              className="mt-2 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs rounded-xl"
            >
              Log First Harvest
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 font-mono text-[11px] uppercase">
                <tr>
                  <th className="py-3 px-4">Batch ID</th>
                  <th className="py-3 px-4">Honey Type & Floral</th>
                  <th className="py-3 px-4">Apiary & Location</th>
                  <th className="py-3 px-4">Yield (kg)</th>
                  <th className="py-3 px-4">Moisture</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {batches.map((b) => (
                  <tr key={b.id} className="hover:bg-amber-50/40">
                    <td className="py-3 px-4">
                      <span className="font-mono font-bold text-amber-800 block">{b.id}</span>
                      <span className="text-[10px] text-stone-400 font-mono">{b.harvestDate}</span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-stone-900">{b.honeyType}</div>
                      <div className="text-[11px] text-stone-500 truncate max-w-xs">{b.floralSource}</div>
                    </td>
                    <td className="py-3 px-4 text-stone-600">
                      <div>{b.apiaryName}</div>
                      <div className="text-[11px] text-stone-400">{b.location}</div>
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-stone-900">
                      {b.quantity} kg
                    </td>
                    <td className="py-3 px-4 font-mono">
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        b.moisturePercentage <= 17.5 ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {b.moisturePercentage}%
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-stone-100 text-stone-700">
                        {b.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => onSelectBatch && onSelectBatch(b.id)}
                        className="px-3 py-1 bg-amber-50 hover:bg-amber-100 text-amber-900 rounded-xl font-bold text-[11px] transition-colors"
                      >
                        View History
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* NEW HONEY HARVEST MODAL (All required fields) */}
      {showNewHarvestModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/75 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full border border-stone-200 shadow-2xl my-8 overflow-hidden">
            <div className="p-5 bg-gradient-to-r from-amber-500 to-amber-600 text-stone-950 flex items-center justify-between">
              <div>
                <h3 className="font-black text-base font-['Outfit']">New Honey Harvest Submission</h3>
                <p className="text-xs text-amber-950 font-medium">
                  Generates unique Batch ID, stores harvest records, and commits transaction to Blockchain.
                </p>
              </div>
              <button
                onClick={() => setShowNewHarvestModal(false)}
                className="p-1 rounded-full hover:bg-amber-600 text-stone-950 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateHarvest} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Beekeeper name */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Beekeeper Name</label>
                  <input
                    type="text"
                    readOnly
                    value={user?.name || ''}
                    className="w-full px-3 py-2 text-xs border border-stone-200 rounded-xl bg-stone-100 text-stone-600 font-semibold cursor-not-allowed"
                  />
                </div>

                {/* Apiary ID */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Apiary ID</label>
                  <input
                    type="text"
                    required
                    value={apiaryId}
                    onChange={(e) => setApiaryId(e.target.value)}
                    placeholder="e.g. AP-PINES-04"
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                  />
                </div>

                {/* Apiary Name */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Apiary Sanctuary Name</label>
                  <input
                    type="text"
                    required
                    value={apiaryName}
                    onChange={(e) => setApiaryName(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                {/* Harvest Date */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Harvest Date</label>
                  <input
                    type="date"
                    required
                    value={harvestDate}
                    onChange={(e) => setHarvestDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                {/* Location */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Harvest Location</label>
                  <input
                    type="text"
                    required
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="e.g. Cascade Mountain Valley, WA"
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                {/* Coordinates */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Latitude</label>
                  <input
                    type="number"
                    step="0.0001"
                    required
                    value={latitude}
                    onChange={(e) => setLatitude(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Longitude</label>
                  <input
                    type="number"
                    step="0.0001"
                    required
                    value={longitude}
                    onChange={(e) => setLongitude(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                  />
                </div>

                {/* Number of hives */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Number of Hives</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={hiveCount}
                    onChange={(e) => setHiveCount(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                {/* Honey Type */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Honey Type</label>
                  <select
                    value={honeyType}
                    onChange={(e) => setHoneyType(e.target.value as HoneyType)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
                  >
                    <option value="Wildflower">Wildflower</option>
                    <option value="Acacia">Acacia</option>
                    <option value="Eucalyptus">Eucalyptus</option>
                    <option value="Mustard">Mustard</option>
                    <option value="Multifloral">Multifloral</option>
                    <option value="Sidr">Sidr</option>
                    <option value="Lavender">Lavender</option>
                    <option value="Clover">Clover</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                {/* Floral Source */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Floral Source</label>
                  <input
                    type="text"
                    required
                    value={floralSource}
                    onChange={(e) => setFloralSource(e.target.value)}
                    placeholder="e.g. Robinia pseudoacacia (Acacia Blossom)"
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                {/* Quantity */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Quantity Harvested (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    min="1"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-bold"
                  />
                </div>

                {/* Base Cost / Price */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                    Base Cost / Price ($/kg)
                    {user?.giTagVerified && <span className="text-emerald-600 font-semibold ml-1">(GI Premium Enabled)</span>}
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    required
                    value={costPerKg}
                    onChange={(e) => setCostPerKg(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-bold text-emerald-800"
                  />
                </div>

                {/* Harvest Method */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Harvest Method</label>
                  <input
                    type="text"
                    value={harvestMethod}
                    onChange={(e) => setHarvestMethod(e.target.value)}
                    placeholder="e.g. Cold comb centrifugal extraction"
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                {/* Temperature */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Temperature at Harvest (°C)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={temperature}
                    onChange={(e) => setTemperature(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                {/* Moisture Percentage */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Moisture Percentage (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={moisturePercentage}
                    onChange={(e) => setMoisturePercentage(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                {/* Notes */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Harvest Notes & Observations</label>
                  <textarea
                    rows={2}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-amber-50/70 border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
                <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <span>
                  Submitting this harvest will automatically generate a unique Batch ID, compute SHA-256 data hash, and mine a new block on the Honey Chain private blockchain.
                </span>
              </div>

              <div className="flex justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowNewHarvestModal(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-6 py-2 bg-amber-500 hover:bg-amber-600 text-stone-950 text-xs font-bold rounded-xl shadow-md disabled:opacity-50"
                >
                  {submitting ? 'Mining Blockchain Block...' : 'Submit Harvest & Mine Block'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* GI TAG SUBMISSION MODAL (as requested) */}
      {showGiModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/75 backdrop-blur-sm">
          <div className="bg-white rounded-3xl max-w-lg w-full border border-stone-200 shadow-2xl overflow-hidden">
            <div className="p-5 bg-gradient-to-r from-emerald-600 to-emerald-700 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5" />
                <h3 className="font-bold text-sm font-['Outfit']">Submit Geographical Indication (GI) Certificate</h3>
              </div>
              <button onClick={() => setShowGiModal(false)} className="text-white hover:opacity-80">✕</button>
            </div>

            <form onSubmit={handleSubmitGiTag} className="p-6 space-y-4">
              <p className="text-xs text-stone-600">
                Harvesters with a certified GI Tag (such as Kashmir Honey, Sundarbans Honey, or Pacific Northwest Reserve) can register their official certificate. Once verified by the Admin Board, your profile earns a Verified GI Badge and unlocks higher product pricing.
              </p>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">GI Reserve / Region Name</label>
                <input
                  type="text"
                  required
                  value={giName}
                  onChange={(e) => setGiName(e.target.value)}
                  placeholder="e.g. Pacific Northwest Wildflower Forest Reserve"
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Official Registration / Certificate No.</label>
                <input
                  type="text"
                  required
                  value={giNumber}
                  onChange={(e) => setGiNumber(e.target.value)}
                  placeholder="e.g. GI-USA-WA-2024-0089"
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Certificate File / Document URL</label>
                <input
                  type="text"
                  value={giCertUrl}
                  onChange={(e) => setGiCertUrl(e.target.value)}
                  placeholder="https://honeychain.io/certificates/my-gi-certificate.pdf"
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Requested Base Price ($/kg)</label>
                <input
                  type="number"
                  step="0.5"
                  value={giBasePrice}
                  onChange={(e) => setGiBasePrice(e.target.value)}
                  placeholder="38.50"
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowGiModal(false)}
                  className="px-4 py-2 bg-stone-100 rounded-xl text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold"
                >
                  {submitting ? 'Submitting...' : 'Submit GI Tag for Verification'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
