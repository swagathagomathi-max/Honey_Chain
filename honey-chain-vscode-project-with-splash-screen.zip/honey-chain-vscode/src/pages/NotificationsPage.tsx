import React, { useState } from 'react';
import { useNotifications } from '../context/NotificationContext';
import {
  Bell,
  CheckCircle,
  CheckCheck,
  Filter,
  Layers,
  Cpu,
  ShieldCheck,
  PackageCheck,
  Truck,
  Award,
  Link as LinkIcon
} from 'lucide-react';

interface NotificationsPageProps {
  onSelectBatch?: (id: string) => void;
  onNavigateTracking?: (trackId: string) => void;
}

export const NotificationsPage: React.FC<NotificationsPageProps> = ({
  onSelectBatch,
  onNavigateTracking
}) => {
  const { notifications, unreadCount, markAsRead, markAllAsRead } = useNotifications();
  const [filterType, setFilterType] = useState<string>('ALL');

  const getIconForType = (type: string) => {
    switch (type) {
      case 'BATCH_CREATED':
        return <Layers className="w-4 h-4 text-amber-600" />;
      case 'PROCESSING_UPDATE':
        return <Cpu className="w-4 h-4 text-purple-600" />;
      case 'INSPECTION_UPDATE':
        return <ShieldCheck className="w-4 h-4 text-emerald-600" />;
      case 'PRODUCT_PACKAGED':
        return <PackageCheck className="w-4 h-4 text-blue-600" />;
      case 'DISTRIBUTION_UPDATE':
        return <Truck className="w-4 h-4 text-sky-600" />;
      case 'GI_VERIFIED':
        return <Award className="w-4 h-4 text-amber-600" />;
      default:
        return <Bell className="w-4 h-4 text-stone-600" />;
    }
  };

  const filteredNotifs = notifications.filter((n) => {
    if (filterType === 'UNREAD') return !n.read;
    if (filterType !== 'ALL') return n.type === filterType;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-amber-700 bg-amber-100 font-bold px-2.5 py-0.5 rounded-full">
              Real-Time Push Notification Center
            </span>
            {unreadCount > 0 && (
              <span className="text-xs font-bold text-rose-600">
                {unreadCount} Unread Alerts
              </span>
            )}
          </div>
          <h1 className="text-2xl font-black font-['Outfit'] text-stone-900">
            System Events & Alerts
          </h1>
          <p className="text-xs text-stone-500">
            Live WebSocket pushed notifications for harvest creation, lab inspection verdicts, and distribution dispatch milestones.
          </p>
        </div>

        {unreadCount > 0 && (
          <button
            onClick={() => markAllAsRead()}
            className="flex items-center gap-1.5 px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-bold transition-colors"
          >
            <CheckCheck className="w-4 h-4 text-emerald-600" />
            <span>Mark All as Read</span>
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        {[
          { id: 'ALL', label: 'All Alerts' },
          { id: 'UNREAD', label: `Unread (${unreadCount})` },
          { id: 'BATCH_CREATED', label: 'Harvests' },
          { id: 'PROCESSING_UPDATE', label: 'Processing' },
          { id: 'INSPECTION_UPDATE', label: 'Lab Inspections' },
          { id: 'PRODUCT_PACKAGED', label: 'Packaging' },
          { id: 'DISTRIBUTION_UPDATE', label: 'Distribution' },
          { id: 'GI_VERIFIED', label: 'GI Verification' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilterType(tab.id)}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all whitespace-nowrap ${
              filterType === tab.id
                ? 'bg-amber-500 text-stone-950 shadow-sm'
                : 'bg-white hover:bg-stone-50 text-stone-600 border border-stone-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Notifications List */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden">
        {filteredNotifs.length === 0 ? (
          <div className="p-12 text-center text-xs text-stone-400">
            No notifications in this category.
          </div>
        ) : (
          <div className="divide-y divide-stone-100">
            {filteredNotifs.map((n) => (
              <div
                key={n.id}
                onClick={() => {
                  markAsRead(n.id);
                  if (n.batchId && onSelectBatch) {
                    onSelectBatch(n.batchId);
                  } else if (n.trackingId && onNavigateTracking) {
                    onNavigateTracking(n.trackingId);
                  }
                }}
                className={`p-5 flex items-start justify-between gap-4 transition-colors cursor-pointer ${
                  !n.read ? 'bg-amber-50/50 hover:bg-amber-100/50' : 'hover:bg-stone-50'
                }`}
              >
                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-2xl bg-white border border-stone-200 flex items-center justify-center shrink-0 shadow-sm">
                    {getIconForType(n.type)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-xs text-stone-900">{n.title}</h4>
                      {!n.read && (
                        <span className="w-2 h-2 rounded-full bg-rose-500" />
                      )}
                    </div>
                    <p className="text-xs text-stone-600 mt-0.5 max-w-2xl">{n.message}</p>

                    <div className="flex items-center gap-3 mt-2 text-[11px] font-mono text-stone-400">
                      <span>Type: {n.type}</span>
                      {n.batchId && <span>Batch: {n.batchId}</span>}
                      {n.trackingId && <span>Track: {n.trackingId}</span>}
                    </div>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-[11px] font-mono text-stone-400 block">
                    {new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                  <span className="text-[10px] text-stone-400 block">
                    {new Date(n.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
