import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { HoneyChainLogo } from '../components/HoneyChainLogo';
import { TrackingMap } from '../components/TrackingMap';
import {
  ShieldCheck,
  CheckCircle2,
  Award,
  Search,
  ExternalLink,
  Printer,
  Share2,
  Calendar,
  MapPin,
  Thermometer,
  Droplets,
  Cpu,
  Layers,
  Sparkles,
  Link as LinkIcon,
  Truck,
  Hash
} from 'lucide-react';

interface PublicVerifyPageProps {
  initialCode?: string;
  onNavigateHome?: () => void;
}

export const PublicVerifyPage: React.FC<PublicVerifyPageProps> = ({ initialCode, onNavigateHome }) => {
  const [searchCode, setSearchCode] = useState(initialCode || 'HC-PROD-9021');
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const performVerification = async (codeToVerify: string) => {
    if (!codeToVerify.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const res = await api.verifyCode(codeToVerify.trim());
      setData(res);
    } catch (err: any) {
      setError(err.message || 'Product or batch could not be found in blockchain ledger.');
      setData(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialCode) {
      setSearchCode(initialCode);
      performVerification(initialCode);
    } else {
      performVerification('HC-PROD-9021');
    }
  }, [initialCode]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    performVerification(searchCode);
  };

  const handlePrintCertificate = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FFFDF7] via-[#FFF9EC] to-[#FEF3C7] py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Verification Top Nav */}
        <div className="bg-white/95 backdrop-blur-md p-4 rounded-3xl border border-stone-200/90 shadow-sm flex flex-wrap items-center justify-between gap-4">
          <HoneyChainLogo size="sm" showSubtitle={true} />

          {/* Quick Search */}
          <form onSubmit={handleSearchSubmit} className="flex items-center gap-2 flex-1 max-w-md">
            <div className="relative w-full">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Enter Product ID, Track ID, or Batch ID..."
                value={searchCode}
                onChange={(e) => setSearchCode(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono placeholder:font-sans"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs rounded-xl transition-colors shadow-sm"
            >
              Verify
            </button>
          </form>
        </div>

        {loading ? (
          <div className="bg-white p-12 rounded-3xl border border-stone-200 text-center space-y-3 shadow-sm">
            <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-xs font-mono text-stone-600">Verifying SHA-256 Hashes Across Blockchain Nodes...</p>
          </div>
        ) : error ? (
          <div className="bg-white p-10 rounded-3xl border border-rose-200 text-center space-y-3 shadow-sm">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto text-xl">
              ✕
            </div>
            <h3 className="text-base font-bold text-stone-900 font-['Outfit']">Verification Failed</h3>
            <p className="text-xs text-rose-700 max-w-md mx-auto">{error}</p>
            <p className="text-[11px] text-stone-400">
              Try searching with demo product ID: <strong className="font-mono text-stone-700">HC-PROD-9021</strong> or batch ID: <strong className="font-mono text-stone-700">HC-BATCH-2026-0812</strong>
            </p>
          </div>
        ) : data && (
          <div className="space-y-6">
            {/* Authenticity Certificate Hero Banner */}
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0b3b24] via-[#052e1b] to-[#021b10] border-2 border-amber-400/60 p-6 sm:p-8 text-white shadow-xl">
              {/* Honeycomb background */}
              <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#f59e0b_1px,transparent_1px)] [background-size:12px_12px]" />

              <div className="relative z-10 flex flex-wrap items-center justify-between gap-6">
                <div className="space-y-2">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-400/40 text-emerald-300 text-xs font-bold font-mono">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>CRYPTOGRAPHICALLY VERIFIED GENUINE HONEY</span>
                  </div>

                  <h1 className="text-3xl font-black font-['Outfit'] tracking-tight text-amber-400">
                    {data.product ? data.product.productName : `${data.batch?.honeyType} Honey Reserve`}
                  </h1>

                  <p className="text-xs text-stone-300 max-w-lg">
                    This honey has been tracked from the high alpine apiary to this jar using Honey Chain private blockchain. Every stage is signed with SHA-256 hashes.
                  </p>

                  <div className="flex flex-wrap items-center gap-4 text-xs font-mono pt-2">
                    <span className="text-amber-300">
                      Product ID: <strong>{data.product?.id || 'PROD-VERIFIED'}</strong>
                    </span>
                    <span className="text-stone-300">
                      Batch ID: <strong>{data.batch?.id}</strong>
                    </span>
                    {data.product?.trackingId && (
                      <span className="text-emerald-300">
                        Track ID: <strong>{data.product.trackingId}</strong>
                      </span>
                    )}
                  </div>
                </div>

                {/* Authenticity Score Badge */}
                <div className="flex flex-col items-center justify-center p-4 rounded-2xl bg-gradient-to-b from-amber-500/20 to-amber-700/30 border border-amber-400/50 backdrop-blur-md shrink-0">
                  <span className="text-3xl font-black text-amber-300 font-['Outfit']">100%</span>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-stone-200 mt-0.5">Authenticity</span>
                  <span className="text-[9px] font-mono text-emerald-400 mt-1">Zero Adulteration</span>
                </div>
              </div>

              {/* Action Buttons in Banner */}
              <div className="relative z-10 mt-6 pt-4 border-t border-emerald-900/60 flex flex-wrap items-center justify-between gap-3 text-xs">
                <span className="text-[11px] font-mono text-stone-400">
                  Certified Under: Codex Alimentarius Stan 12-1981 & ISO 17025
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handlePrintCertificate}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold transition-colors"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Print Certificate</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Harvester Profile & GI Verified Badge (as requested in spec) */}
            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-stone-100">
                <h3 className="font-bold text-sm text-stone-900 font-['Outfit'] flex items-center gap-2">
                  <span className="text-lg">🐝</span>
                  <span>Harvester & Geographic Origin</span>
                </h3>

                {data.harvester?.hasGiTag && (
                  <span className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 border ${
                    data.harvester.giTagVerified
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                      : 'bg-amber-50 text-amber-800 border-amber-300'
                  }`}>
                    <Award className="w-4 h-4 text-emerald-600" />
                    <span>{data.harvester.giTagVerified ? 'Verified GI Tag Protected Origin' : 'GI Tag Pending'}</span>
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <h4 className="text-base font-bold text-stone-900">{data.harvester?.name || data.batch?.beekeeperName}</h4>
                  <p className="text-xs text-stone-500">{data.harvester?.organization || data.batch?.apiaryName}</p>
                  <div className="flex items-center gap-1.5 text-xs text-stone-600">
                    <MapPin className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>{data.batch?.location}</span>
                  </div>
                  <div className="text-xs text-stone-500 font-mono">
                    GPS Coordinates: [{data.batch?.latitude?.toFixed(4)}, {data.batch?.longitude?.toFixed(4)}]
                  </div>
                </div>

                {/* Geographical Indication (GI Tag) Certificate Details */}
                {data.harvester?.hasGiTag ? (
                  <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200 text-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-emerald-950 flex items-center gap-1">
                        <Award className="w-4 h-4 text-emerald-600" />
                        {data.harvester.giTagName}
                      </span>
                      <span className="text-[10px] font-mono font-bold bg-emerald-200/80 text-emerald-950 px-2 py-0.5 rounded-full">
                        GI Registered
                      </span>
                    </div>
                    <p className="text-emerald-800 text-[11px]">
                      Protected Geographical Indication guarantees nectar purity native only to this specific biodiversity zone.
                    </p>
                    <div className="font-mono text-[11px] text-emerald-900">
                      Registration No: <strong>{data.harvester.giTagNumber}</strong>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 text-xs text-stone-500 flex items-center">
                    <span>Standard Regional Origin (Zero Synthetic Additives)</span>
                  </div>
                )}
              </div>
            </div>

            {/* Farm-to-Table Supply Chain Journey */}
            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-4">
              <h3 className="font-bold text-sm text-stone-900 font-['Outfit'] flex items-center gap-2 pb-2 border-b border-stone-100">
                <Layers className="w-4 h-4 text-amber-600" />
                <span>The Story of This Honey Jar ("Every Drop Has a Story")</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* 1. Harvest */}
                <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200/90 space-y-2">
                  <div className="flex items-center justify-between text-[10px] font-mono uppercase font-bold text-amber-800">
                    <span>Stage 1: Harvest</span>
                    <span>{data.batch?.harvestDate}</span>
                  </div>
                  <div className="font-bold text-xs text-stone-900">{data.batch?.honeyType} Honey</div>
                  <p className="text-[11px] text-stone-600 line-clamp-2">{data.batch?.floralSource}</p>
                  <div className="pt-1 text-[11px] text-stone-500 font-mono">
                    Moisture: <strong>{data.batch?.moisturePercentage}%</strong>
                  </div>
                </div>

                {/* 2. Processing */}
                <div className="p-4 rounded-2xl bg-purple-50/70 border border-purple-200/90 space-y-2">
                  <div className="flex items-center justify-between text-[10px] font-mono uppercase font-bold text-purple-800">
                    <span>Stage 2: Processing</span>
                    <span>{data.processing?.[0]?.processingDate || 'Verified'}</span>
                  </div>
                  <div className="font-bold text-xs text-stone-900">Cold Extraction</div>
                  <p className="text-[11px] text-stone-600 line-clamp-2">
                    {data.processing?.[0]?.processingMethod || 'Raw Micro-clarification'}
                  </p>
                  <div className="pt-1 text-[11px] text-stone-500 font-mono">
                    Temp: <strong>{data.processing?.[0]?.heatingTemperature || 34.0}°C (Gentle)</strong>
                  </div>
                </div>

                {/* 3. Lab Inspection */}
                <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200/90 space-y-2">
                  <div className="flex items-center justify-between text-[10px] font-mono uppercase font-bold text-emerald-800">
                    <span>Stage 3: Lab Certified</span>
                    <span>{data.inspection?.[0]?.inspectionDate || 'Verified'}</span>
                  </div>
                  <div className="font-bold text-xs text-stone-900">
                    Grade {data.inspection?.[0]?.qualityGrade || data.batch?.qualityGrade || 'A'}
                  </div>
                  <p className="text-[11px] text-stone-600 line-clamp-2">
                    {data.inspection?.[0]?.purityTestResult || '100% Pure Natural Honey'}
                  </p>
                  <div className="pt-1 text-[11px] text-stone-500 font-mono">
                    Cert: <strong>{data.inspection?.[0]?.certificateNumber || 'ISO-17025'}</strong>
                  </div>
                </div>

                {/* 4. Retail Packaging */}
                <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200/90 space-y-2">
                  <div className="flex items-center justify-between text-[10px] font-mono uppercase font-bold text-blue-800">
                    <span>Stage 4: Sealed Jar</span>
                    <span>{data.product?.packagingDate || 'In Stock'}</span>
                  </div>
                  <div className="font-bold text-xs text-stone-900">{data.product?.packageType || 'Glass Jar'}</div>
                  <p className="text-[11px] text-stone-600">
                    Net: {data.product?.netQuantityGrams || 500}g • Expiry: {data.product?.expiryDate || '2028'}
                  </p>
                  <div className="pt-1 text-[11px] text-stone-500 font-mono">
                    MRP: <strong>${data.product?.mrp?.toFixed(2) || '32.50'}</strong>
                  </div>
                </div>
              </div>
            </div>

            {/* Cold Chain Distribution Map (if distribution record available) */}
            {data.distribution && (
              <div className="space-y-2">
                <h3 className="font-bold text-sm text-stone-900 font-['Outfit'] flex items-center gap-2">
                  <Truck className="w-4 h-4 text-blue-600" />
                  <span>Real-Time Logistics & Cold-Chain Route</span>
                </h3>
                <TrackingMap distribution={data.distribution} />
              </div>
            )}

            {/* Immutable Blockchain Ledger Certificate Proof */}
            <div className="bg-stone-900 text-stone-200 p-6 rounded-3xl border border-stone-800 space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                <div className="flex items-center gap-2">
                  <LinkIcon className="w-5 h-5 text-amber-400" />
                  <h3 className="font-bold text-sm font-mono text-amber-400 uppercase tracking-wider">
                    SHA-256 Blockchain Ledger Proof
                  </h3>
                </div>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2.5 py-0.5 rounded-full border border-emerald-800">
                  Consensus Verified
                </span>
              </div>

              <div className="space-y-2.5 text-xs font-mono">
                {data.blockchain.blocks.map((block: any) => (
                  <div key={block.index} className="p-3 bg-stone-950/80 rounded-xl border border-stone-800 space-y-1">
                    <div className="flex items-center justify-between text-stone-400 text-[11px]">
                      <span className="text-amber-400 font-bold">Block #{block.index}</span>
                      <span>Action: {block.transaction.action}</span>
                      <span>{new Date(block.timestamp).toLocaleString()}</span>
                    </div>
                    <div className="truncate text-stone-300 text-[10px]">
                      Block SHA-256: <span className="text-emerald-400">{block.hash}</span>
                    </div>
                    <div className="truncate text-stone-500 text-[10px]">
                      Previous Hash: {block.previousHash}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
