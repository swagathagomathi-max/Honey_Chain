import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { HoneyBatch, InspectionRecord, QualityGrade } from '../types';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Award,
  FileCheck,
  TestTube,
  Droplets,
  Calendar,
  Layers,
  Info
} from 'lucide-react';

interface InspectionModuleProps {
  onSelectBatch?: (id: string) => void;
}

export const InspectionModule: React.FC<InspectionModuleProps> = ({ onSelectBatch }) => {
  const { user } = useAuth();
  const [batches, setBatches] = useState<HoneyBatch[]>([]);
  const [inspections, setInspections] = useState<InspectionRecord[]>([]);
  const [selectedBatchId, setSelectedBatchId] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [successBanner, setSuccessBanner] = useState<string | null>(null);

  // Form State
  const [inspectionDate, setInspectionDate] = useState(new Date().toISOString().slice(0, 10));
  const [moisturePercentage, setMoisturePercentage] = useState('16.8');
  const [phLevel, setPhLevel] = useState('3.92');
  const [colorPfund, setColorPfund] = useState('Light Amber (42mm Pfund Scale)');
  const [aroma, setAroma] = useState('Fragrant floral nectar, zero fermentation odor');
  const [taste, setTaste] = useState('Velvety smooth, natural fructose balance, pure lingering finish');
  const [purityTestResult, setPurityTestResult] = useState('100% Pure Floral Honey (HMF 8.4 mg/kg, Diastase 18.2 DN)');
  const [adulterationTestResult, setAdulterationTestResult] = useState('PASSED (Negative for C4/C3 Sugars, HFCS & Inverted Syrups)');
  const [microbialTestResult, setMicrobialTestResult] = useState('SAFE (Total yeast & mold < 10 CFU/g, Zero pathogenic spores)');
  const [qualityGrade, setQualityGrade] = useState<QualityGrade>('A');
  const [inspectionResult, setInspectionResult] = useState<'PASSED' | 'FAILED' | 'PENDING'>('PASSED');
  const [remarks, setRemarks] = useState('Meets Codex Alimentarius Standard 12-1981 and USDA Grade A specifications.');

  const fetchData = async () => {
    setLoading(true);
    try {
      const allBatches = await api.getBatches();
      setBatches(allBatches);

      // Eligible batches are PROCESSED or HARVESTED awaiting inspection
      const eligible = allBatches.filter(b => b.status === 'PROCESSED' || b.status === 'HARVESTED');
      if (eligible.length > 0 && !selectedBatchId) {
        setSelectedBatchId(eligible[0].id);
        setMoisturePercentage(eligible[0].moisturePercentage.toString());
      }

      const allInspections = await api.getInspections();
      setInspections(allInspections);
    } catch (err) {
      console.error('Failed to load inspections:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleBatchSelect = (bId: string) => {
    setSelectedBatchId(bId);
    const b = batches.find(item => item.id === bId);
    if (b) {
      setMoisturePercentage(b.moisturePercentage.toString());
    }
  };

  const handleSubmitInspection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBatchId) return;

    setSubmitting(true);
    try {
      const res = await api.submitInspection({
        batchId: selectedBatchId,
        inspectionDate,
        moisturePercentage: parseFloat(moisturePercentage),
        phLevel: parseFloat(phLevel),
        colorPfund,
        aroma,
        taste,
        purityTestResult,
        adulterationTestResult,
        microbialTestResult,
        qualityGrade,
        inspectionResult,
        remarks,
      });

      setSuccessBanner(
        `Batch ${selectedBatchId} inspected! Certificate ${res.inspectionRecord.certificateNumber} issued with Grade ${qualityGrade}. Mined Blockchain Block #${res.blockchainBlock.index}.`
      );
      fetchData();
    } catch (err: any) {
      alert('Error submitting inspection: ' + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const eligibleBatches = batches.filter(b => b.status === 'PROCESSED' || b.status === 'HARVESTED');
  const activeBatch = batches.find(b => b.id === selectedBatchId);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-800 bg-emerald-100 font-bold px-2.5 py-0.5 rounded-full">
              ISO 17025 Quality Laboratory
            </span>
            <span className="text-xs text-stone-500">
              {eligibleBatches.length} Batches Ready for Lab Testing
            </span>
          </div>
          <h1 className="text-2xl font-black font-['Outfit'] text-stone-900">
            Honey Quality Certification & Lab Testing
          </h1>
          <p className="text-xs text-stone-500">
            Enforce Codex Alimentarius purity tests, C4 adulteration screening, pH analysis, and digital certificate generation.
          </p>
        </div>
      </div>

      {successBanner && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <span>{successBanner}</span>
          </div>
          <button onClick={() => setSuccessBanner(null)} className="font-mono text-xs opacity-60 hover:opacity-100">
            Dismiss
          </button>
        </div>
      )}

      {/* Main Grid: Left Form, Right Recent Certificates */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Inspection Form */}
        <div className="lg:col-span-2 bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100">
            <h3 className="font-bold text-sm text-stone-900 font-['Outfit'] flex items-center gap-2">
              <TestTube className="w-4 h-4 text-emerald-600" />
              <span>Perform Laboratory Quality Assay</span>
            </h3>
            <span className="text-[11px] font-mono text-stone-400">
              Inspector: <strong className="text-stone-800">{user?.name}</strong>
            </span>
          </div>

          {eligibleBatches.length === 0 ? (
            <div className="p-8 text-center bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
              <p className="font-bold text-stone-700 text-xs">No batches currently pending inspection.</p>
              <p className="text-[11px] text-stone-500">
                Processed batches will automatically queue here for lab moisture, purity, and adulteration testing.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmitInspection} className="space-y-4">
              {/* Batch Selector */}
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                  Select Honey Batch to Inspect *
                </label>
                <select
                  value={selectedBatchId}
                  onChange={(e) => handleBatchSelect(e.target.value)}
                  required
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white font-mono font-semibold"
                >
                  {eligibleBatches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.id} — {b.honeyType} ({b.quantity}kg) • Status: {b.status} • Apiary: {b.apiaryName}
                    </option>
                  ))}
                </select>
              </div>

              {activeBatch && (
                <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200 text-xs text-stone-700 grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <div><strong>Beekeeper:</strong> {activeBatch.beekeeperName}</div>
                  <div><strong>Floral Source:</strong> {activeBatch.floralSource}</div>
                  <div><strong>Harvest Moisture:</strong> {activeBatch.moisturePercentage}%</div>
                  <div><strong>Location:</strong> {activeBatch.location}</div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {/* Inspection Date */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Inspection Date</label>
                  <input
                    type="date"
                    required
                    value={inspectionDate}
                    onChange={(e) => setInspectionDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                {/* Moisture Percentage */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Moisture Percentage (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={moisturePercentage}
                    onChange={(e) => setMoisturePercentage(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
                  />
                  <span className="text-[10px] text-stone-400 mt-0.5 block">Grade A standard: ≤ 17.5%</span>
                </div>

                {/* pH Level */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">pH Level</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={phLevel}
                    onChange={(e) => setPhLevel(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
                  />
                  <span className="text-[10px] text-stone-400 mt-0.5 block">Standard: 3.4 – 4.5</span>
                </div>

                {/* Color */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Color (Pfund Scale)</label>
                  <input
                    type="text"
                    required
                    value={colorPfund}
                    onChange={(e) => setColorPfund(e.target.value)}
                    placeholder="e.g. Light Amber (42mm)"
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                {/* Aroma */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Aroma Evaluation</label>
                  <input
                    type="text"
                    required
                    value={aroma}
                    onChange={(e) => setAroma(e.target.value)}
                    placeholder="e.g. Clean, floral nectar bouquet"
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                {/* Taste */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Taste Profile</label>
                  <input
                    type="text"
                    required
                    value={taste}
                    onChange={(e) => setTaste(e.target.value)}
                    placeholder="e.g. Smooth, natural sweetness"
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Lab Assays */}
              <div className="space-y-3 pt-2">
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Purity Test & Diastase Activity</label>
                  <input
                    type="text"
                    required
                    value={purityTestResult}
                    onChange={(e) => setPurityTestResult(e.target.value)}
                    placeholder="e.g. 100% Pure Floral Honey (HMF < 15 mg/kg, Diastase > 8 DN)"
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Adulteration Screening (C4/C3 Sugars)</label>
                  <input
                    type="text"
                    required
                    value={adulterationTestResult}
                    onChange={(e) => setAdulterationTestResult(e.target.value)}
                    placeholder="e.g. PASSED (Negative for added syrups or beet/corn sugar)"
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Microbial Safety Test</label>
                  <input
                    type="text"
                    required
                    value={microbialTestResult}
                    onChange={(e) => setMicrobialTestResult(e.target.value)}
                    placeholder="e.g. SAFE (Zero pathogenic bacteria, yeasts within standard limits)"
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                  />
                </div>
              </div>

              {/* Grade & Result */}
              <div className="grid grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Assigned Quality Grade *</label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['A', 'B', 'C'] as QualityGrade[]).map((g) => (
                      <button
                        key={g}
                        type="button"
                        onClick={() => setQualityGrade(g)}
                        className={`py-2 rounded-xl text-xs font-bold transition-all ${
                          qualityGrade === g
                            ? 'bg-emerald-600 text-white shadow-sm ring-2 ring-emerald-400'
                            : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                        }`}
                      >
                        Grade {g}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Inspection Verdict *</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setInspectionResult('PASSED')}
                      className={`py-2 rounded-xl text-xs font-bold transition-all ${
                        inspectionResult === 'PASSED'
                          ? 'bg-emerald-600 text-white shadow-sm'
                          : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                      }`}
                    >
                      PASSED ✓
                    </button>
                    <button
                      type="button"
                      onClick={() => setInspectionResult('FAILED')}
                      className={`py-2 rounded-xl text-xs font-bold transition-all ${
                        inspectionResult === 'FAILED'
                          ? 'bg-rose-600 text-white shadow-sm'
                          : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                      }`}
                    >
                      FAILED ✕
                    </button>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Official Remarks</label>
                <textarea
                  rows={2}
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="flex justify-end pt-3">
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition-all disabled:opacity-50"
                >
                  {submitting ? 'Generating Digital Certificate...' : 'Issue Certificate & Commit to Blockchain'}
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Recent Quality Certificates */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-stone-100">
            <h3 className="font-bold text-sm text-stone-900 font-['Outfit']">
              Quality Certificates ({inspections.length})
            </h3>
            <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full font-bold">
              ISO 17025
            </span>
          </div>

          <div className="space-y-3 max-h-[500px] overflow-y-auto">
            {inspections.map((insp) => (
              <div
                key={insp.id}
                onClick={() => onSelectBatch && onSelectBatch(insp.batchId)}
                className="p-4 rounded-2xl bg-stone-50 hover:bg-emerald-50/50 border border-stone-200 hover:border-emerald-200 transition-all cursor-pointer text-xs space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    insp.inspectionResult === 'PASSED' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                  }`}>
                    {insp.inspectionResult} • Grade {insp.qualityGrade}
                  </span>
                  <span className="text-[10px] font-mono text-stone-400">{insp.inspectionDate}</span>
                </div>

                <div>
                  <span className="font-mono font-bold text-stone-900 block">{insp.batchId}</span>
                  <span className="text-[10px] font-mono text-emerald-700 font-semibold block">
                    Cert: {insp.certificateNumber}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-1 text-[11px] text-stone-500 font-mono">
                  <span>Moisture: {insp.moisturePercentage}%</span>
                  <span>pH: {insp.phLevel}</span>
                </div>

                <p className="text-[11px] text-stone-600 line-clamp-1 italic">
                  "{insp.remarks}"
                </p>

                <div className="pt-1.5 border-t border-stone-200/60 flex items-center justify-between text-[10px] text-stone-400">
                  <span>Inspector: {insp.inspectorName}</span>
                  <span className="text-emerald-600 font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" /> Blockchain Certified
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
