import React, { useState } from 'react';
import { useAuth, DEMO_CREDENTIALS } from '../context/AuthContext';
import { HoneyChainLogo } from '../components/HoneyChainLogo';
import { Role } from '../types';
import { ShieldCheck, Lock, Mail, User, Building, MapPin, Phone, ArrowRight, CheckCircle } from 'lucide-react';

export const AuthPage: React.FC = () => {
  const { login, register, quickDemoLogin, isLoading } = useAuth();
  const [isRegister, setIsRegister] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<Role>('BEEKEEPER');
  const [organization, setOrganization] = useState('');
  const [location, setLocation] = useState('');
  const [phone, setPhone] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      if (isRegister) {
        await register({
          name,
          email,
          password,
          role,
          organization,
          location,
          phone,
        });
      } else {
        await login(email, password);
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFFDF7] via-[#FFF9ED] to-[#FEF3C7] flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      {/* Brand Header */}
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="flex justify-center mb-2">
          <HoneyChainLogo size="lg" showSubtitle={true} />
        </div>
        <p className="mt-2 text-xs font-mono text-stone-600 uppercase tracking-widest font-semibold">
          Blockchain Honey Traceability & Smart Beekeeping Protocol
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-4xl px-4">
        {/* Quick Demo Credentials Bar (Requested in spec) */}
        <div className="mb-6 p-5 rounded-3xl bg-white border border-amber-200/80 shadow-md shadow-amber-900/5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <h3 className="text-xs font-bold font-mono uppercase tracking-wider text-amber-900">
                1-Click Demo Accounts (Test All 6 Roles)
              </h3>
            </div>
            <span className="text-[11px] text-stone-500 hidden sm:inline">
              Click any account below for instant full-access login:
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
            {(Object.keys(DEMO_CREDENTIALS) as Role[]).map((r) => {
              const demo = DEMO_CREDENTIALS[r];
              return (
                <button
                  key={r}
                  type="button"
                  onClick={() => quickDemoLogin(r)}
                  disabled={isLoading}
                  className="p-2.5 rounded-2xl bg-amber-50/80 hover:bg-amber-100/90 border border-amber-200/90 text-left transition-all hover:scale-105 active:scale-95 group focus:outline-none focus:ring-2 focus:ring-amber-400"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xl">{demo.icon}</span>
                    <span className="text-[9px] font-mono font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-amber-200/80 text-amber-950">
                      {r.replace('_', ' ')}
                    </span>
                  </div>
                  <div className="font-bold text-xs text-stone-900 truncate group-hover:text-amber-800">
                    {demo.title.split(' ')[0]}
                  </div>
                  <div className="text-[10px] text-stone-500 font-mono truncate">
                    {demo.email}
                  </div>
                  <div className="mt-1 text-[9px] text-amber-700/80 font-medium">
                    Pass: {demo.pass}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Main Card */}
        <div className="bg-white py-8 px-6 sm:px-10 shadow-xl rounded-3xl border border-stone-200/80 max-w-md mx-auto">
          {/* Toggle */}
          <div className="flex rounded-xl bg-stone-100 p-1 mb-6">
            <button
              type="button"
              onClick={() => { setIsRegister(false); setError(null); }}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                !isRegister ? 'bg-white text-stone-900 shadow-sm' : 'text-stone-500 hover:text-stone-900'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => { setIsRegister(true); setError(null); }}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                isRegister ? 'bg-white text-stone-900 shadow-sm' : 'text-stone-500 hover:text-stone-900'
              }`}
            >
              Register Account
            </button>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {isRegister && (
              <>
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Full Name</label>
                  <div className="relative">
                    <User className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Darius Thorne"
                      className="w-full pl-9 pr-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Select Role</label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value as Role)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
                  >
                    <option value="BEEKEEPER">Beekeeper / Harvester</option>
                    <option value="PROCESSOR">Honey Processor</option>
                    <option value="QUALITY_INSPECTOR">Quality Inspector</option>
                    <option value="DISTRIBUTOR">Distributor / Logistics</option>
                    <option value="CUSTOMER">Customer / Buyer</option>
                    <option value="ADMIN">System Administrator</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Organization</label>
                    <input
                      type="text"
                      value={organization}
                      onChange={(e) => setOrganization(e.target.value)}
                      placeholder="Apiary or Company"
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Location</label>
                    <input
                      type="text"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      placeholder="City, State/Country"
                      className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@honeychain.io"
                  className="w-full pl-9 pr-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full mt-4 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-500/25 active:scale-95 disabled:opacity-50"
            >
              {isLoading ? (
                'Processing...'
              ) : isRegister ? (
                <>
                  <span>Create Account</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              ) : (
                <>
                  <span>Sign In to Honey Chain</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-stone-100 text-center">
            <span className="text-[11px] text-stone-400">
              Secured with SHA-256 Ledger & Role-Based Access Control
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
