import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { DashboardMetrics, DashboardCharts, User, HoneyBatch, ProcessingRecord, InspectionRecord, DistributionRecord, Product, AuditLog } from '../types';
import {
  Users,
  Sprout,
  Layers,
  PackageCheck,
  Link as LinkIcon,
  ShieldAlert,
  Truck,
  CheckCircle2,
  RefreshCw,
  Search,
  ShieldCheck,
  FileText,
  Download,
  AlertTriangle,
  Award,
  ChevronRight,
  TrendingUp,
  BarChart3,
  PieChart
} from 'lucide-react';

interface AdminDashboardProps {
  onSelectBatch?: (id: string) => void;
  onOpenProductQR?: (product: Product) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onSelectBatch, onOpenProductQR }) => {
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [charts, setCharts] = useState<DashboardCharts | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'users' | 'batches' | 'inspections' | 'gi_tags' | 'audit_logs'>('overview');

  // Management data lists
  const [usersList, setUsersList] = useState<User[]>([]);
  const [batchesList, setBatchesList] = useState<HoneyBatch[]>([]);
  const [auditLogsList, setAuditLogsList] = useState<AuditLog[]>([]);
  const [searchUser, setSearchUser] = useState('');
  const [verifyingChain, setVerifyingChain] = useState(false);
  const [chainAuditResult, setChainAuditResult] = useState<any>(null);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const stats = await api.getDashboardStats();
      setMetrics(stats.metrics);
      setCharts(stats.charts);

      const users = await api.getUsers();
      setUsersList(users);

      const batches = await api.getBatches();
      setBatchesList(batches);

      const logs = await api.getAuditLogs();
      setAuditLogsList(logs);
    } catch (err) {
      console.error('Failed to load admin dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const handleVerifyGiTag = async (userId: string, currentStatus: boolean) => {
    try {
      const updated = await api.verifyGiTag(userId, !currentStatus);
      setUsersList(prev => prev.map(u => u.id === userId ? { ...u, giTagVerified: updated.giTagVerified } : u));
    } catch (err) {
      console.error('Failed to update GI tag status:', err);
    }
  };

  const handleVerifyBlockchain = async () => {
    setVerifyingChain(true);
    try {
      const res = await api.verifyBlockchainChain();
      setChainAuditResult(res);
    } catch (err) {
      console.error('Failed to audit chain:', err);
    } finally {
      setVerifyingChain(false);
    }
  };

  const exportSystemReport = () => {
    const reportData = {
      generatedAt: new Date().toISOString(),
      authority: 'Honey Chain International Traceability Administration',
      metrics,
      totalUsers: usersList.length,
      totalBatches: batchesList.length,
      recentBatches: batchesList.slice(0, 5),
    };
    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `HONEY-CHAIN-AUDIT-REPORT-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs font-mono text-stone-500">Loading Honey Chain Protocol Analytics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Admin Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono uppercase tracking-wider text-amber-700 bg-amber-100 font-bold px-2 py-0.5 rounded-full">
              System Administration
            </span>
            <span className="text-xs text-stone-500">Node: Local Authority Protocol v2.0</span>
          </div>
          <h1 className="text-2xl font-black font-['Outfit'] text-stone-900 mt-1">
            Traceability & Quality Command Center
          </h1>
          <p className="text-xs text-stone-500">
            Real-time telemetry, cryptographic verification, and smart beekeeping governance.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleVerifyBlockchain}
            disabled={verifyingChain}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-amber-400 font-mono text-xs font-bold transition-all shadow-sm"
          >
            <ShieldCheck className={`w-4 h-4 ${verifyingChain ? 'animate-spin' : ''}`} />
            <span>{verifyingChain ? 'Auditing Ledger...' : 'Audit Blockchain'}</span>
          </button>

          <button
            onClick={exportSystemReport}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-xs font-bold transition-colors"
          >
            <Download className="w-4 h-4 text-amber-700" />
            <span>Export Report</span>
          </button>

          <button
            onClick={fetchDashboardData}
            className="p-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors"
            title="Refresh Metrics"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Blockchain Audit Result Banner */}
      {chainAuditResult && (
        <div className={`p-4 rounded-2xl border transition-all ${
          chainAuditResult.isValid
            ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
            : 'bg-rose-50 border-rose-300 text-rose-950'
        }`}>
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-emerald-600 mt-0.5" />
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider font-mono">
                  Blockchain Cryptographic Integrity: {chainAuditResult.isValid ? '100% INTACT & SECURE' : 'COMPROMISED'}
                </h4>
                <p className="text-xs mt-0.5">
                  Verified all {chainAuditResult.totalBlocks} blocks in sequence. SHA-256 parent hash pointers match with zero tampering.
                </p>
              </div>
            </div>
            <button
              onClick={() => setChainAuditResult(null)}
              className="text-xs opacity-60 hover:opacity-100 font-mono"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* 8 Primary KPI Metric Cards (as requested) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        {/* 1. Total Users */}
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm">
          <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-2">
            <Users className="w-4 h-4" />
          </div>
          <span className="text-[10px] font-mono text-stone-500 uppercase font-semibold block truncate">Total Users</span>
          <span className="text-xl font-black font-['Outfit'] text-stone-900">{metrics?.totalUsers || 0}</span>
        </div>

        {/* 2. Total Beekeepers */}
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm">
          <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-2">
            <Sprout className="w-4 h-4" />
          </div>
          <span className="text-[10px] font-mono text-stone-500 uppercase font-semibold block truncate">Beekeepers</span>
          <span className="text-xl font-black font-['Outfit'] text-stone-900">{metrics?.totalBeekeepers || 0}</span>
        </div>

        {/* 3. Total Batches */}
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm">
          <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center mb-2">
            <Layers className="w-4 h-4" />
          </div>
          <span className="text-[10px] font-mono text-stone-500 uppercase font-semibold block truncate">Honey Batches</span>
          <span className="text-xl font-black font-['Outfit'] text-stone-900">{metrics?.totalBatches || 0}</span>
        </div>

        {/* 4. Total Products */}
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm">
          <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center mb-2">
            <PackageCheck className="w-4 h-4" />
          </div>
          <span className="text-[10px] font-mono text-stone-500 uppercase font-semibold block truncate">Total Products</span>
          <span className="text-xl font-black font-['Outfit'] text-stone-900">{metrics?.totalProducts || 0}</span>
        </div>

        {/* 5. Total Blockchain Transactions */}
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm">
          <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-2">
            <LinkIcon className="w-4 h-4" />
          </div>
          <span className="text-[10px] font-mono text-stone-500 uppercase font-semibold block truncate">Blockchain TXs</span>
          <span className="text-xl font-black font-['Outfit'] text-stone-900">{metrics?.totalBlockchainTransactions || 0}</span>
        </div>

        {/* 6. Pending Quality Inspections */}
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm">
          <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center mb-2">
            <ShieldAlert className="w-4 h-4" />
          </div>
          <span className="text-[10px] font-mono text-stone-500 uppercase font-semibold block truncate">Pending Insp.</span>
          <span className="text-xl font-black font-['Outfit'] text-rose-600">{metrics?.pendingQualityInspections || 0}</span>
        </div>

        {/* 7. Delivered Batches */}
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm">
          <div className="w-8 h-8 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center mb-2">
            <Truck className="w-4 h-4" />
          </div>
          <span className="text-[10px] font-mono text-stone-500 uppercase font-semibold block truncate">Delivered</span>
          <span className="text-xl font-black font-['Outfit'] text-stone-900">{metrics?.deliveredBatches || 0}</span>
        </div>

        {/* 8. Verified Products */}
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm">
          <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-2">
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <span className="text-[10px] font-mono text-stone-500 uppercase font-semibold block truncate">Verified QRs</span>
          <span className="text-xl font-black font-['Outfit'] text-emerald-700">{metrics?.verifiedProducts || 0}</span>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex border-b border-stone-200 gap-2 overflow-x-auto">
        {[
          { id: 'overview', label: 'Analytics & Charts', icon: BarChart3 },
          { id: 'users', label: 'User Management', icon: Users },
          { id: 'batches', label: 'All Batches', icon: Layers },
          { id: 'gi_tags', label: 'Harvester GI Tags', icon: Award },
          { id: 'audit_logs', label: 'Audit Trail Logs', icon: FileText },
        ].map((tab) => {
          const Icon = tab.icon;
          const isAct = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-3 text-xs font-bold border-b-2 transition-all whitespace-nowrap ${
                isAct
                  ? 'border-amber-500 text-amber-900 bg-amber-50/50'
                  : 'border-transparent text-stone-500 hover:text-stone-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB CONTENT 1: OVERVIEW & 4 CHARTS */}
      {activeSubTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Chart 1: Honey Production by Month */}
            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-bold text-sm text-stone-900 font-['Outfit']">Honey Production by Month</h3>
                  <span className="text-xs text-stone-500">Cumulative harvest output (kg)</span>
                </div>
                <span className="text-xs font-mono font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-lg">
                  Output (KG)
                </span>
              </div>

              {/* Bar Chart Visualization */}
              <div className="h-56 flex items-end justify-between gap-3 pt-6 pb-2 px-2 border-b border-stone-100">
                {charts?.monthlyProduction.map((item, i) => {
                  const maxKg = Math.max(...charts.monthlyProduction.map(m => m.quantityKg), 1000);
                  const heightPercent = Math.max(12, Math.round((item.quantityKg / maxKg) * 100));

                  return (
                    <div key={item.month} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                      <span className="text-[10px] font-mono font-bold text-stone-700 opacity-0 group-hover:opacity-100 transition-opacity">
                        {item.quantityKg}kg
                      </span>
                      <div
                        style={{ height: `${heightPercent}%` }}
                        className="w-full max-w-[42px] rounded-t-xl bg-gradient-to-t from-amber-600 via-amber-500 to-amber-400 group-hover:from-amber-700 group-hover:to-amber-500 transition-all shadow-sm"
                      />
                      <span className="text-[10px] font-medium text-stone-500 truncate w-full text-center">
                        {item.month.split(' ')[0]}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Chart 2: Batches by Lifecycle Status */}
            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-bold text-sm text-stone-900 font-['Outfit']">Honey Batches by Status</h3>
                  <span className="text-xs text-stone-500">Current position across supply chain</span>
                </div>
                <span className="text-xs font-mono font-bold text-stone-700 bg-stone-100 px-2 py-0.5 rounded-lg">
                  {batchesList.length} Batches
                </span>
              </div>

              <div className="space-y-3 pt-2">
                {charts?.batchesByStatus.map((item) => {
                  const total = batchesList.length || 1;
                  const pct = Math.round((item.count / total) * 100);

                  const statusColorMap: Record<string, string> = {
                    HARVESTED: 'bg-amber-500',
                    PROCESSED: 'bg-purple-500',
                    INSPECTED_PASSED: 'bg-emerald-500',
                    INSPECTED_FAILED: 'bg-rose-500',
                    PACKAGED: 'bg-blue-500',
                    COMPLETED: 'bg-stone-700',
                  };

                  return (
                    <div key={item.status} className="space-y-1">
                      <div className="flex items-center justify-between text-xs font-medium">
                        <span className="text-stone-700 font-mono text-[11px] font-semibold">{item.status.replace('_', ' ')}</span>
                        <span className="text-stone-500 font-mono">{item.count} batches ({pct}%)</span>
                      </div>
                      <div className="w-full h-3 rounded-full bg-stone-100 overflow-hidden">
                        <div
                          style={{ width: `${pct}%` }}
                          className={`h-full rounded-full transition-all ${statusColorMap[item.status] || 'bg-amber-500'}`}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Chart 3: Honey Production by Floral Type */}
            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-bold text-sm text-stone-900 font-['Outfit']">Honey Output by Floral Source</h3>
                  <span className="text-xs text-stone-500">Breakdown of botanical variety harvested</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                {charts?.productionByHoneyType.map((item) => (
                  <div key={item.honeyType} className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200/80">
                    <span className="text-[10px] font-mono text-stone-500 font-bold uppercase block">{item.honeyType} Honey</span>
                    <span className="text-lg font-bold text-stone-900 font-['Outfit']">{item.quantityKg} kg</span>
                    <span className="text-[10px] text-amber-700 font-semibold block mt-0.5">Verified Origin</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Chart 4: Quality Inspection Results */}
            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-bold text-sm text-stone-900 font-['Outfit']">ISO 17025 Quality Inspection Analytics</h3>
                  <span className="text-xs text-stone-500">Laboratory certification pass rate and grade distribution</span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-center">
                  <span className="text-2xl font-black text-emerald-800 font-['Outfit'] block">
                    {charts?.inspectionResults.gradeA || 0}
                  </span>
                  <span className="text-xs font-bold text-emerald-900 mt-1 block">Grade A Premium</span>
                  <span className="text-[10px] text-emerald-700">Moisture &lt; 17.5%</span>
                </div>

                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-center">
                  <span className="text-2xl font-black text-amber-800 font-['Outfit'] block">
                    {charts?.inspectionResults.gradeB || 0}
                  </span>
                  <span className="text-xs font-bold text-amber-900 mt-1 block">Grade B Standard</span>
                  <span className="text-[10px] text-amber-700">Moisture 17.5-19%</span>
                </div>

                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 text-center">
                  <span className="text-2xl font-black text-stone-800 font-['Outfit'] block">
                    {charts?.inspectionResults.gradeC || 0}
                  </span>
                  <span className="text-xs font-bold text-stone-700 mt-1 block">Grade C Commercial</span>
                  <span className="text-[10px] text-stone-500">Industrial batch</span>
                </div>
              </div>

              <div className="mt-4 p-3 rounded-2xl bg-stone-50 border border-stone-200 flex items-center justify-between text-xs">
                <span className="font-semibold text-stone-700">Pass / Fail Ratio:</span>
                <div className="flex items-center gap-3 font-mono font-bold">
                  <span className="text-emerald-700">{charts?.inspectionResults.passed || 0} Passed</span>
                  <span className="text-rose-600">{charts?.inspectionResults.failed || 0} Failed</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT 2: USER MANAGEMENT */}
      {activeSubTab === 'users' && (
        <div className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-stone-200 flex items-center justify-between gap-3">
            <h3 className="font-bold text-sm text-stone-900">Registered System Users ({usersList.length})</h3>
            <input
              type="text"
              placeholder="Search by name, role, email..."
              value={searchUser}
              onChange={(e) => setSearchUser(e.target.value)}
              className="px-3 py-1.5 text-xs border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 w-64"
            />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 font-mono text-[11px] uppercase">
                <tr>
                  <th className="py-3 px-4">User</th>
                  <th className="py-3 px-4">Role</th>
                  <th className="py-3 px-4">Organization & Location</th>
                  <th className="py-3 px-4">GI Tag Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {usersList
                  .filter(u =>
                    u.name.toLowerCase().includes(searchUser.toLowerCase()) ||
                    u.email.toLowerCase().includes(searchUser.toLowerCase()) ||
                    u.role.toLowerCase().includes(searchUser.toLowerCase())
                  )
                  .map((u) => (
                    <tr key={u.id} className="hover:bg-stone-50">
                      <td className="py-3 px-4">
                        <div className="font-bold text-stone-900">{u.name}</div>
                        <div className="text-[11px] text-stone-400 font-mono">{u.email}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase bg-stone-100 text-stone-700">
                          {u.role.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-stone-600">
                        <div>{u.organization || 'Independent'}</div>
                        <div className="text-[11px] text-stone-400">{u.location || 'N/A'}</div>
                      </td>
                      <td className="py-3 px-4">
                        {u.hasGiTag ? (
                          <div className="flex items-center gap-1.5">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              u.giTagVerified ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                            }`}>
                              {u.giTagVerified ? 'Verified GI Tag' : 'Pending Verification'}
                            </span>
                            <span className="text-[11px] text-stone-500 font-mono truncate max-w-[140px]" title={u.giTagName}>
                              {u.giTagName}
                            </span>
                          </div>
                        ) : (
                          <span className="text-stone-400 text-[11px]">No GI Tag Submitted</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right">
                        {u.hasGiTag && (
                          <button
                            onClick={() => handleVerifyGiTag(u.id, !!u.giTagVerified)}
                            className={`px-3 py-1 rounded-xl text-[11px] font-bold transition-colors ${
                              u.giTagVerified
                                ? 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                                : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                            }`}
                          >
                            {u.giTagVerified ? 'Revoke GI' : 'Verify GI Tag'}
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB CONTENT 3: ALL BATCHES */}
      {activeSubTab === 'batches' && (
        <div className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-stone-200">
            <h3 className="font-bold text-sm text-stone-900">Full Honey Batch Inventory</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 font-mono text-[11px] uppercase">
                <tr>
                  <th className="py-3 px-4">Batch ID</th>
                  <th className="py-3 px-4">Type & Floral</th>
                  <th className="py-3 px-4">Beekeeper</th>
                  <th className="py-3 px-4">Quantity</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Provenance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {batchesList.map((b) => (
                  <tr key={b.id} className="hover:bg-stone-50">
                    <td className="py-3 px-4 font-mono font-bold text-amber-800">{b.id}</td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-stone-900">{b.honeyType}</div>
                      <div className="text-[11px] text-stone-500">{b.floralSource}</div>
                    </td>
                    <td className="py-3 px-4 text-stone-700">{b.beekeeperName}</td>
                    <td className="py-3 px-4 font-mono">{b.quantity} kg</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-stone-100 text-stone-800">
                        {b.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => onSelectBatch && onSelectBatch(b.id)}
                        className="px-3 py-1 bg-amber-50 hover:bg-amber-100 text-amber-900 rounded-xl font-bold text-[11px]"
                      >
                        View History
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB CONTENT 4: HARVESTER GI TAGS */}
      {activeSubTab === 'gi_tags' && (
        <div className="bg-white rounded-3xl border border-stone-200 shadow-sm p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-stone-900 font-['Outfit']">
                Geographical Indication (GI Tag) Certificate Governance
              </h3>
              <p className="text-xs text-stone-500">
                Verify authentic regional honey origins to boost consumer trust and unlock premium pricing for harvesters.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {usersList.filter(u => u.hasGiTag).map((u) => (
              <div key={u.id} className="p-4 rounded-2xl border border-stone-200 bg-stone-50/50 space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-700 flex items-center justify-center font-bold">
                      🍯
                    </div>
                    <div>
                      <h4 className="font-bold text-xs text-stone-900">{u.name}</h4>
                      <span className="text-[10px] text-stone-500">{u.location}</span>
                    </div>
                  </div>

                  <span className={`px-2.5 py-0.5 text-[10px] font-bold rounded-full ${
                    u.giTagVerified ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' : 'bg-amber-100 text-amber-800 border border-amber-200'
                  }`}>
                    {u.giTagVerified ? 'Verified Active' : 'Pending Verification'}
                  </span>
                </div>

                <div className="p-3 bg-white rounded-xl border border-stone-200 text-xs space-y-1">
                  <div><strong>GI Name:</strong> {u.giTagName}</div>
                  <div><strong>Reg Number:</strong> <span className="font-mono text-stone-600">{u.giTagNumber}</span></div>
                  <div><strong>Base Price Allowed:</strong> <span className="text-emerald-700 font-bold">${u.baseCostPerKg || 35}/kg</span></div>
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => handleVerifyGiTag(u.id, !!u.giTagVerified)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                      u.giTagVerified ? 'bg-stone-200 text-stone-800' : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    }`}
                  >
                    {u.giTagVerified ? 'Revoke Verification' : 'Verify & Sign on Blockchain'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT 5: SYSTEM AUDIT LOGS */}
      {activeSubTab === 'audit_logs' && (
        <div className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-stone-200">
            <h3 className="font-bold text-sm text-stone-900">System Audit Trail</h3>
          </div>
          <div className="divide-y divide-stone-100 max-h-96 overflow-y-auto">
            {auditLogsList.map((log) => (
              <div key={log.id} className="p-3.5 hover:bg-stone-50 flex items-start justify-between text-xs gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[10px] font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded">
                      {log.action}
                    </span>
                    <span className="font-semibold text-stone-900">{log.userName}</span>
                    <span className="text-[10px] text-stone-400 font-mono">({log.role})</span>
                  </div>
                  <p className="text-stone-600 text-[11px] mt-0.5">{log.details}</p>
                </div>
                <span className="text-[10px] font-mono text-stone-400 shrink-0">
                  {new Date(log.timestamp).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
