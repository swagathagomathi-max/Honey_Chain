import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { BlockchainBlock } from '../types';
import {
  Link as LinkIcon,
  ShieldCheck,
  Search,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Hash,
  Clock,
  Layers,
  ArrowDown
} from 'lucide-react';

export const BlockchainPage: React.FC = () => {
  const [chain, setChain] = useState<BlockchainBlock[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterText, setFilterText] = useState('');
  const [auditResult, setAuditResult] = useState<any>(null);
  const [auditing, setAuditing] = useState(false);

  const fetchLedger = async () => {
    setLoading(true);
    try {
      const res = await api.getBlockchainLedger();
      setChain(res.chain);
    } catch (err) {
      console.error('Failed to load blockchain ledger:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLedger();
  }, []);

  const handleAudit = async () => {
    setAuditing(true);
    try {
      const result = await api.verifyBlockchainChain();
      setAuditResult(result);
    } catch (err) {
      console.error('Failed to audit chain:', err);
    } finally {
      setAuditing(false);
    }
  };

  const filteredBlocks = chain.filter((b) => {
    if (!filterText) return true;
    const s = filterText.toLowerCase();
    return (
      b.index.toString().includes(s) ||
      b.hash.toLowerCase().includes(s) ||
      b.previousHash.toLowerCase().includes(s) ||
      b.transaction.id.toLowerCase().includes(s) ||
      b.transaction.batchId.toLowerCase().includes(s) ||
      b.transaction.action.toLowerCase().includes(s) ||
      b.transaction.actor.name.toLowerCase().includes(s)
    );
  });

  return (
    <div className="space-y-6">
      {/* Blockchain Header */}
      <div className="bg-stone-900 text-white p-6 rounded-3xl border border-stone-800 shadow-md flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 bg-amber-950 font-bold px-2.5 py-0.5 rounded-full border border-amber-800">
              SHA-256 Private Consensus Engine
            </span>
            <span className="text-xs text-stone-400 font-mono">
              Total Blocks: <strong>{chain.length}</strong>
            </span>
          </div>
          <h1 className="text-2xl font-black font-['Outfit'] text-stone-100">
            Immutable Honey Chain Ledger Explorer
          </h1>
          <p className="text-xs text-stone-400">
            Inspect cryptographic proof of work, parent hash pointers, and tamper-evident transaction logs across the supply chain.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleAudit}
            disabled={auditing}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs uppercase tracking-wider transition-all shadow-md active:scale-95 disabled:opacity-50"
          >
            <ShieldCheck className={`w-4 h-4 ${auditing ? 'animate-spin' : ''}`} />
            <span>{auditing ? 'Auditing SHA-256 Chain...' : 'Verify Cryptographic Integrity'}</span>
          </button>

          <button
            onClick={fetchLedger}
            className="p-2.5 rounded-2xl bg-stone-800 hover:bg-stone-700 text-stone-300 transition-colors"
            title="Refresh Ledger"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Audit Banner */}
      {auditResult && (
        <div className={`p-5 rounded-3xl border transition-all ${
          auditResult.isValid
            ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-100'
            : 'bg-rose-950/80 border-rose-500/40 text-rose-100'
        }`}>
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3">
              <ShieldCheck className="w-6 h-6 text-emerald-400 mt-0.5 shrink-0" />
              <div>
                <h3 className="font-bold text-sm font-['Outfit'] text-white">
                  Cryptographic Ledger Audit: {auditResult.isValid ? '100% Valid & Intact' : 'Discrepancy Detected'}
                </h3>
                <p className="text-xs text-stone-300 mt-0.5">
                  Verified all {auditResult.totalBlocks} blocks in sequence. Recalculated SHA-256 hashes and previousHash link pointers.
                </p>
                <div className="text-[11px] font-mono text-emerald-400 mt-2">
                  ✓ Genesis to tip verified at {new Date(auditResult.verifiedAt).toLocaleTimeString()}
                </div>
              </div>
            </div>

            <button
              onClick={() => setAuditResult(null)}
              className="text-xs text-stone-400 hover:text-white font-mono"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Search Filter */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm flex items-center gap-3">
        <Search className="w-4 h-4 text-stone-400" />
        <input
          type="text"
          placeholder="Filter blocks by index, hash, transaction ID, batch ID, or actor..."
          value={filterText}
          onChange={(e) => setFilterText(e.target.value)}
          className="w-full text-xs focus:outline-none font-mono"
        />
        {filterText && (
          <button onClick={() => setFilterText('')} className="text-xs text-stone-400 hover:text-stone-700">
            Clear
          </button>
        )}
      </div>

      {/* Chain Visualizer */}
      {loading ? (
        <div className="p-12 text-center text-xs text-stone-400 font-mono">
          Querying ledger nodes...
        </div>
      ) : filteredBlocks.length === 0 ? (
        <div className="bg-white p-12 rounded-3xl border border-stone-200 text-center">
          <p className="text-xs text-stone-500 font-mono">No blocks match the filter query.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredBlocks.map((block, idx) => {
            const isGenesis = block.index === 0;

            return (
              <div key={block.index} className="space-y-4">
                <div className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden p-6 space-y-4 hover:border-amber-400 transition-colors">
                  {/* Block Header */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-stone-100">
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-2xl flex items-center justify-center font-bold text-sm ${
                        isGenesis ? 'bg-amber-500 text-stone-950 font-black' : 'bg-stone-900 text-amber-400 font-mono'
                      }`}>
                        #{block.index}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-stone-900 font-mono">
                            {isGenesis ? 'GENESIS BLOCK' : `BLOCK #${block.index}`}
                          </span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-50 text-amber-900 border border-amber-200">
                            {block.transaction.action}
                          </span>
                        </div>
                        <span className="text-[11px] font-mono text-stone-400">
                          Timestamp: {new Date(block.timestamp).toLocaleString()} • Nonce: {block.nonce}
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] font-mono text-stone-400 block uppercase">Transaction ID</span>
                      <span className="text-xs font-mono font-bold text-stone-800">{block.transaction.id}</span>
                    </div>
                  </div>

                  {/* Hash Explorer */}
                  <div className="space-y-2 text-xs font-mono bg-stone-50 p-4 rounded-2xl border border-stone-200/80">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-stone-400 block">Current Block Hash (SHA-256)</span>
                      <span className="text-emerald-700 font-bold break-all select-all">{block.hash}</span>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-stone-400 block">Previous Block Hash</span>
                      <span className="text-stone-500 break-all">{block.previousHash}</span>
                    </div>
                  </div>

                  {/* Transaction Actor & Data */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/70 space-y-1">
                      <span className="text-[10px] uppercase font-bold text-stone-400 block font-mono">Signatory Actor</span>
                      <div className="font-bold text-stone-900">{block.transaction.actor.name}</div>
                      <div className="text-[11px] text-stone-500">
                        {block.transaction.actor.role} • {block.transaction.actor.organization || 'Verified Node'}
                      </div>
                    </div>

                    <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/70 space-y-1">
                      <span className="text-[10px] uppercase font-bold text-stone-400 block font-mono">Entity Reference</span>
                      <div className="font-bold text-amber-800 font-mono">Batch: {block.transaction.batchId}</div>
                      {block.transaction.productId && (
                        <div className="text-[11px] font-mono text-stone-600">Product: {block.transaction.productId}</div>
                      )}
                      {block.transaction.trackingId && (
                        <div className="text-[11px] font-mono text-stone-600">Track: {block.transaction.trackingId}</div>
                      )}
                    </div>
                  </div>

                  {/* Data Payload Preview */}
                  <details className="text-xs group">
                    <summary className="cursor-pointer text-amber-700 font-semibold hover:underline select-none">
                      Inspect Transaction Data Payload
                    </summary>
                    <pre className="mt-2 p-3 bg-stone-900 text-amber-300 rounded-xl font-mono text-[11px] overflow-x-auto max-h-48 border border-stone-800">
                      {JSON.stringify(block.transaction.data, null, 2)}
                    </pre>
                  </details>
                </div>

                {/* Cryptographic Link Chain Indicator */}
                {idx < filteredBlocks.length - 1 && (
                  <div className="flex justify-center items-center gap-2 text-amber-600/60 font-mono text-xs">
                    <ArrowDown className="w-4 h-4 animate-bounce" />
                    <span>SHA-256 Link Connected</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
