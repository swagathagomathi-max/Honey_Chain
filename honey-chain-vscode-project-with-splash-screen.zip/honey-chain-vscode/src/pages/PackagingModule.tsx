import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { HoneyBatch, Product } from '../types';
import {
  PackageCheck,
  QrCode,
  Plus,
  ShieldCheck,
  Award,
  Layers,
  Sparkles,
  ExternalLink,
  Tag,
  CheckCircle2,
  Download
} from 'lucide-react';

interface PackagingModuleProps {
  onOpenProductQR: (product: Product) => void;
  onSelectBatch?: (id: string) => void;
  onNavigateTracking?: (trackId: string) => void;
}

export const PackagingModule: React.FC<PackagingModuleProps> = ({
  onOpenProductQR,
  onSelectBatch,
  onNavigateTracking
}) => {
  const { user } = useAuth();
  const [batches, setBatches] = useState<HoneyBatch[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showPackageModal, setShowPackageModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [successBanner, setSuccessBanner] = useState<string | null>(null);

  // Form states
  const [selectedBatchId, setSelectedBatchId] = useState('');
  const [productName, setProductName] = useState('Reserve Organic Raw Forest Mountain Honey');
  const [brandName, setBrandName] = useState('Cascade Golden Nectar');
  const [netQuantityGrams, setNetQuantityGrams] = useState('500');
  const [totalUnits, setTotalUnits] = useState('600');
  const [packagingDate, setPackagingDate] = useState(new Date().toISOString().slice(0, 10));
  const [expiryDate, setExpiryDate] = useState('2028-12-31');
  const [packageType, setPackageType] = useState('Hexagonal UV-Protected Glass Jar with Wooden Honey Dipper');
  const [mrp, setMrp] = useState('34.50');

  const fetchData = async () => {
    setLoading(true);
    try {
      const allBatches = await api.getBatches();
      setBatches(allBatches);

      // Batches eligible for packaging: status = 'INSPECTED_PASSED' or 'PROCESSED'
      const eligible = allBatches.filter(b => b.status === 'INSPECTED_PASSED' || b.status === 'PROCESSED');
      if (eligible.length > 0 && !selectedBatchId) {
        setSelectedBatchId(eligible[0].id);
        const activeB = eligible[0];
        setProductName(`${activeB.honeyType} Reserve Single-Origin Honey`);
        if (activeB.giTagVerified) {
          setMrp('38.50'); // Higher price for verified GI Tag
        }
      }

      const allProducts = await api.getProducts();
      setProducts(allProducts);
    } catch (err) {
      console.error('Failed to load packaging data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleBatchSelect = (bId: string) => {
    setSelectedBatchId(bId);
    const b = batches.find(item => item.id === bId);
    if (b) {
      setProductName(`${b.honeyType} Reserve Single-Origin Honey`);
      if (b.giTagVerified) {
        setMrp('39.00'); // Premium GI pricing
      } else {
        setMrp('28.50');
      }
    }
  };

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBatchId) return;

    setSubmitting(true);
    try {
      const res = await api.packageProduct({
        batchId: selectedBatchId,
        productName,
        brandName,
        netQuantityGrams: parseInt(netQuantityGrams, 10),
        totalUnits: parseInt(totalUnits, 10),
        packagingDate,
        expiryDate,
        packageType,
        mrp: parseFloat(mrp),
      });

      setShowPackageModal(false);
      setSuccessBanner(
        `Product ${res.product.id} created! Track ID: ${res.trackingId}. Generated high-resolution public verification QR code and committed Block #${res.blockchainBlock.index}.`
      );
      fetchData();
      onOpenProductQR(res.product);
    } catch (err: any) {
      alert('Error packaging product: ' + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const eligibleBatches = batches.filter(b => b.status === 'INSPECTED_PASSED' || b.status === 'PROCESSED');
  const activeBatch = batches.find(b => b.id === selectedBatchId);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-amber-700 bg-amber-100 font-bold px-2.5 py-0.5 rounded-full">
              Packaging & Retail Authentication
            </span>
            <span className="text-xs text-stone-500">
              {products.length} Active Consumer Honey SKUs
            </span>
          </div>
          <h1 className="text-2xl font-black font-['Outfit'] text-stone-900">
            Product Packaging & QR Minting
          </h1>
          <p className="text-xs text-stone-500">
            Transform certified honey batches into consumer retail jars. Mint unique QR verification labels and assign live Tracking IDs.
          </p>
        </div>

        <button
          onClick={() => setShowPackageModal(true)}
          disabled={eligibleBatches.length === 0}
          className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs uppercase tracking-wider transition-all shadow-md shadow-amber-500/20 active:scale-95 disabled:opacity-50"
        >
          <Plus className="w-4 h-4" />
          <span>Package Passed Batch</span>
        </button>
      </div>

      {successBanner && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <span>{successBanner}</span>
          </div>
          <button onClick={() => setSuccessBanner(null)} className="font-mono text-xs opacity-60 hover:opacity-100">
            Dismiss
          </button>
        </div>
      )}

      {/* Products Catalog */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-sm text-stone-900 font-['Outfit']">
            Packaged Honey Products ({products.length})
          </h3>
          <span className="text-xs text-stone-400">
            Every product features a unique QR code linked to the public blockchain provenance ledger.
          </span>
        </div>

        {loading ? (
          <div className="p-12 text-center text-xs text-stone-400 font-mono">
            Loading products...
          </div>
        ) : products.length === 0 ? (
          <div className="bg-white p-12 rounded-3xl border border-stone-200 text-center space-y-3">
            <p className="font-bold text-stone-700 text-sm">No packaged products created yet.</p>
            <p className="text-xs text-stone-400 max-w-sm mx-auto">
              Batches that have passed quality inspection can be packaged here into retail honey jars with QR codes.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((prod) => (
              <div
                key={prod.id}
                className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div className="p-5 space-y-3">
                  {/* Top IDs */}
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] font-mono font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200 block truncate">
                        ID: {prod.id}
                      </span>
                      <span className="text-[10px] font-mono text-stone-500 mt-1 block">
                        Track ID: <strong className="text-stone-800">{prod.trackingId}</strong>
                      </span>
                    </div>

                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                      Grade {prod.qualityGrade}
                    </span>
                  </div>

                  {/* Title & Brand */}
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 block">
                      {prod.brandName}
                    </span>
                    <h4 className="font-black text-base text-stone-900 font-['Outfit'] mt-0.5">
                      {prod.productName}
                    </h4>
                    <p className="text-xs text-stone-500">
                      {prod.honeyType} • {prod.netQuantityGrams}g Jar • {prod.totalUnits} Units Total
                    </p>
                  </div>

                  {/* Pricing and GI */}
                  <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200/80 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-stone-400 block uppercase">Retail Price</span>
                      <span className="text-lg font-black font-['Outfit'] text-stone-900">
                        ${prod.mrp.toFixed(2)}
                      </span>
                    </div>

                    {prod.harvesterGiVerified && (
                      <div className="text-right">
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 inline-flex items-center gap-1">
                          <Award className="w-3 h-3 text-emerald-600" />
                          GI Certified Premium
                        </span>
                        <span className="text-[10px] text-stone-400 block mt-0.5">Origin Protected</span>
                      </div>
                    )}
                  </div>

                  {/* Batch Link */}
                  <div className="text-xs text-stone-600 flex items-center justify-between pt-1">
                    <span>Source Batch:</span>
                    <button
                      onClick={() => onSelectBatch && onSelectBatch(prod.batchId)}
                      className="font-mono text-amber-800 font-bold hover:underline"
                    >
                      {prod.batchId}
                    </button>
                  </div>
                </div>

                {/* Bottom Card Actions */}
                <div className="p-4 bg-stone-50/80 border-t border-stone-100 flex items-center justify-between gap-2">
                  <button
                    onClick={() => onOpenProductQR(prod)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 bg-amber-500 hover:bg-amber-600 text-stone-950 rounded-xl text-xs font-bold transition-colors shadow-sm"
                  >
                    <QrCode className="w-4 h-4" />
                    <span>View QR Code</span>
                  </button>

                  {onNavigateTracking && (
                    <button
                      onClick={() => onNavigateTracking(prod.trackingId)}
                      className="py-2 px-3 bg-white hover:bg-stone-100 text-stone-700 border border-stone-200 rounded-xl text-xs font-semibold transition-colors"
                      title="Track Logistics"
                    >
                      Track Route
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* PACKAGING MODAL */}
      {showPackageModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/75 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full border border-stone-200 shadow-2xl my-8 overflow-hidden">
            <div className="p-5 bg-gradient-to-r from-amber-500 to-amber-600 text-stone-950 flex items-center justify-between">
              <div>
                <h3 className="font-black text-base font-['Outfit']">Package Honey & Mint QR Code</h3>
                <p className="text-xs text-amber-950 font-medium">
                  Create final retail product, assign unique Track ID, and generate public QR code.
                </p>
              </div>
              <button
                onClick={() => setShowPackageModal(false)}
                className="text-stone-950 font-bold text-lg hover:opacity-80"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateProduct} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                  Select Passed Batch to Package *
                </label>
                <select
                  value={selectedBatchId}
                  onChange={(e) => handleBatchSelect(e.target.value)}
                  required
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white font-mono font-semibold"
                >
                  {eligibleBatches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.id} — {b.honeyType} ({b.quantity}kg) • Grade {b.qualityGrade || 'A'} • {b.hasGiTag ? 'GI Verified' : 'Standard'}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Product Name *</label>
                <input
                  type="text"
                  required
                  value={productName}
                  onChange={(e) => setProductName(e.target.value)}
                  placeholder="e.g. Reserve Wildflower Mountain Raw Honey"
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Brand Name *</label>
                  <input
                    type="text"
                    required
                    value={brandName}
                    onChange={(e) => setBrandName(e.target.value)}
                    placeholder="e.g. Cascade Golden Nectar"
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Net Quantity (Grams)</label>
                  <input
                    type="number"
                    required
                    value={netQuantityGrams}
                    onChange={(e) => setNetQuantityGrams(e.target.value)}
                    placeholder="500"
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Total Jars / Units</label>
                  <input
                    type="number"
                    required
                    value={totalUnits}
                    onChange={(e) => setTotalUnits(e.target.value)}
                    placeholder="500"
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                    MRP / Retail Price ($)
                    {activeBatch?.giTagVerified && <span className="text-emerald-700 font-semibold ml-1">(GI Premium)</span>}
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={mrp}
                    onChange={(e) => setMrp(e.target.value)}
                    placeholder="32.50"
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-bold text-emerald-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Packaging Date</label>
                  <input
                    type="date"
                    required
                    value={packagingDate}
                    onChange={(e) => setPackagingDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Expiry Date</label>
                  <input
                    type="date"
                    required
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Package Type & Container</label>
                <input
                  type="text"
                  required
                  value={packageType}
                  onChange={(e) => setPackageType(e.target.value)}
                  placeholder="e.g. Hexagonal Glass Jar with Wooden Dipper"
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowPackageModal(false)}
                  className="px-4 py-2 bg-stone-100 rounded-xl text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-6 py-2.5 bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs uppercase tracking-wider rounded-xl shadow-md disabled:opacity-50"
                >
                  {submitting ? 'Minting QR Code...' : 'Mint Product & QR Code'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
