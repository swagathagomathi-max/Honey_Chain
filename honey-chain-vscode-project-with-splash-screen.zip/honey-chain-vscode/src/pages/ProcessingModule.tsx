import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { HoneyBatch, ProcessingRecord } from '../types';
import {
  Cpu,
  Plus,
  Layers,
  Thermometer,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileText,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';

interface ProcessingModuleProps {
  onSelectBatch?: (id: string) => void;
}

export const ProcessingModule: React.FC<ProcessingModuleProps> = ({ onSelectBatch }) => {
  const { user } = useAuth();
  const [batches, setBatches] = useState<HoneyBatch[]>([]);
  const [processingLogs, setProcessingLogs] = useState<ProcessingRecord[]>([]);
  const [selectedBatchId, setSelectedBatchId] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Form states
  const [processingDate, setProcessingDate] = useState(new Date().toISOString().slice(0, 10));
  const [facilityName, setFacilityName] = useState('PureCraft Cleanroom Extraction Lab #3');
  const [processingMethod, setProcessingMethod] = useState('Raw Cold Settling & Gentle Clarification');
  const [filtrationMethod, setFiltrationMethod] = useState('Dual 200-Micron Food-Grade Stainless Mesh');
  const [heatingTemperature, setHeatingTemperature] = useState('34.0');
  const [processingDurationMinutes, setProcessingDurationMinutes] = useState('180');
  const [quantityBeforeKg, setQuantityBeforeKg] = useState('');
  const [quantityAfterKg, setQuantityAfterKg] = useState('');
  const [storageContainer, setStorageContainer] = useState('316L Food-Grade Nitrogen-Blanketed Stainless Vat');
  const [storageTemperature, setStorageTemperature] = useState('18.0');
  const [notes, setNotes] = useState('Temperature kept strictly below 35°C to preserve active honey pollen enzymes.');

  const fetchData = async () => {
    setLoading(true);
    try {
      const allBatches = await api.getBatches();
      // Batches eligible for processing: status = 'HARVESTED'
      setBatches(allBatches);
      const eligible = allBatches.filter(b => b.status === 'HARVESTED');
      if (eligible.length > 0 && !selectedBatchId) {
        setSelectedBatchId(eligible[0].id);
        setQuantityBeforeKg(eligible[0].quantity.toString());
        setQuantityAfterKg((eligible[0].quantity * 0.99).toFixed(1));
      }

      const records = await api.getProcessingRecords();
      setProcessingLogs(records);
    } catch (err) {
      console.error('Failed to load processing data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleBatchChange = (bId: string) => {
    setSelectedBatchId(bId);
    const b = batches.find(item => item.id === bId);
    if (b) {
      setQuantityBeforeKg(b.quantity.toString());
      setQuantityAfterKg((b.quantity * 0.99).toFixed(1));
    }
  };

  const handleSubmitProcessing = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBatchId) return;

    setSubmitting(true);
    try {
      const res = await api.submitProcessing({
        batchId: selectedBatchId,
        processingDate,
        facilityName,
        processingMethod,
        filtrationMethod,
        heatingTemperature: parseFloat(heatingTemperature),
        processingDurationMinutes: parseInt(processingDurationMinutes, 10),
        quantityBeforeKg: parseFloat(quantityBeforeKg),
        quantityAfterKg: parseFloat(quantityAfterKg),
        storageContainer,
        storageTemperature: parseFloat(storageTemperature),
        notes,
      });

      setSuccessMsg(`Processing recorded for batch ${selectedBatchId}! Generated new Blockchain Block #${res.blockchainBlock.index}. Batch is now ready for Quality Inspection.`);
      fetchData();
    } catch (err: any) {
      alert('Error recording processing: ' + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const eligibleBatches = batches.filter(b => b.status === 'HARVESTED');
  const currentBatch = batches.find(b => b.id === selectedBatchId);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-purple-700 bg-purple-100 font-bold px-2.5 py-0.5 rounded-full">
              Honey Processing Facility
            </span>
            <span className="text-xs text-stone-500">
              {eligibleBatches.length} Batches Awaiting Processing
            </span>
          </div>
          <h1 className="text-2xl font-black font-['Outfit'] text-stone-900">
            Cold Extraction & Clarification Module
          </h1>
          <p className="text-xs text-stone-500">
            Log processing parameters, monitor temperature thresholds, calculate yield, and append cryptographic processing blocks.
          </p>
        </div>
      </div>

      {successMsg && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <span>{successMsg}</span>
          </div>
          <button onClick={() => setSuccessMsg(null)} className="font-mono text-xs opacity-60 hover:opacity-100">
            Dismiss
          </button>
        </div>
      )}

      {/* Main Grid: Left Processing Form, Right Batches & History */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Processing Form */}
        <div className="lg:col-span-2 bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100">
            <h3 className="font-bold text-sm text-stone-900 font-['Outfit'] flex items-center gap-2">
              <Cpu className="w-4 h-4 text-purple-600" />
              <span>Record Processing Run</span>
            </h3>
            <span className="text-[11px] font-mono text-stone-400">
              Processor: <strong className="text-stone-800">{user?.name}</strong>
            </span>
          </div>

          {eligibleBatches.length === 0 ? (
            <div className="p-8 text-center bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
              <p className="font-bold text-stone-700 text-xs">No batches currently awaiting processing.</p>
              <p className="text-[11px] text-stone-500">
                All harvested batches have either been processed or are already in subsequent supply chain stages.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmitProcessing} className="space-y-4">
              {/* Batch Selector */}
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                  Select Harvested Honey Batch *
                </label>
                <select
                  value={selectedBatchId}
                  onChange={(e) => handleBatchChange(e.target.value)}
                  required
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white font-mono font-semibold"
                >
                  {eligibleBatches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.id} — {b.honeyType} ({b.quantity}kg) by {b.beekeeperName} [{b.location}]
                    </option>
                  ))}
                </select>
              </div>

              {currentBatch && (
                <div className="p-3 rounded-2xl bg-amber-50/70 border border-amber-200 text-xs text-amber-900 grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <div><strong>Apiary:</strong> {currentBatch.apiaryName}</div>
                  <div><strong>Harvest Date:</strong> {currentBatch.harvestDate}</div>
                  <div><strong>Harvest Moisture:</strong> {currentBatch.moisturePercentage}%</div>
                  <div><strong>GI Status:</strong> {currentBatch.giTagVerified ? 'Verified' : 'Standard'}</div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Processing Date */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Processing Date</label>
                  <input
                    type="date"
                    required
                    value={processingDate}
                    onChange={(e) => setProcessingDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                {/* Facility Name */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Processing Facility</label>
                  <input
                    type="text"
                    required
                    value={facilityName}
                    onChange={(e) => setFacilityName(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                {/* Processing Method */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Processing Method</label>
                  <input
                    type="text"
                    required
                    value={processingMethod}
                    onChange={(e) => setProcessingMethod(e.target.value)}
                    placeholder="e.g. Raw Cold Settling & Gentle Clarification"
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                {/* Filtration Method */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Filtration Method</label>
                  <input
                    type="text"
                    required
                    value={filtrationMethod}
                    onChange={(e) => setFiltrationMethod(e.target.value)}
                    placeholder="e.g. Dual 200-Micron Mesh"
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                {/* Heating Temperature */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                    Heating Temperature (°C)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={heatingTemperature}
                    onChange={(e) => setHeatingTemperature(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 font-bold text-stone-800"
                  />
                  <span className="text-[10px] text-stone-400 mt-0.5 block">
                    Ideal raw honey temperature: &lt; 35.0°C
                  </span>
                </div>

                {/* Processing Duration */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Duration (Minutes)</label>
                  <input
                    type="number"
                    required
                    min="10"
                    value={processingDurationMinutes}
                    onChange={(e) => setProcessingDurationMinutes(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                {/* Quantity Before */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Quantity Before (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={quantityBeforeKg}
                    onChange={(e) => setQuantityBeforeKg(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl font-bold bg-stone-50"
                  />
                </div>

                {/* Quantity After */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Quantity After (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={quantityAfterKg}
                    onChange={(e) => setQuantityAfterKg(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl font-bold text-emerald-700"
                  />
                  <span className="text-[10px] text-stone-400 mt-0.5 block">
                    Tracks extraction yield & micro-clarification loss
                  </span>
                </div>

                {/* Storage Container */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Storage Container</label>
                  <input
                    type="text"
                    required
                    value={storageContainer}
                    onChange={(e) => setStorageContainer(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                {/* Storage Temperature */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Storage Temperature (°C)</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={storageTemperature}
                    onChange={(e) => setStorageTemperature(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 font-bold"
                  />
                </div>

                {/* Notes */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Processing Notes</label>
                  <textarea
                    rows={2}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-3">
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-6 py-2.5 bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition-all disabled:opacity-50"
                >
                  {submitting ? 'Generating Blockchain Block...' : 'Save Processing & Commit Block'}
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Processing Logs History */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-stone-100">
            <h3 className="font-bold text-sm text-stone-900 font-['Outfit']">
              Processing History ({processingLogs.length})
            </h3>
            <span className="text-[10px] font-mono text-purple-700 bg-purple-50 px-2 py-0.5 rounded-full font-bold">
              Cleanroom Log
            </span>
          </div>

          <div className="space-y-3 max-h-[500px] overflow-y-auto">
            {processingLogs.map((p) => (
              <div
                key={p.id}
                onClick={() => onSelectBatch && onSelectBatch(p.batchId)}
                className="p-3.5 rounded-2xl bg-stone-50 hover:bg-purple-50/50 border border-stone-200 hover:border-purple-200 transition-all cursor-pointer text-xs space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-purple-900">{p.batchId}</span>
                  <span className="text-[10px] font-mono text-stone-400">{p.processingDate}</span>
                </div>
                <div className="font-semibold text-stone-800 truncate">{p.facilityName}</div>
                <div className="flex items-center justify-between text-[11px] text-stone-500 font-mono">
                  <span>Temp: {p.heatingTemperature}°C</span>
                  <span>Yield: {p.quantityAfterKg}kg</span>
                </div>
                <div className="flex items-center justify-between pt-1 border-t border-stone-200/60 text-[10px] text-stone-400">
                  <span>By: {p.processorName}</span>
                  <span className="text-emerald-600 font-bold flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" /> Blockchain Verified
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
