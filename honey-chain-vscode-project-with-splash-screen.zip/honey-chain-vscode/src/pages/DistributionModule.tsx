import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { DistributionRecord, TransportStatus } from '../types';
import { TrackingMap } from '../components/TrackingMap';
import {
  Truck,
  MapPin,
  Calendar,
  Thermometer,
  ShieldCheck,
  Plus,
  Navigation,
  CheckCircle2,
  Clock,
  Radio,
  Search
} from 'lucide-react';

interface DistributionModuleProps {
  initialTrackId?: string;
}

export const DistributionModule: React.FC<DistributionModuleProps> = ({ initialTrackId }) => {
  const { user } = useAuth();
  const [distributions, setDistributions] = useState<DistributionRecord[]>([]);
  const [selectedRecord, setSelectedRecord] = useState<DistributionRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [successBanner, setSuccessBanner] = useState<string | null>(null);
  const [searchTrackId, setSearchTrackId] = useState(initialTrackId || '');

  // Update Checkpoint Form State
  const [newStatus, setNewStatus] = useState<TransportStatus>('IN_TRANSIT');
  const [carrierName, setCarrierName] = useState('AeroCold Climate Fleet #EV-99');
  const [storageTemperature, setStorageTemperature] = useState('16.5');
  const [checkpointLocation, setCheckpointLocation] = useState('Sacramento Logistics Gate #4, CA');
  const [checkpointLat, setCheckpointLat] = useState('38.5816');
  const [checkpointLng, setCheckpointLng] = useState('-121.4944');
  const [checkpointNote, setCheckpointNote] = useState('Seal intact. Cold chain temperature verified at 16.5°C.');

  const fetchDistributions = async () => {
    setLoading(true);
    try {
      const records = await api.getDistributions();
      setDistributions(records);

      if (initialTrackId) {
        const found = records.find(r => r.trackingId.toLowerCase() === initialTrackId.toLowerCase());
        if (found) {
          setSelectedRecord(found);
        } else if (records.length > 0) {
          setSelectedRecord(records[0]);
        }
      } else if (records.length > 0 && !selectedRecord) {
        setSelectedRecord(records[0]);
      }
    } catch (err) {
      console.error('Failed to load distribution records:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDistributions();
  }, [initialTrackId]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchTrackId.trim()) return;
    const match = distributions.find(d =>
      d.trackingId.toLowerCase() === searchTrackId.trim().toLowerCase() ||
      d.productId.toLowerCase() === searchTrackId.trim().toLowerCase()
    );
    if (match) {
      setSelectedRecord(match);
    } else {
      alert(`No shipment found matching "${searchTrackId}".`);
    }
  };

  const handleUpdateStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRecord) return;

    setSubmitting(true);
    try {
      const res = await api.updateDistribution({
        trackingId: selectedRecord.trackingId,
        distributorName: user?.name || 'AeroCold Logistics',
        carrierName,
        transportStatus: newStatus,
        storageTemperature: parseFloat(storageTemperature),
        checkpointLocation,
        checkpointLat: parseFloat(checkpointLat),
        checkpointLng: parseFloat(checkpointLng),
        checkpointNote,
        actualDeliveryDate: newStatus === 'DELIVERED' ? new Date().toISOString().slice(0, 10) : undefined
      });

      setSelectedRecord(res.distribution);
      setShowUpdateModal(false);
      setSuccessBanner(
        `Tracking ID ${selectedRecord.trackingId} updated to ${newStatus}! Mined new Blockchain Block #${res.blockchainBlock.index}.`
      );
      fetchDistributions();
    } catch (err: any) {
      alert('Error updating logistics checkpoint: ' + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const statusBadge: Record<TransportStatus, string> = {
    PREPARING: 'bg-amber-100 text-amber-900 border-amber-300',
    IN_TRANSIT: 'bg-blue-100 text-blue-900 border-blue-300',
    DELIVERED: 'bg-emerald-100 text-emerald-900 border-emerald-300',
    DELAYED: 'bg-rose-100 text-rose-900 border-rose-300',
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-blue-700 bg-blue-100 font-bold px-2.5 py-0.5 rounded-full">
              Cold-Chain Logistics & IoT Tracking
            </span>
            <span className="text-xs text-stone-500">
              {distributions.length} Active Shipments Tracked
            </span>
          </div>
          <h1 className="text-2xl font-black font-['Outfit'] text-stone-900">
            Distribution & Route Telemetry
          </h1>
          <p className="text-xs text-stone-500">
            Real-time GPS tracking from harvest packing to delivery. Integrated with Mapbox coordinates engine and SHA-256 ledger.
          </p>
        </div>

        {/* Track ID Lookup Form */}
        <form onSubmit={handleSearch} className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search Track ID (e.g. HC-TRK-77401)..."
              value={searchTrackId}
              onChange={(e) => setSearchTrackId(e.target.value)}
              className="pl-9 pr-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono w-64"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs rounded-xl"
          >
            Locate
          </button>
        </form>
      </div>

      {successBanner && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <span>{successBanner}</span>
          </div>
          <button onClick={() => setSuccessBanner(null)} className="font-mono text-xs opacity-60 hover:opacity-100">
            Dismiss
          </button>
        </div>
      )}

      {/* Main Layout: Left Map & Live Tracking, Right Shipment List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Selected Shipment Details & Interactive Map */}
        <div className="lg:col-span-2 space-y-6">
          {selectedRecord ? (
            <>
              {/* Mapbox Route Visualization */}
              <TrackingMap distribution={selectedRecord} />

              {/* Shipment Details & Actions */}
              <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-stone-100">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400 block font-bold">
                      Distribution Record
                    </span>
                    <h3 className="text-lg font-bold text-stone-900 font-['Outfit']">
                      Track ID: <span className="font-mono text-amber-700">{selectedRecord.trackingId}</span>
                    </h3>
                  </div>

                  {/* Log Checkpoint Button (for Distributor or Admin) */}
                  {(user?.role === 'ADMIN' || user?.role === 'DISTRIBUTOR') && (
                    <button
                      onClick={() => {
                        setNewStatus(selectedRecord.transportStatus);
                        setShowUpdateModal(true);
                      }}
                      className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-colors shadow-sm"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Log Waypoint / Update Status</span>
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-stone-50 border border-stone-200/80">
                    <span className="text-[10px] text-stone-400 block uppercase font-mono">Origin</span>
                    <span className="font-bold text-stone-800 truncate block">{selectedRecord.sourceLocation}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-stone-50 border border-stone-200/80">
                    <span className="text-[10px] text-stone-400 block uppercase font-mono">Destination</span>
                    <span className="font-bold text-stone-800 truncate block">{selectedRecord.destinationLocation}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-stone-50 border border-stone-200/80">
                    <span className="text-[10px] text-stone-400 block uppercase font-mono">Storage Temp</span>
                    <span className="font-bold text-emerald-700 block font-mono">{selectedRecord.storageTemperature}°C</span>
                  </div>
                  <div className="p-3 rounded-xl bg-stone-50 border border-stone-200/80">
                    <span className="text-[10px] text-stone-400 block uppercase font-mono">Total Units</span>
                    <span className="font-bold text-stone-800 block font-mono">{selectedRecord.quantityUnits} Jars</span>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="bg-white p-12 rounded-3xl border border-stone-200 text-center">
              <p className="text-xs text-stone-500 font-mono">Select a shipment to view live GPS tracking route.</p>
            </div>
          )}
        </div>

        {/* Right 1 Col: Shipments List */}
        <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-stone-100">
            <h3 className="font-bold text-sm text-stone-900 font-['Outfit'] flex items-center gap-2">
              <Truck className="w-4 h-4 text-blue-600" />
              <span>Active Shipments ({distributions.length})</span>
            </h3>
            <span className="text-[10px] font-mono text-stone-400">Real-Time</span>
          </div>

          <div className="space-y-2.5 max-h-[600px] overflow-y-auto">
            {distributions.map((dist) => {
              const isSelected = selectedRecord?.id === dist.id;

              return (
                <div
                  key={dist.id}
                  onClick={() => setSelectedRecord(dist)}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer text-xs space-y-2 ${
                    isSelected
                      ? 'bg-blue-50/70 border-blue-300 ring-2 ring-blue-400/20 shadow-sm'
                      : 'bg-stone-50 hover:bg-stone-100/70 border-stone-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-stone-900">{dist.trackingId}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase border ${statusBadge[dist.transportStatus]}`}>
                      {dist.transportStatus.replace('_', ' ')}
                    </span>
                  </div>

                  <div className="text-[11px] text-stone-600 space-y-0.5">
                    <div className="truncate"><strong>From:</strong> {dist.sourceLocation.split(',')[0]}</div>
                    <div className="truncate"><strong>To:</strong> {dist.destinationLocation.split(',')[0]}</div>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-stone-200/60 text-[10px] text-stone-400 font-mono">
                    <span>Carrier: {dist.carrierName.split(' ')[0]}</span>
                    <span>{dist.storageTemperature}°C</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* UPDATE CHECKPOINT MODAL */}
      {showUpdateModal && selectedRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/75 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full border border-stone-200 shadow-2xl my-8 overflow-hidden">
            <div className="p-5 bg-gradient-to-r from-blue-600 to-blue-700 text-white flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm font-['Outfit']">Log Transit Checkpoint & Update Status</h3>
                <p className="text-xs text-blue-100">
                  Appends GPS coordinates to route and commits transaction to Blockchain.
                </p>
              </div>
              <button onClick={() => setShowUpdateModal(false)} className="text-white hover:opacity-80">✕</button>
            </div>

            <form onSubmit={handleUpdateStatus} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                  Logistics Transport Status *
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(['PREPARING', 'IN_TRANSIT', 'DELIVERED', 'DELAYED'] as TransportStatus[]).map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => setNewStatus(st)}
                      className={`py-2 rounded-xl text-xs font-bold transition-all ${
                        newStatus === st
                          ? 'bg-blue-600 text-white shadow-sm ring-2 ring-blue-400'
                          : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                      }`}
                    >
                      {st.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Checkpoint Location Name</label>
                <input
                  type="text"
                  required
                  value={checkpointLocation}
                  onChange={(e) => setCheckpointLocation(e.target.value)}
                  placeholder="e.g. Portland Agri-Corridor Logistics Gate"
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">GPS Latitude</label>
                  <input
                    type="number"
                    step="0.0001"
                    required
                    value={checkpointLat}
                    onChange={(e) => setCheckpointLat(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">GPS Longitude</label>
                  <input
                    type="number"
                    step="0.0001"
                    required
                    value={checkpointLng}
                    onChange={(e) => setCheckpointLng(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Carrier Fleet</label>
                  <input
                    type="text"
                    required
                    value={carrierName}
                    onChange={(e) => setCarrierName(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Cargo Storage Temp (°C)</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={storageTemperature}
                    onChange={(e) => setStorageTemperature(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Telemetry Notes</label>
                <textarea
                  rows={2}
                  value={checkpointNote}
                  onChange={(e) => setCheckpointNote(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowUpdateModal(false)}
                  className="px-4 py-2 bg-stone-100 rounded-xl text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md disabled:opacity-50"
                >
                  {submitting ? 'Mining Waypoint Block...' : 'Commit Checkpoint to Blockchain'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
