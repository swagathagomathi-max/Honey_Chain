import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  User as UserIcon,
  ShieldCheck,
  Award,
  Building,
  MapPin,
  Phone,
  Mail,
  DollarSign,
  CheckCircle,
  FileText,
  Upload
} from 'lucide-react';

export const UserProfilePage: React.FC = () => {
  const { user, updateProfile } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [organization, setOrganization] = useState(user?.organization || '');
  const [location, setLocation] = useState(user?.location || '');
  const [baseCostPerKg, setBaseCostPerKg] = useState(user?.baseCostPerKg ? user.baseCostPerKg.toString() : '35.0');

  // GI Tag State
  const [hasGiTag, setHasGiTag] = useState(user?.hasGiTag || false);
  const [giTagName, setGiTagName] = useState(user?.giTagName || '');
  const [giTagNumber, setGiTagNumber] = useState(user?.giTagNumber || '');
  const [giTagCertificateUrl, setGiTagCertificateUrl] = useState(user?.giTagCertificateUrl || '');

  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSuccessMsg(null);
    try {
      await updateProfile({
        name,
        phone,
        organization,
        location,
        baseCostPerKg: parseFloat(baseCostPerKg),
        hasGiTag,
        giTagName,
        giTagNumber,
        giTagCertificateUrl,
      });
      setSuccessMsg('Profile and Geographical Indication records updated successfully!');
    } catch (err: any) {
      alert('Failed to update profile: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-600 text-stone-950 font-black text-2xl flex items-center justify-center shadow-md">
            {user?.name ? user.name[0] : 'U'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold font-['Outfit'] text-stone-900">{user?.name}</h1>
              {user?.giTagVerified && (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  GI Certified Origin
                </span>
              )}
            </div>
            <p className="text-xs text-stone-500 font-mono mt-0.5">{user?.email}</p>
            <div className="mt-1 text-[10px] font-mono font-bold uppercase tracking-wider text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md inline-block">
              Role: {user?.role.replace('_', ' ')}
            </div>
          </div>
        </div>
      </div>

      {successMsg && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Main Form */}
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-6">
        <div>
          <h3 className="font-bold text-sm text-stone-900 pb-2 border-b border-stone-100">
            Account Details & Organization
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Phone Number</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Organization / Apiary</label>
              <input
                type="text"
                value={organization}
                onChange={(e) => setOrganization(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Geographic Location</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>
        </div>

        {/* Harvester Pricing & GI Tag Certificate Section */}
        <div className="pt-2">
          <div className="flex items-center justify-between pb-2 border-b border-stone-100">
            <div>
              <h3 className="font-bold text-sm text-stone-900 flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-600" />
                <span>Geographical Indication (GI Tag) & Product Pricing</span>
              </h3>
              <p className="text-xs text-stone-500">
                Harvesters with a certified GI Tag can submit their registration number and certificate document here.
              </p>
            </div>
          </div>

          <div className="space-y-4 mt-4">
            <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-stone-50 border border-stone-200">
              <input
                type="checkbox"
                id="giCheckbox"
                checked={hasGiTag}
                onChange={(e) => setHasGiTag(e.target.checked)}
                className="w-4 h-4 text-amber-600 rounded border-stone-300 focus:ring-amber-500"
              />
              <label htmlFor="giCheckbox" className="text-xs text-stone-800 font-semibold cursor-pointer select-none">
                I hold an official Geographical Indication (GI) Certificate for my honey harvest region
              </label>
            </div>

            {hasGiTag && (
              <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-amber-900 uppercase mb-1">GI Reserve Name</label>
                    <input
                      type="text"
                      required={hasGiTag}
                      value={giTagName}
                      onChange={(e) => setGiTagName(e.target.value)}
                      placeholder="e.g. Pacific Northwest Wildflower Forest Reserve"
                      className="w-full px-3 py-2 text-xs border border-amber-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-amber-900 uppercase mb-1">GI Registration Number</label>
                    <input
                      type="text"
                      required={hasGiTag}
                      value={giTagNumber}
                      onChange={(e) => setGiTagNumber(e.target.value)}
                      placeholder="e.g. GI-USA-WA-2024-0089"
                      className="w-full px-3 py-2 text-xs border border-amber-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-amber-900 uppercase mb-1">
                    Official Certificate File URL
                  </label>
                  <input
                    type="text"
                    value={giTagCertificateUrl}
                    onChange={(e) => setGiTagCertificateUrl(e.target.value)}
                    placeholder="https://honeychain.io/certificates/GI-USA-WA-2024-0089.pdf"
                    className="w-full px-3 py-2 text-xs border border-amber-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
                  />
                  <span className="text-[10px] text-amber-800/80 mt-1 block">
                    Certificate will be stored in database and reviewed by System Administrators.
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-amber-900 uppercase mb-1">
                    Base Harvest Price ($/kg)
                    <span className="text-emerald-700 font-semibold ml-1">
                      (GI Certified harvesters can increase their product cost)
                    </span>
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={baseCostPerKg}
                    onChange={(e) => setBaseCostPerKg(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-amber-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white font-bold text-emerald-800"
                  />
                </div>

                <div className="p-3 rounded-xl bg-white border border-amber-200 text-xs flex items-center justify-between">
                  <span className="text-stone-600 font-medium">Verification Status:</span>
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                    user?.giTagVerified ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {user?.giTagVerified ? 'Verified Active (Badge Displayed)' : 'Pending Verification by Admin'}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end pt-3">
          <button
            type="submit"
            disabled={saving}
            className="px-6 py-2.5 bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition-all disabled:opacity-50"
          >
            {saving ? 'Saving...' : 'Save Profile Changes'}
          </button>
        </div>
      </form>
    </div>
  );
};
