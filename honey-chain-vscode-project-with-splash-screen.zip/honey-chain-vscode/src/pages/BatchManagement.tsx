import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { HoneyBatch, BatchStatus, HoneyType } from '../types';
import {
  Layers,
  Search,
  Filter,
  Calendar,
  MapPin,
  ShieldCheck,
  Award,
  ChevronRight,
  ExternalLink,
  Droplets,
  Sparkles
} from 'lucide-react';

interface BatchManagementProps {
  onSelectBatch: (id: string) => void;
}

export const BatchManagement: React.FC<BatchManagementProps> = ({ onSelectBatch }) => {
  const [batches, setBatches] = useState<HoneyBatch[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [typeFilter, setTypeFilter] = useState<string>('ALL');

  const fetchBatches = async () => {
    setLoading(true);
    try {
      const data = await api.getBatches({
        status: statusFilter !== 'ALL' ? statusFilter : undefined,
        honeyType: typeFilter !== 'ALL' ? typeFilter : undefined,
        search: searchTerm || undefined,
      });
      setBatches(data);
    } catch (err) {
      console.error('Failed to load batches:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBatches();
  }, [statusFilter, typeFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchBatches();
  };

  const statusBadgeColor: Record<string, string> = {
    HARVESTED: 'bg-amber-100 text-amber-900 border-amber-300',
    PROCESSING: 'bg-indigo-100 text-indigo-900 border-indigo-300',
    PROCESSED: 'bg-purple-100 text-purple-900 border-purple-300',
    INSPECTED_PASSED: 'bg-emerald-100 text-emerald-900 border-emerald-300',
    INSPECTED_FAILED: 'bg-rose-100 text-rose-900 border-rose-300',
    PACKAGED: 'bg-blue-100 text-blue-900 border-blue-300',
    COMPLETED: 'bg-stone-200 text-stone-900 border-stone-300',
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-amber-700 bg-amber-100 font-bold px-2.5 py-0.5 rounded-full">
              Full Supply Chain Registry
            </span>
            <span className="text-xs text-stone-500">
              {batches.length} Verified Batches in Database
            </span>
          </div>
          <h1 className="text-2xl font-black font-['Outfit'] text-stone-900">
            Honey Batch Management
          </h1>
          <p className="text-xs text-stone-500">
            Browse all honey batches, check lab quality grades, inspect origin credentials, and trace complete blockchain history.
          </p>
        </div>

        {/* Search bar */}
        <form onSubmit={handleSearchSubmit} className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search batch ID, floral source, location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 pr-3 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 w-64 sm:w-80"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold rounded-xl"
          >
            Search
          </button>
        </form>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 font-bold text-stone-700">
            <Filter className="w-4 h-4 text-amber-600" />
            <span>Filter By:</span>
          </div>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 border border-stone-200 rounded-xl bg-stone-50 text-stone-700 font-semibold focus:outline-none"
          >
            <option value="ALL">All Statuses</option>
            <option value="HARVESTED">Harvested</option>
            <option value="PROCESSED">Processed</option>
            <option value="INSPECTED_PASSED">Inspected (Passed)</option>
            <option value="INSPECTED_FAILED">Inspected (Failed)</option>
            <option value="PACKAGED">Packaged</option>
            <option value="COMPLETED">Delivered</option>
          </select>

          {/* Honey Type Filter */}
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-3 py-1.5 border border-stone-200 rounded-xl bg-stone-50 text-stone-700 font-semibold focus:outline-none"
          >
            <option value="ALL">All Honey Types</option>
            <option value="Wildflower">Wildflower</option>
            <option value="Acacia">Acacia</option>
            <option value="Eucalyptus">Eucalyptus</option>
            <option value="Mustard">Mustard</option>
            <option value="Multifloral">Multifloral</option>
            <option value="Sidr">Sidr</option>
            <option value="Lavender">Lavender</option>
            <option value="Clover">Clover</option>
          </select>
        </div>

        <span className="text-[11px] font-mono text-stone-400">
          Click any batch to inspect end-to-end provenance timeline
        </span>
      </div>

      {/* Batches Grid */}
      {loading ? (
        <div className="p-12 text-center text-xs text-stone-400 font-mono">
          Querying batch inventory...
        </div>
      ) : batches.length === 0 ? (
        <div className="bg-white p-12 rounded-3xl border border-stone-200 text-center space-y-2">
          <p className="font-bold text-stone-700 text-sm">No batches match the selected criteria.</p>
          <p className="text-xs text-stone-400">Try adjusting your search query or reset the filters.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {batches.map((batch) => (
            <div
              key={batch.id}
              onClick={() => onSelectBatch(batch.id)}
              className="bg-white p-5 rounded-3xl border border-stone-200/90 shadow-sm hover:shadow-md hover:border-amber-300 transition-all cursor-pointer flex flex-col justify-between group"
            >
              <div>
                {/* Header row */}
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div>
                    <span className="text-[10px] font-mono font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200 block truncate max-w-[190px]">
                      {batch.id}
                    </span>
                    <span className="text-[10px] text-stone-400 font-mono mt-0.5 block">
                      Harvested: {batch.harvestDate}
                    </span>
                  </div>

                  <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full uppercase border shrink-0 ${statusBadgeColor[batch.status] || 'bg-stone-100'}`}>
                    {batch.status.replace('_', ' ')}
                  </span>
                </div>

                {/* Title & Floral */}
                <h3 className="font-black text-base text-stone-900 font-['Outfit'] group-hover:text-amber-800 transition-colors">
                  {batch.honeyType} Honey
                </h3>
                <p className="text-xs text-stone-500 line-clamp-1 mt-0.5">
                  {batch.floralSource}
                </p>

                {/* Metrics pill */}
                <div className="grid grid-cols-3 gap-2 mt-4 p-2.5 rounded-2xl bg-stone-50 text-center text-xs">
                  <div>
                    <span className="text-[10px] text-stone-400 block">Quantity</span>
                    <span className="font-bold text-stone-800 font-mono">{batch.quantity} kg</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-stone-400 block">Moisture</span>
                    <span className="font-bold text-stone-800 font-mono">{batch.moisturePercentage}%</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-stone-400 block">Quality</span>
                    <span className="font-bold text-emerald-700">
                      {batch.qualityGrade ? `Grade ${batch.qualityGrade}` : 'Pending'}
                    </span>
                  </div>
                </div>

                {/* Harvester line */}
                <div className="mt-3 flex items-center justify-between text-xs text-stone-600">
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="text-amber-600 font-bold">🐝</span>
                    <span className="font-semibold truncate">{batch.beekeeperName}</span>
                  </div>

                  {batch.hasGiTag && (
                    <span className="px-1.5 py-0.5 text-[9px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 rounded flex items-center gap-1 shrink-0">
                      <Award className="w-3 h-3 text-emerald-600" />
                      GI Tag
                    </span>
                  )}
                </div>

                <div className="mt-1 flex items-center gap-1 text-[11px] text-stone-400 truncate">
                  <MapPin className="w-3 h-3 text-stone-400 shrink-0" />
                  <span className="truncate">{batch.location}</span>
                </div>
              </div>

              {/* Bottom Blockchain Proof Tag */}
              <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between text-xs">
                <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md flex items-center gap-1 font-semibold">
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                  Blockchain Mined
                </span>

                <span className="text-amber-800 font-bold text-xs flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  View Timeline <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
