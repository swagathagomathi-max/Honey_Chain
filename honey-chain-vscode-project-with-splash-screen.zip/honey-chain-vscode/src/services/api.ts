import {
  User,
  HoneyBatch,
  ProcessingRecord,
  InspectionRecord,
  Product,
  DistributionRecord,
  NotificationItem,
  BlockchainBlock,
  DashboardMetrics,
  DashboardCharts,
  AuditLog
} from '../types';

const TOKEN_KEY = 'honeychain_jwt_token';

export const getStoredToken = (): string | null => {
  return localStorage.getItem(TOKEN_KEY);
};

export const setStoredToken = (token: string): void => {
  localStorage.setItem(TOKEN_KEY, token);
};

export const removeStoredToken = (): void => {
  localStorage.removeItem(TOKEN_KEY);
};

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  if (!response.ok) {
    let errorMsg = 'Network request failed';
    try {
      const errJson = await response.json();
      errorMsg = errJson.error || errJson.message || errorMsg;
    } catch {
      errorMsg = `Server error ${response.status}: ${response.statusText}`;
    }
    throw new Error(errorMsg);
  }

  return response.json();
}

export const api = {
  // Auth
  login: (credentials: { email: string; password: string }) =>
    request<{ token: string; user: User }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    }),

  register: (data: Partial<User> & { password: string }) =>
    request<{ token: string; user: User }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getMe: () => request<User>('/api/auth/me'),

  updateProfile: (data: any) =>
    request<User>('/api/users/profile', {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  getUsers: () => request<User[]>('/api/users'),

  verifyGiTag: (userId: string, verified: boolean) =>
    request<User>(`/api/users/${userId}/verify-gi`, {
      method: 'POST',
      body: JSON.stringify({ verified }),
    }),

  // Harvests & Batches
  getBatches: (filters?: { status?: string; honeyType?: string; beekeeperId?: string; search?: string }) => {
    const params = new URLSearchParams();
    if (filters?.status) params.append('status', filters.status);
    if (filters?.honeyType) params.append('honeyType', filters.honeyType);
    if (filters?.beekeeperId) params.append('beekeeperId', filters.beekeeperId);
    if (filters?.search) params.append('search', filters.search);
    const qs = params.toString() ? `?${params.toString()}` : '';
    return request<HoneyBatch[]>(`/api/harvests${qs}`);
  },

  createHarvest: (data: any) =>
    request<{ batch: HoneyBatch; blockchainBlock: BlockchainBlock }>('/api/harvests', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getBatchDetails: (id: string) =>
    request<{
      batch: HoneyBatch;
      processingRecords: ProcessingRecord[];
      inspectionRecords: InspectionRecord[];
      products: Product[];
      distributionRecords: DistributionRecord[];
      blockchainBlocks: BlockchainBlock[];
    }>(`/api/batches/${id}`),

  // Processing
  getProcessingRecords: () => request<ProcessingRecord[]>('/api/processing'),

  submitProcessing: (data: any) =>
    request<{ processingRecord: ProcessingRecord; blockchainBlock: BlockchainBlock }>('/api/processing', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // Inspections
  getInspections: () => request<InspectionRecord[]>('/api/inspections'),

  submitInspection: (data: any) =>
    request<{ inspectionRecord: InspectionRecord; blockchainBlock: BlockchainBlock }>('/api/inspections', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // Products & Packaging
  getProducts: () => request<Product[]>('/api/products'),

  packageProduct: (data: any) =>
    request<{ product: Product; trackingId: string; blockchainBlock: BlockchainBlock }>('/api/products', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // Distribution & Tracking
  getDistributions: () => request<DistributionRecord[]>('/api/distribution'),

  trackShipment: (trackingId: string) =>
    request<{
      distribution: DistributionRecord;
      product?: Product;
      batch?: HoneyBatch;
      blockchainBlocks: BlockchainBlock[];
    }>(`/api/distribution/track/${trackingId}`),

  updateDistribution: (data: any) =>
    request<{ distribution: DistributionRecord; blockchainBlock: BlockchainBlock }>('/api/distribution/update', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // Public Verification (QR code lookup)
  verifyCode: (code: string) =>
    request<{
      verified: boolean;
      authenticityScore: number;
      product: Product | null;
      batch: HoneyBatch | null;
      harvester: any;
      processing: ProcessingRecord[];
      inspection: InspectionRecord[];
      distribution: DistributionRecord | null;
      blockchain: {
        blocks: BlockchainBlock[];
        totalBlocksInChain: number;
        isChainIntact: boolean;
        hashAlgorithm: string;
      };
    }>(`/api/verify/${encodeURIComponent(code)}`),

  // Blockchain Ledger & Verification
  getBlockchainLedger: () =>
    request<{ chain: BlockchainBlock[]; length: number; latestBlock: BlockchainBlock }>('/api/blockchain/ledger'),

  verifyBlockchainChain: () =>
    request<{ isValid: boolean; totalBlocks: number; errors: string[]; verifiedAt: string }>('/api/blockchain/verify'),

  // Notifications
  getNotifications: () => request<NotificationItem[]>('/api/notifications'),

  markNotificationAsRead: (id: string) =>
    request<{ success: boolean }>(`/api/notifications/${id}/read`, { method: 'PATCH' }),

  markAllNotificationsAsRead: () =>
    request<{ success: boolean }>('/api/notifications/read-all', { method: 'POST' }),

  // Dashboard Stats
  getDashboardStats: () =>
    request<{
      metrics: DashboardMetrics;
      charts: DashboardCharts;
    }>('/api/stats/dashboard'),

  getAuditLogs: () => request<AuditLog[]>('/api/audit-logs'),
};
