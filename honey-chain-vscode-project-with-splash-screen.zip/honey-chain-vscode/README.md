# Honey Chain — VS Code Setup

Honey Chain is a React + Vite frontend with an Express/TypeScript API and WebSocket server.

## Requirements
- **Node.js 22 LTS** (recommended; Node 20.19+ may also work with the installed Vite version)
- **Visual Studio Code**
- Internet access for the first dependency installation

## Open and run in VS Code (Windows)
1. Extract this ZIP file to a normal folder, for example `Documents\\honey-chain`.
2. Open VS Code.
3. Select **File → Open Folder…** and choose the extracted `honey-chain` folder (the folder containing `package.json`).
4. Open **Terminal → New Terminal**.
5. Check Node.js and npm are installed:
   ```powershell
   node -v
   npm -v
   ```
6. Install the project dependencies (first time only):
   ```powershell
   npm install
   ```
7. Start the full app:
   ```powershell
   npm run dev
   ```
8. Open **http://localhost:3000** in your browser. Keep the terminal running while using the app.
9. To stop it, click the terminal and press **Ctrl+C**.

## Environment settings (optional)
The project has an `.env.example` file. If you need custom local settings:
1. Copy `.env.example` and name the copy `.env`.
2. Change `JWT_SECRET` to a long random local value if desired.
3. `PORT` defaults to `3000`.

Do not commit real API keys or passwords. The app is designed to run locally without configuring a Gemini key unless you specifically add Gemini-powered features.

## Useful commands
- `npm run dev` — start the API and frontend together
- `npm run build` — build the frontend for production
- `npm run start` — start the server (set `NODE_ENV=production` after building to serve the built frontend)
- `npm run lint` — run TypeScript checking

## Troubleshooting
- **`npm` is not recognized:** install Node.js LTS, then close and reopen VS Code.
- **Port 3000 is busy:** set `PORT=3001` in `.env` and restart; then open `http://localhost:3001`.
- **Dependency install fails:** check internet access and run `npm install` again.
- **Page opens but API fails:** check that the terminal still shows the server running and that you opened the correct URL.
- **Build/type-check errors:** these can be caused by dependency version or TypeScript compatibility differences; share the exact terminal error to troubleshoot.

## Project structure
- `src/` — React pages, components, context, and API client
- `server.ts` — Express server, REST API, and WebSocket server
- `server/` — local database and blockchain simulation
- `index.html` — Vite entry page
- `vite.config.ts` — Vite configuration

## Important note
This is the Google AI Studio-exported source project adapted for local VS Code use. Its blockchain/database implementation is part of this application; it does not automatically deploy a real public blockchain. Review authentication, secrets, and persistence before using it with real users or production data.
