import crypto from 'crypto';

export interface BlockchainTransaction {
  id: string;
  batchId: string;
  productId?: string;
  trackingId?: string;
  action: 'HARVEST_CREATED' | 'PROCESSING_COMPLETED' | 'QUALITY_INSPECTED' | 'PRODUCT_PACKAGED' | 'DISTRIBUTION_DISPATCHED' | 'CHECKPOINT_UPDATE' | 'DELIVERY_COMPLETED' | 'GI_TAG_VERIFIED';
  actor: {
    id: string;
    name: string;
    role: string;
    organization?: string;
  };
  timestamp: string;
  data: Record<string, any>;
  dataHash: string;
}

export interface BlockchainBlock {
  index: number;
  timestamp: string;
  transaction: BlockchainTransaction;
  previousHash: string;
  hash: string;
  nonce: number;
  merkleRoot: string;
}

export class Blockchain {
  public chain: BlockchainBlock[] = [];
  public difficulty: number = 2; // Fast proof-of-work simulation for responsive local execution

  constructor() {
    // Will be initialized with Genesis block or existing chain in db
  }

  public calculateHash(
    index: number,
    previousHash: string,
    timestamp: string,
    transactionHash: string,
    merkleRoot: string,
    nonce: number
  ): string {
    const dataString = `${index}${previousHash}${timestamp}${transactionHash}${merkleRoot}${nonce}`;
    return crypto.createHash('sha256').update(dataString).digest('hex');
  }

  public calculateDataHash(data: any): string {
    const serialized = typeof data === 'string' ? data : JSON.stringify(data);
    return crypto.createHash('sha256').update(serialized).digest('hex');
  }

  public createGenesisBlock(): BlockchainBlock {
    const genesisTx: BlockchainTransaction = {
      id: 'HC-TX-GENESIS-00000',
      batchId: 'GENESIS-BATCH',
      action: 'HARVEST_CREATED',
      actor: {
        id: 'SYS-GENESIS',
        name: 'Honey Chain Protocol',
        role: 'SYSTEM',
        organization: 'International Honey Traceability Alliance'
      },
      timestamp: new Date('2026-01-01T00:00:00Z').toISOString(),
      data: {
        message: 'Honey Chain Genesis Block - Every Drop Has a Story',
        standard: 'ISO 22000 / Codex Alimentarius Honey Standard',
        protocolVersion: '2.0.4'
      },
      dataHash: this.calculateDataHash({ message: 'Honey Chain Genesis' })
    };

    const timestamp = genesisTx.timestamp;
    const previousHash = '0000000000000000000000000000000000000000000000000000000000000000';
    const merkleRoot = this.calculateDataHash(genesisTx);
    let nonce = 0;
    let hash = this.calculateHash(0, previousHash, timestamp, genesisTx.id, merkleRoot, nonce);

    while (!hash.startsWith('00')) {
      nonce++;
      hash = this.calculateHash(0, previousHash, timestamp, genesisTx.id, merkleRoot, nonce);
    }

    return {
      index: 0,
      timestamp,
      transaction: genesisTx,
      previousHash,
      hash,
      nonce,
      merkleRoot
    };
  }

  public addBlock(transaction: BlockchainTransaction): BlockchainBlock {
    // Ensure transaction.dataHash is consistently computed from transaction.data
    transaction.dataHash = this.calculateDataHash(transaction.data);

    const previousBlock = this.chain[this.chain.length - 1];
    const index = previousBlock ? previousBlock.index + 1 : 0;
    const previousHash = previousBlock ? previousBlock.hash : '0000000000000000000000000000000000000000000000000000000000000000';
    const timestamp = new Date().toISOString();
    const merkleRoot = this.calculateDataHash(transaction);

    let nonce = 0;
    let hash = this.calculateHash(index, previousHash, timestamp, transaction.id, merkleRoot, nonce);

    // Simulated proof-of-work
    const prefix = '0'.repeat(this.difficulty);
    while (!hash.startsWith(prefix)) {
      nonce++;
      hash = this.calculateHash(index, previousHash, timestamp, transaction.id, merkleRoot, nonce);
    }

    const newBlock: BlockchainBlock = {
      index,
      timestamp,
      transaction,
      previousHash,
      hash,
      nonce,
      merkleRoot
    };

    this.chain.push(newBlock);
    return newBlock;
  }

  public verifyChain(): {
    isValid: boolean;
    totalBlocks: number;
    errors: string[];
    verifiedAt: string;
  } {
    const errors: string[] = [];

    for (let i = 1; i < this.chain.length; i++) {
      const currentBlock = this.chain[i];
      const previousBlock = this.chain[i - 1];

      // Check 1: Previous hash link
      if (currentBlock.previousHash !== previousBlock.hash) {
        errors.push(`Block #${currentBlock.index} invalid link: previousHash mismatch (Expected ${previousBlock.hash}, got ${currentBlock.previousHash})`);
      }

      // Check 2: Hash integrity recalculation
      const recalculatedHash = this.calculateHash(
        currentBlock.index,
        currentBlock.previousHash,
        currentBlock.timestamp,
        currentBlock.transaction.id,
        currentBlock.merkleRoot,
        currentBlock.nonce
      );

      if (currentBlock.hash !== recalculatedHash) {
        errors.push(`Block #${currentBlock.index} data corrupted: stored hash does not match computed SHA-256`);
      }

      // Check 3: Transaction data hash integrity
      const recalculatedDataHash = this.calculateDataHash(currentBlock.transaction.data);
      if (currentBlock.transaction.dataHash !== recalculatedDataHash) {
        errors.push(`Block #${currentBlock.index} transaction payload tampered with`);
      }
    }

    return {
      isValid: errors.length === 0,
      totalBlocks: this.chain.length,
      errors,
      verifiedAt: new Date().toISOString()
    };
  }

  public getBlocksForBatch(batchId: string): BlockchainBlock[] {
    return this.chain.filter(b => b.transaction.batchId === batchId);
  }

  public getBlocksForProduct(productId: string): BlockchainBlock[] {
    return this.chain.filter(b => b.transaction.productId === productId || b.transaction.data?.productId === productId);
  }

  public getBlocksForTracking(trackingId: string): BlockchainBlock[] {
    return this.chain.filter(b => b.transaction.trackingId === trackingId || b.transaction.data?.trackingId === trackingId);
  }
}
