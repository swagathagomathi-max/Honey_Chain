import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { Blockchain, BlockchainBlock, BlockchainTransaction } from './blockchain.ts';

const DB_FILE = path.resolve(process.cwd(), 'server', 'honeychain_db.json');

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: 'ADMIN' | 'BEEKEEPER' | 'PROCESSOR' | 'QUALITY_INSPECTOR' | 'DISTRIBUTOR' | 'CUSTOMER';
  phone?: string;
  organization?: string;
  location?: string;
  avatar?: string;
  hasGiTag?: boolean;
  giTagNumber?: string;
  giTagName?: string;
  giTagCertificateUrl?: string;
  giTagVerified?: boolean;
  baseCostPerKg?: number;
  createdAt: string;
}

export interface HoneyBatch {
  id: string;
  apiaryId: string;
  apiaryName: string;
  beekeeperId: string;
  beekeeperName: string;
  harvestDate: string;
  location: string;
  latitude: number;
  longitude: number;
  hiveCount: number;
  honeyType: 'Wildflower' | 'Acacia' | 'Eucalyptus' | 'Mustard' | 'Multifloral' | 'Sidr' | 'Lavender' | 'Clover' | 'Other';
  floralSource: string;
  quantity: number; // in kg
  remainingQuantity: number;
  harvestMethod: string;
  temperature: number; // in Celsius
  moisturePercentage: number; // in %
  notes: string;
  imageUrl?: string;
  hasGiTag: boolean;
  giTagName?: string;
  giTagNumber?: string;
  giTagVerified?: boolean;
  costPerKg: number;
  status: 'HARVESTED' | 'PROCESSING' | 'PROCESSED' | 'INSPECTED_PASSED' | 'INSPECTED_FAILED' | 'PACKAGED' | 'COMPLETED';
  qualityGrade?: 'A' | 'B' | 'C';
  blockchainTxId: string;
  createdAt: string;
}

export interface ProcessingRecord {
  id: string;
  batchId: string;
  processorId: string;
  processorName: string;
  processingDate: string;
  facilityName: string;
  processingMethod: string;
  filtrationMethod: string;
  heatingTemperature: number;
  processingDurationMinutes: number;
  quantityBeforeKg: number;
  quantityAfterKg: number;
  storageContainer: string;
  storageTemperature: number;
  notes: string;
  blockchainTxId: string;
  createdAt: string;
}

export interface InspectionRecord {
  id: string;
  batchId: string;
  inspectorId: string;
  inspectorName: string;
  inspectionDate: string;
  moisturePercentage: number;
  phLevel: number;
  colorPfund: string;
  aroma: string;
  taste: string;
  purityTestResult: string; // e.g., '100% Pure, HMF < 15mg/kg'
  adulterationTestResult: string; // 'PASSED (Negative for C4/C3 Sugars)'
  microbialTestResult: string; // 'SAFE (Negative for yeast/mold)'
  qualityGrade: 'A' | 'B' | 'C';
  inspectionResult: 'PASSED' | 'FAILED' | 'PENDING';
  certificateNumber: string;
  remarks: string;
  blockchainTxId: string;
  createdAt: string;
}

export interface Product {
  id: string; // e.g. HC-PROD-9021
  batchId: string;
  trackingId: string; // e.g. HC-TRK-77401
  productName: string;
  honeyType: string;
  floralSource: string;
  brandName: string;
  netQuantityGrams: number;
  totalUnits: number;
  packagingDate: string;
  expiryDate: string;
  packageType: string;
  mrp: number;
  qualityGrade: string;
  qrCodeUrl: string;
  harvesterName: string;
  harvesterGiVerified: boolean;
  apiaryLocation: string;
  status: 'IN_STOCK' | 'SHIPPED' | 'DELIVERED';
  blockchainTxId: string;
  createdAt: string;
}

export interface Checkpoint {
  id: string;
  timestamp: string;
  location: string;
  coordinates: [number, number]; // [lat, lng]
  status: string;
  note: string;
  temperature?: number;
}

export interface DistributionRecord {
  id: string;
  batchId: string;
  productId: string;
  trackingId: string;
  distributorId: string;
  distributorName: string;
  carrierName: string;
  sourceLocation: string;
  sourceCoords: [number, number];
  destinationLocation: string;
  destinationCoords: [number, number];
  transportMethod: string;
  dispatchDate: string;
  expectedDeliveryDate: string;
  actualDeliveryDate?: string;
  storageTemperature: number;
  quantityUnits: number;
  transportStatus: 'PREPARING' | 'IN_TRANSIT' | 'DELIVERED' | 'DELAYED';
  notes: string;
  checkpoints: Checkpoint[];
  blockchainTxId: string;
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  userId?: string;
  role?: string;
  title: string;
  message: string;
  type: 'BATCH_CREATED' | 'PROCESSING_UPDATE' | 'INSPECTION_UPDATE' | 'PRODUCT_PACKAGED' | 'DISTRIBUTION_UPDATE' | 'GI_VERIFIED' | 'BLOCKCHAIN_ALERT';
  batchId?: string;
  productId?: string;
  trackingId?: string;
  read: boolean;
  timestamp: string;
}

export interface GiCertificate {
  id: string;
  beekeeperId: string;
  beekeeperName: string;
  giName: string;
  registrationNumber: string;
  region: string;
  issuingAuthority: string;
  certificateFileUrl: string;
  validUntil: string;
  verified: boolean;
  verifiedAt?: string;
  verifiedBy?: string;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  role: string;
  action: string;
  entityType: string;
  entityId: string;
  details: string;
}

export interface DatabaseSchema {
  users: User[];
  honey_batches: HoneyBatch[];
  processing_records: ProcessingRecord[];
  inspection_records: InspectionRecord[];
  products: Product[];
  distribution_records: DistributionRecord[];
  notifications: NotificationItem[];
  gi_certificates: GiCertificate[];
  audit_logs: AuditLog[];
  blockchain: BlockchainBlock[];
}

export class Database {
  private data: DatabaseSchema;
  public blockchainEngine: Blockchain;

  constructor() {
    this.blockchainEngine = new Blockchain();
    this.data = this.loadOrInitialize();
    this.blockchainEngine.chain = this.data.blockchain;
  }

  private loadOrInitialize(): DatabaseSchema {
    const dir = path.dirname(DB_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        return parsed;
      } catch (err) {
        console.error('Error reading database file, re-initializing...', err);
      }
    }

    const initial = this.generateSeedData();
    this.saveData(initial);
    return initial;
  }

  private saveData(dataToSave?: DatabaseSchema) {
    try {
      const data = dataToSave || this.data;
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to write database file:', err);
    }
  }

  public persist() {
    this.data.blockchain = this.blockchainEngine.chain;
    this.saveData();
  }

  // Getters
  public getUsers(): User[] { return this.data.users; }
  public getBatches(): HoneyBatch[] { return this.data.honey_batches; }
  public getProcessingRecords(): ProcessingRecord[] { return this.data.processing_records; }
  public getInspectionRecords(): InspectionRecord[] { return this.data.inspection_records; }
  public getProducts(): Product[] { return this.data.products; }
  public getDistributionRecords(): DistributionRecord[] { return this.data.distribution_records; }
  public getNotifications(): NotificationItem[] { return this.data.notifications; }
  public getGiCertificates(): GiCertificate[] { return this.data.gi_certificates; }
  public getAuditLogs(): AuditLog[] { return this.data.audit_logs; }

  // Mutations
  public addUser(user: User): User {
    this.data.users.push(user);
    this.persist();
    return user;
  }

  public updateUser(id: string, updates: Partial<User>): User | null {
    const idx = this.data.users.findIndex(u => u.id === id);
    if (idx === -1) return null;
    this.data.users[idx] = { ...this.data.users[idx], ...updates };
    this.persist();
    return this.data.users[idx];
  }

  public addBatch(batch: HoneyBatch): HoneyBatch {
    this.data.honey_batches.unshift(batch);
    this.persist();
    return batch;
  }

  public updateBatch(id: string, updates: Partial<HoneyBatch>): HoneyBatch | null {
    const idx = this.data.honey_batches.findIndex(b => b.id === id);
    if (idx === -1) return null;
    this.data.honey_batches[idx] = { ...this.data.honey_batches[idx], ...updates };
    this.persist();
    return this.data.honey_batches[idx];
  }

  public addProcessingRecord(record: ProcessingRecord): ProcessingRecord {
    this.data.processing_records.unshift(record);
    this.persist();
    return record;
  }

  public addInspectionRecord(record: InspectionRecord): InspectionRecord {
    this.data.inspection_records.unshift(record);
    this.persist();
    return record;
  }

  public addProduct(product: Product): Product {
    this.data.products.unshift(product);
    this.persist();
    return product;
  }

  public updateProduct(id: string, updates: Partial<Product>): Product | null {
    const idx = this.data.products.findIndex(p => p.id === id);
    if (idx === -1) return null;
    this.data.products[idx] = { ...this.data.products[idx], ...updates };
    this.persist();
    return this.data.products[idx];
  }

  public addDistributionRecord(record: DistributionRecord): DistributionRecord {
    this.data.distribution_records.unshift(record);
    this.persist();
    return record;
  }

  public updateDistributionRecord(id: string, updates: Partial<DistributionRecord>): DistributionRecord | null {
    const idx = this.data.distribution_records.findIndex(d => d.id === id || d.trackingId === id);
    if (idx === -1) return null;
    this.data.distribution_records[idx] = { ...this.data.distribution_records[idx], ...updates };
    this.persist();
    return this.data.distribution_records[idx];
  }

  public addNotification(notification: NotificationItem): NotificationItem {
    this.data.notifications.unshift(notification);
    if (this.data.notifications.length > 200) {
      this.data.notifications.pop();
    }
    this.persist();
    return notification;
  }

  public markNotificationAsRead(id: string): boolean {
    const notif = this.data.notifications.find(n => n.id === id);
    if (notif) {
      notif.read = true;
      this.persist();
      return true;
    }
    return false;
  }

  public markAllNotificationsAsRead(userId?: string): void {
    this.data.notifications.forEach(n => {
      if (!userId || !n.userId || n.userId === userId) {
        n.read = true;
      }
    });
    this.persist();
  }

  public addGiCertificate(cert: GiCertificate): GiCertificate {
    this.data.gi_certificates.unshift(cert);
    this.persist();
    return cert;
  }

  public updateGiCertificate(id: string, updates: Partial<GiCertificate>): GiCertificate | null {
    const idx = this.data.gi_certificates.findIndex(c => c.id === id);
    if (idx === -1) return null;
    this.data.gi_certificates[idx] = { ...this.data.gi_certificates[idx], ...updates };
    this.persist();
    return this.data.gi_certificates[idx];
  }

  public logAudit(log: Omit<AuditLog, 'id' | 'timestamp'>): AuditLog {
    const newLog: AuditLog = {
      id: `LOG-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString(),
      ...log
    };
    this.data.audit_logs.unshift(newLog);
    if (this.data.audit_logs.length > 500) {
      this.data.audit_logs.pop();
    }
    this.persist();
    return newLog;
  }

  private generateSeedData(): DatabaseSchema {
    const blockchain = new Blockchain();
    const genesisBlock = blockchain.createGenesisBlock();
    blockchain.chain = [genesisBlock];

    const salt = bcrypt.genSaltSync(10);
    const adminPass = bcrypt.hashSync('admin123', salt);
    const beekeeperPass = bcrypt.hashSync('beekeeper123', salt);
    const processorPass = bcrypt.hashSync('processor123', salt);
    const inspectorPass = bcrypt.hashSync('inspector123', salt);
    const distributorPass = bcrypt.hashSync('distributor123', salt);
    const customerPass = bcrypt.hashSync('customer123', salt);

    const users: User[] = [
      {
        id: 'USR-ADMIN-01',
        name: 'Elena Rostova',
        email: 'admin@honeychain.io',
        passwordHash: adminPass,
        role: 'ADMIN',
        phone: '+1 555-019-2831',
        organization: 'Honey Chain International Traceability Authority',
        location: 'Geneva, Switzerland',
        createdAt: '2026-01-01T08:00:00Z'
      },
      {
        id: 'USR-BEE-01',
        name: 'Darius Thorne',
        email: 'beekeeper@honeychain.io',
        passwordHash: beekeeperPass,
        role: 'BEEKEEPER',
        phone: '+1 555-024-9102',
        organization: 'Whispering Pines Apiaries',
        location: 'Cascade Mountain Valley, Washington, USA',
        hasGiTag: true,
        giTagNumber: 'GI-USA-WA-2024-0089',
        giTagName: 'Pacific Northwest Wildflower Forest Reserve',
        giTagCertificateUrl: 'https://honeychain.io/certificates/GI-USA-WA-2024-0089.pdf',
        giTagVerified: true,
        baseCostPerKg: 38.5,
        createdAt: '2026-01-10T09:30:00Z'
      },
      {
        id: 'USR-BEE-02',
        name: 'Maria Vasileva',
        email: 'maria.apiary@honeychain.io',
        passwordHash: beekeeperPass,
        role: 'BEEKEEPER',
        phone: '+359 88 512 4432',
        organization: 'Balkan Acacia Meadows',
        location: 'Danube Plain, Bulgaria',
        hasGiTag: true,
        giTagNumber: 'GI-EU-BG-2025-0144',
        giTagName: 'Strandzha Honeydew Oak Reserve Honey',
        giTagCertificateUrl: 'https://honeychain.io/certificates/GI-EU-BG-2025-0144.pdf',
        giTagVerified: true,
        baseCostPerKg: 42.0,
        createdAt: '2026-01-12T11:00:00Z'
      },
      {
        id: 'USR-PROC-01',
        name: 'Marcus Vance',
        email: 'processor@honeychain.io',
        passwordHash: processorPass,
        role: 'PROCESSOR',
        phone: '+1 555-031-7788',
        organization: 'PureCraft Cold-Extraction Processing Labs',
        location: 'Seattle Eco-Industrial Park, WA',
        createdAt: '2026-01-15T10:00:00Z'
      },
      {
        id: 'USR-INSP-01',
        name: 'Dr. Aris Thorne',
        email: 'inspector@honeychain.io',
        passwordHash: inspectorPass,
        role: 'QUALITY_INSPECTOR',
        phone: '+1 555-045-3392',
        organization: 'Apex Melissopalynology & Food Quality Labs (ISO 17025)',
        location: 'Portland Agri-Tech BioCenter, OR',
        createdAt: '2026-01-18T14:15:00Z'
      },
      {
        id: 'USR-DIST-01',
        name: 'Kaelen Vance',
        email: 'distributor@honeychain.io',
        passwordHash: distributorPass,
        role: 'DISTRIBUTOR',
        phone: '+1 555-067-1123',
        organization: 'AeroCold Green Logistics & Cold Chain',
        location: 'San Francisco Bay Logistics Hub, CA',
        createdAt: '2026-01-20T16:00:00Z'
      },
      {
        id: 'USR-CUST-01',
        name: 'Sophia Chen',
        email: 'customer@honeychain.io',
        passwordHash: customerPass,
        role: 'CUSTOMER',
        phone: '+1 555-089-4455',
        organization: 'Artisan Food Connoisseur',
        location: 'Vancouver, BC',
        createdAt: '2026-02-01T12:00:00Z'
      }
    ];

    const gi_certificates: GiCertificate[] = [
      {
        id: 'GI-CERT-001',
        beekeeperId: 'USR-BEE-01',
        beekeeperName: 'Darius Thorne',
        giName: 'Pacific Northwest Wildflower Forest Reserve',
        registrationNumber: 'GI-USA-WA-2024-0089',
        region: 'Cascade Mountain Range, Washington State',
        issuingAuthority: 'Federal Geographical Indications Board & US Apiary Registry',
        certificateFileUrl: 'https://honeychain.io/certificates/GI-USA-WA-2024-0089.pdf',
        validUntil: '2029-12-31',
        verified: true,
        verifiedAt: '2026-01-11T14:00:00Z',
        verifiedBy: 'Elena Rostova (ADMIN)',
        createdAt: '2026-01-10T10:00:00Z'
      },
      {
        id: 'GI-CERT-002',
        beekeeperId: 'USR-BEE-02',
        beekeeperName: 'Maria Vasileva',
        giName: 'Strandzha Honeydew Oak Reserve Honey',
        registrationNumber: 'GI-EU-BG-2025-0144',
        region: 'Strandzha Nature Park, Southeast Bulgaria',
        issuingAuthority: 'European Union Protected Designation of Origin (PDO)',
        certificateFileUrl: 'https://honeychain.io/certificates/GI-EU-BG-2025-0144.pdf',
        validUntil: '2030-05-30',
        verified: true,
        verifiedAt: '2026-01-13T09:20:00Z',
        verifiedBy: 'Elena Rostova (ADMIN)',
        createdAt: '2026-01-12T12:30:00Z'
      }
    ];

    // Seed Batches
    const batch1Id = 'HC-BATCH-2026-0812';
    const batch2Id = 'HC-BATCH-2026-0813';
    const batch3Id = 'HC-BATCH-2026-0814';

    // Transactions for Batch 1 (Fully complete lifecycle)
    const tx1: BlockchainTransaction = {
      id: 'HC-TX-HARV-00192',
      batchId: batch1Id,
      action: 'HARVEST_CREATED',
      actor: { id: 'USR-BEE-01', name: 'Darius Thorne', role: 'BEEKEEPER', organization: 'Whispering Pines Apiaries' },
      timestamp: '2026-02-10T08:30:00Z',
      data: {
        batchId: batch1Id,
        apiaryId: 'AP-PINES-04',
        honeyType: 'Wildflower',
        floralSource: 'Blackberry blossom, Douglas Fir dew & Mountain Heather',
        quantityKg: 350,
        moisturePercentage: 16.8,
        temperatureC: 22.4,
        hiveCount: 48,
        harvestMethod: 'Cold comb centrifugal extraction',
        location: 'Cascade Mountain Valley, WA',
        latitude: 47.7511,
        longitude: -120.7401,
        giTagVerified: true,
        giTagName: 'Pacific Northwest Wildflower Forest Reserve',
        costPerKg: 38.5
      },
      dataHash: blockchain.calculateDataHash({ batchId: batch1Id, qty: 350, moisture: 16.8 })
    };
    const block1 = blockchain.addBlock(tx1);

    const tx2: BlockchainTransaction = {
      id: 'HC-TX-PROC-00214',
      batchId: batch1Id,
      action: 'PROCESSING_COMPLETED',
      actor: { id: 'USR-PROC-01', name: 'Marcus Vance', role: 'PROCESSOR', organization: 'PureCraft Cold-Extraction Processing Labs' },
      timestamp: '2026-02-12T11:15:00Z',
      data: {
        batchId: batch1Id,
        facility: 'PureCraft Seattle Cleanroom Lab #3',
        processingMethod: 'Raw Cold Settling & Unpasteurized Micro-clarification',
        filtrationMethod: 'Dual 200-micron Food-grade Stainless Mesh',
        heatingTemperatureC: 34.2, // Below 35°C to preserve active pollen enzymes!
        durationMinutes: 180,
        quantityBeforeKg: 350,
        quantityAfterKg: 346.5,
        yieldEfficiencyPercent: 99.0,
        storageContainer: '316L Food-Grade Nitrogen-blanketed Stainless Vat #08',
        storageTemperatureC: 18.0
      },
      dataHash: blockchain.calculateDataHash({ batchId: batch1Id, proc: 'Raw Cold Settling', temp: 34.2 })
    };
    const block2 = blockchain.addBlock(tx2);

    const tx3: BlockchainTransaction = {
      id: 'HC-TX-INSP-00331',
      batchId: batch1Id,
      action: 'QUALITY_INSPECTED',
      actor: { id: 'USR-INSP-01', name: 'Dr. Aris Thorne', role: 'QUALITY_INSPECTOR', organization: 'Apex Melissopalynology Labs' },
      timestamp: '2026-02-14T14:45:00Z',
      data: {
        batchId: batch1Id,
        certificateNumber: 'CERT-ISO17025-HC-9921',
        moisturePercentage: 16.9,
        phLevel: 3.92,
        colorPfund: 'Amber (52mm)',
        aroma: 'Rich floral forest bouquet, caramelized malt notes',
        taste: 'Velvety smooth, lingering wild berry finish',
        purityTestResult: 'Purity 99.8%, Diastase activity 19.4 DN, HMF 8.2 mg/kg (Exceptional)',
        adulterationTestResult: 'PASSED (Zero C4/C3 sugars detected, Stable Isotope Ratio Verified)',
        microbialTestResult: 'SAFE (Total viable count < 10 CFU/g, Zero pathogenic spores)',
        qualityGrade: 'A',
        inspectionResult: 'PASSED'
      },
      dataHash: blockchain.calculateDataHash({ batchId: batch1Id, cert: 'CERT-ISO17025-HC-9921', grade: 'A' })
    };
    const block3 = blockchain.addBlock(tx3);

    const prod1Id = 'HC-PROD-9021';
    const trk1Id = 'HC-TRK-77401';
    const tx4: BlockchainTransaction = {
      id: 'HC-TX-PACK-00452',
      batchId: batch1Id,
      productId: prod1Id,
      trackingId: trk1Id,
      action: 'PRODUCT_PACKAGED',
      actor: { id: 'USR-ADMIN-01', name: 'Elena Rostova', role: 'ADMIN', organization: 'Honey Chain Quality Bureau' },
      timestamp: '2026-02-16T10:00:00Z',
      data: {
        productId: prod1Id,
        trackingId: trk1Id,
        productName: 'Reserve Organic Wildflower Mountain Honey (GI Verified)',
        brandName: 'Cascade Golden Nectar',
        netQuantityGrams: 500,
        totalUnits: 690,
        mrp: 32.50,
        qualityGrade: 'A',
        packageType: 'Hexagonal UV-Shielded Glass Jar with Wooden Honey Dipper',
        packagingDate: '2026-02-16',
        expiryDate: '2028-02-16'
      },
      dataHash: blockchain.calculateDataHash({ productId: prod1Id, trackingId: trk1Id, units: 690 })
    };
    const block4 = blockchain.addBlock(tx4);

    const tx5: BlockchainTransaction = {
      id: 'HC-TX-DIST-00518',
      batchId: batch1Id,
      productId: prod1Id,
      trackingId: trk1Id,
      action: 'DISTRIBUTION_DISPATCHED',
      actor: { id: 'USR-DIST-01', name: 'Kaelen Vance', role: 'DISTRIBUTOR', organization: 'AeroCold Green Logistics' },
      timestamp: '2026-02-18T07:30:00Z',
      data: {
        trackingId: trk1Id,
        carrier: 'AeroCold Climate-Controlled EV Fleet #EV-99',
        sourceLocation: 'Seattle Cold Distribution Facility, WA',
        destinationLocation: 'San Francisco Gourmet Retail Hub, CA',
        storageTemperatureC: 16.5,
        status: 'IN_TRANSIT',
        unitsDispatched: 690
      },
      dataHash: blockchain.calculateDataHash({ trackingId: trk1Id, status: 'IN_TRANSIT' })
    };
    const block5 = blockchain.addBlock(tx5);

    // Batch 2: Harvested & Inspected
    const tx6: BlockchainTransaction = {
      id: 'HC-TX-HARV-00193',
      batchId: batch2Id,
      action: 'HARVEST_CREATED',
      actor: { id: 'USR-BEE-02', name: 'Maria Vasileva', role: 'BEEKEEPER', organization: 'Balkan Acacia Meadows' },
      timestamp: '2026-02-20T09:00:00Z',
      data: {
        batchId: batch2Id,
        apiaryId: 'AP-BALKAN-02',
        honeyType: 'Acacia',
        floralSource: 'Robinia pseudoacacia (White Acacia Blossoms)',
        quantityKg: 500,
        moisturePercentage: 15.6,
        temperatureC: 21.0,
        hiveCount: 65,
        harvestMethod: 'Traditional comb uncapping & centrifugal extraction',
        location: 'Danube Plain, Bulgaria',
        latitude: 43.8356,
        longitude: 25.9657,
        giTagVerified: true,
        giTagName: 'Strandzha Honeydew Oak Reserve Honey',
        costPerKg: 42.0
      },
      dataHash: blockchain.calculateDataHash({ batchId: batch2Id, qty: 500 })
    };
    blockchain.addBlock(tx6);

    // Batch 3: Freshly Harvested
    const tx7: BlockchainTransaction = {
      id: 'HC-TX-HARV-00194',
      batchId: batch3Id,
      action: 'HARVEST_CREATED',
      actor: { id: 'USR-BEE-01', name: 'Darius Thorne', role: 'BEEKEEPER', organization: 'Whispering Pines Apiaries' },
      timestamp: '2026-03-01T10:15:00Z',
      data: {
        batchId: batch3Id,
        apiaryId: 'AP-PINES-09',
        honeyType: 'Lavender',
        floralSource: 'Highland Organic Lavender Fields',
        quantityKg: 280,
        moisturePercentage: 17.2,
        temperatureC: 23.1,
        hiveCount: 36,
        harvestMethod: 'Cold press & gravity separation',
        location: 'Sequim Lavender Valley, WA',
        latitude: 48.0795,
        longitude: -123.1018,
        giTagVerified: true,
        giTagName: 'Pacific Northwest Wildflower Forest Reserve',
        costPerKg: 45.0
      },
      dataHash: blockchain.calculateDataHash({ batchId: batch3Id, qty: 280 })
    };
    blockchain.addBlock(tx7);

    const honey_batches: HoneyBatch[] = [
      {
        id: batch1Id,
        apiaryId: 'AP-PINES-04',
        apiaryName: 'Whispering Pines - High Alpine Apiary #4',
        beekeeperId: 'USR-BEE-01',
        beekeeperName: 'Darius Thorne',
        harvestDate: '2026-02-10',
        location: 'Cascade Mountain Valley, Washington, USA',
        latitude: 47.7511,
        longitude: -120.7401,
        hiveCount: 48,
        honeyType: 'Wildflower',
        floralSource: 'Blackberry blossom, Douglas Fir dew & Mountain Heather',
        quantity: 350,
        remainingQuantity: 0,
        harvestMethod: 'Cold comb centrifugal extraction',
        temperature: 22.4,
        moisturePercentage: 16.8,
        notes: 'Exceptional clarity and herbal aroma. Microclimate provided ideal nectar flow during dry July sun.',
        hasGiTag: true,
        giTagName: 'Pacific Northwest Wildflower Forest Reserve',
        giTagNumber: 'GI-USA-WA-2024-0089',
        giTagVerified: true,
        costPerKg: 38.5,
        status: 'PACKAGED',
        qualityGrade: 'A',
        blockchainTxId: tx1.id,
        createdAt: '2026-02-10T08:30:00Z'
      },
      {
        id: batch2Id,
        apiaryId: 'AP-BALKAN-02',
        apiaryName: 'Balkan Sun Meadows - Station #2',
        beekeeperId: 'USR-BEE-02',
        beekeeperName: 'Maria Vasileva',
        harvestDate: '2026-02-20',
        location: 'Danube Plain, Bulgaria',
        latitude: 43.8356,
        longitude: 25.9657,
        hiveCount: 65,
        honeyType: 'Acacia',
        floralSource: 'Robinia pseudoacacia (Pure White Acacia)',
        quantity: 500,
        remainingQuantity: 500,
        harvestMethod: 'Traditional comb uncapping & centrifugal extraction',
        temperature: 21.0,
        moisturePercentage: 15.6,
        notes: 'Water-white color, very slow crystallization tendency. Highest fructose to glucose ratio recorded.',
        hasGiTag: true,
        giTagName: 'Strandzha Honeydew Oak Reserve Honey',
        giTagNumber: 'GI-EU-BG-2025-0144',
        giTagVerified: true,
        costPerKg: 42.0,
        status: 'HARVESTED',
        qualityGrade: 'A',
        blockchainTxId: tx6.id,
        createdAt: '2026-02-20T09:00:00Z'
      },
      {
        id: batch3Id,
        apiaryId: 'AP-PINES-09',
        apiaryName: 'Olympic Sun Valley Sanctuary',
        beekeeperId: 'USR-BEE-01',
        beekeeperName: 'Darius Thorne',
        harvestDate: '2026-03-01',
        location: 'Sequim Lavender Valley, WA',
        latitude: 48.0795,
        longitude: -123.1018,
        hiveCount: 36,
        honeyType: 'Lavender',
        floralSource: 'Highland Organic Lavender Fields',
        quantity: 280,
        remainingQuantity: 280,
        harvestMethod: 'Cold press & gravity separation',
        temperature: 23.1,
        moisturePercentage: 17.2,
        notes: 'Subtle floral lavender notes with golden amber hue. Rich in polyphenols and natural pollen.',
        hasGiTag: true,
        giTagName: 'Pacific Northwest Wildflower Forest Reserve',
        giTagNumber: 'GI-USA-WA-2024-0089',
        giTagVerified: true,
        costPerKg: 45.0,
        status: 'HARVESTED',
        qualityGrade: undefined,
        blockchainTxId: tx7.id,
        createdAt: '2026-03-01T10:15:00Z'
      }
    ];

    const processing_records: ProcessingRecord[] = [
      {
        id: 'HC-PROC-00214',
        batchId: batch1Id,
        processorId: 'USR-PROC-01',
        processorName: 'Marcus Vance',
        processingDate: '2026-02-12',
        facilityName: 'PureCraft Seattle Cleanroom Lab #3',
        processingMethod: 'Raw Cold Settling & Unpasteurized Micro-clarification',
        filtrationMethod: 'Dual 200-micron Food-grade Stainless Mesh',
        heatingTemperature: 34.2,
        processingDurationMinutes: 180,
        quantityBeforeKg: 350,
        quantityAfterKg: 346.5,
        storageContainer: '316L Food-Grade Nitrogen-blanketed Stainless Vat #08',
        storageTemperature: 18.0,
        notes: 'Temperature stayed well below 35°C throughout filtration to preserve live beneficial enzymes (invertase and glucose oxidase).',
        blockchainTxId: tx2.id,
        createdAt: '2026-02-12T11:15:00Z'
      }
    ];

    const inspection_records: InspectionRecord[] = [
      {
        id: 'HC-INSP-00331',
        batchId: batch1Id,
        inspectorId: 'USR-INSP-01',
        inspectorName: 'Dr. Aris Thorne',
        inspectionDate: '2026-02-14',
        moisturePercentage: 16.9,
        phLevel: 3.92,
        colorPfund: 'Amber (52mm)',
        aroma: 'Rich floral forest bouquet, caramelized malt notes',
        taste: 'Velvety smooth, balanced sweetness, wild berry finish',
        purityTestResult: 'Purity 99.8%, Diastase activity 19.4 DN, HMF 8.2 mg/kg',
        adulterationTestResult: 'PASSED (Negative for C4/C3 Sugars & HFCS)',
        microbialTestResult: 'SAFE (Negative for yeast/mold/Clostridium botulinum spores)',
        qualityGrade: 'A',
        inspectionResult: 'PASSED',
        certificateNumber: 'CERT-ISO17025-HC-9921',
        remarks: 'Batch meets all Codex Alimentarius and USDA Grade A requirements with distinction.',
        blockchainTxId: tx3.id,
        createdAt: '2026-02-14T14:45:00Z'
      }
    ];

    const products: Product[] = [
      {
        id: prod1Id,
        batchId: batch1Id,
        trackingId: trk1Id,
        productName: 'Reserve Organic Wildflower Mountain Honey (GI Verified)',
        honeyType: 'Wildflower',
        floralSource: 'Blackberry blossom, Douglas Fir dew & Mountain Heather',
        brandName: 'Cascade Golden Nectar',
        netQuantityGrams: 500,
        totalUnits: 690,
        packagingDate: '2026-02-16',
        expiryDate: '2028-02-16',
        packageType: 'Hexagonal UV-Shielded Glass Jar with Wooden Honey Dipper',
        mrp: 32.50,
        qualityGrade: 'A',
        qrCodeUrl: '',
        harvesterName: 'Darius Thorne',
        harvesterGiVerified: true,
        apiaryLocation: 'Cascade Mountain Valley, Washington, USA',
        status: 'SHIPPED',
        blockchainTxId: tx4.id,
        createdAt: '2026-02-16T10:00:00Z'
      }
    ];

    const distribution_records: DistributionRecord[] = [
      {
        id: 'HC-DIST-00518',
        batchId: batch1Id,
        productId: prod1Id,
        trackingId: trk1Id,
        distributorId: 'USR-DIST-01',
        distributorName: 'Kaelen Vance',
        carrierName: 'AeroCold Climate-Controlled EV Fleet #EV-99',
        sourceLocation: 'Seattle Cold Distribution Facility, WA',
        sourceCoords: [47.6062, -122.3321],
        destinationLocation: 'San Francisco Gourmet Retail Hub, CA',
        destinationCoords: [37.7749, -122.4194],
        transportMethod: 'Refrigerated EV Freight with Real-time IoT Telemetry',
        dispatchDate: '2026-02-18T07:30:00Z',
        expectedDeliveryDate: '2026-02-21T18:00:00Z',
        storageTemperature: 16.5,
        quantityUnits: 690,
        transportStatus: 'IN_TRANSIT',
        notes: 'Continuous temperature logging active. Maintained between 15°C and 18°C.',
        checkpoints: [
          {
            id: 'CP-01',
            timestamp: '2026-02-18T08:00:00Z',
            location: 'Seattle Hub Departure Facility, WA',
            coordinates: [47.6062, -122.3321],
            status: 'DISPATCHED',
            note: 'Loaded onto refrigerated truck #EV-99. Temperature set to 16.5°C.',
            temperature: 16.5
          },
          {
            id: 'CP-02',
            timestamp: '2026-02-18T16:40:00Z',
            location: 'Portland Agri-Corridor Logistics Gate, OR',
            coordinates: [45.5152, -122.6784],
            status: 'CHECKPOINT_CLEARED',
            note: 'IoT sensor verification completed. Seal intact. Pallet vibration normal.',
            temperature: 16.3
          },
          {
            id: 'CP-03',
            timestamp: '2026-02-19T11:20:00Z',
            location: 'Redding Transit Station, Northern CA',
            coordinates: [40.5865, -122.3917],
            status: 'IN_TRANSIT',
            note: 'Vehicle battery charged at solar superhub. Honey cargo stable at 16.8°C.',
            temperature: 16.8
          }
        ],
        blockchainTxId: tx5.id,
        createdAt: '2026-02-18T07:30:00Z'
      }
    ];

    const notifications: NotificationItem[] = [
      {
        id: 'NOTIF-001',
        title: 'New Honey Harvest Batch Registered',
        message: 'Batch HC-BATCH-2026-0814 (Lavender) created by Darius Thorne at Sequim Lavender Valley.',
        type: 'BATCH_CREATED',
        batchId: batch3Id,
        read: false,
        timestamp: '2026-03-01T10:15:30Z'
      },
      {
        id: 'NOTIF-002',
        title: 'Quality Grade A Certificate Issued',
        message: 'Batch HC-BATCH-2026-0812 passed ISO 17025 inspection with Grade A certification.',
        type: 'INSPECTION_UPDATE',
        batchId: batch1Id,
        read: false,
        timestamp: '2026-02-14T14:46:00Z'
      },
      {
        id: 'NOTIF-003',
        title: 'Product Packaged & QR Minted',
        message: 'Product HC-PROD-9021 generated with 690 jars and public verification QR code.',
        type: 'PRODUCT_PACKAGED',
        batchId: batch1Id,
        productId: prod1Id,
        trackingId: trk1Id,
        read: true,
        timestamp: '2026-02-16T10:02:00Z'
      },
      {
        id: 'NOTIF-004',
        title: 'Cold-Chain Shipment Dispatched',
        message: 'Tracking ID HC-TRK-77401 is In-Transit to San Francisco Retail Hub.',
        type: 'DISTRIBUTION_UPDATE',
        batchId: batch1Id,
        trackingId: trk1Id,
        read: true,
        timestamp: '2026-02-18T07:31:00Z'
      },
      {
        id: 'NOTIF-005',
        title: 'Geographical Indication (GI) Verified',
        message: 'Maria Vasileva has been verified for Strandzha Honeydew Oak Reserve Honey.',
        type: 'GI_VERIFIED',
        read: true,
        timestamp: '2026-01-13T09:21:00Z'
      }
    ];

    const audit_logs: AuditLog[] = [
      {
        id: 'LOG-001',
        timestamp: '2026-02-10T08:30:00Z',
        userId: 'USR-BEE-01',
        userName: 'Darius Thorne',
        role: 'BEEKEEPER',
        action: 'HARVEST_SUBMISSION',
        entityType: 'HONEY_BATCH',
        entityId: batch1Id,
        details: 'Submitted 350kg Wildflower honey harvest from Apiary AP-PINES-04 with GI tag.'
      },
      {
        id: 'LOG-002',
        timestamp: '2026-02-12T11:15:00Z',
        userId: 'USR-PROC-01',
        userName: 'Marcus Vance',
        role: 'PROCESSOR',
        action: 'PROCESSING_LOG',
        entityType: 'PROCESSING_RECORD',
        entityId: 'HC-PROC-00214',
        details: 'Recorded raw micro-clarification of batch HC-BATCH-2026-0812 (346.5kg yield).'
      },
      {
        id: 'LOG-003',
        timestamp: '2026-02-14T14:45:00Z',
        userId: 'USR-INSP-01',
        userName: 'Dr. Aris Thorne',
        role: 'QUALITY_INSPECTOR',
        action: 'QUALITY_INSPECTION',
        entityType: 'INSPECTION_RECORD',
        entityId: 'HC-INSP-00331',
        details: 'Certified Grade A purity and zero adulteration on batch HC-BATCH-2026-0812.'
      },
      {
        id: 'LOG-004',
        timestamp: '2026-02-16T10:00:00Z',
        userId: 'USR-ADMIN-01',
        userName: 'Elena Rostova',
        role: 'ADMIN',
        action: 'PACKAGING_CREATION',
        entityType: 'PRODUCT',
        entityId: prod1Id,
        details: 'Packaged 690 jars of Reserve Organic Wildflower Honey. Tracking ID HC-TRK-77401 assigned.'
      },
      {
        id: 'LOG-005',
        timestamp: '2026-02-18T07:30:00Z',
        userId: 'USR-DIST-01',
        userName: 'Kaelen Vance',
        role: 'DISTRIBUTOR',
        action: 'DISTRIBUTION_DISPATCH',
        entityType: 'DISTRIBUTION_RECORD',
        entityId: 'HC-DIST-00518',
        details: 'Dispatched climate-controlled shipment HC-TRK-77401 from Seattle to San Francisco.'
      }
    ];

    return {
      users,
      honey_batches,
      processing_records,
      inspection_records,
      products,
      distribution_records,
      notifications,
      gi_certificates,
      audit_logs,
      blockchain: blockchain.chain
    };
  }
}

export const db = new Database();
