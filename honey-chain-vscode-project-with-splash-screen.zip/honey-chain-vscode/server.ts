import express, { Request, Response, NextFunction } from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import QRCode from 'qrcode';
import { db, User, HoneyBatch, ProcessingRecord, InspectionRecord, Product, DistributionRecord, NotificationItem, GiCertificate, Checkpoint } from './server/db.ts';
import { BlockchainTransaction } from './server/blockchain.ts';

const JWT_SECRET = process.env.JWT_SECRET || 'honeychain-secret-key-blockchain-2026';
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

const app = express();
const server = http.createServer(app);

// Increase limit for base64 images and certificates
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true, limit: '20mb' }));

// WebSocket Server for Real-Time Push Notifications
const wss = new WebSocketServer({ server, path: '/ws' });
const connectedClients = new Set<WebSocket>();

wss.on('connection', (ws: WebSocket) => {
  connectedClients.add(ws);

  // Send initial welcome & connection ack
  ws.send(JSON.stringify({
    type: 'CONNECTION_ESTABLISHED',
    message: 'Connected to Honey Chain Real-Time WebSocket Network',
    timestamp: new Date().toISOString()
  }));

  ws.on('close', () => {
    connectedClients.delete(ws);
  });

  ws.on('error', (err) => {
    console.error('WebSocket client error:', err);
    connectedClients.delete(ws);
  });
});

export function broadcastRealtime(event: { type: string; payload: any }) {
  const message = JSON.stringify(event);
  for (const client of connectedClients) {
    if (client.readyState === WebSocket.OPEN) {
      try {
        client.send(message);
      } catch (err) {
        console.error('Failed to send WS message to client:', err);
      }
    }
  }
}

// Helper to push notification & broadcast
function pushNotification(notification: Omit<NotificationItem, 'id' | 'timestamp' | 'read'>) {
  const notif: NotificationItem = {
    id: `NOTIF-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    ...notification,
    read: false,
    timestamp: new Date().toISOString()
  };
  db.addNotification(notif);
  broadcastRealtime({
    type: 'NEW_NOTIFICATION',
    payload: notif
  });
  return notif;
}

// Authentication Middleware
export interface AuthRequest extends Request {
  user?: {
    id: string;
    email: string;
    role: User['role'];
    name: string;
  };
}

function authenticateToken(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, decoded: any) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = decoded;
    next();
  });
}

function requireRoles(roles: User['role'][]) {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: `Forbidden: Requires one of [${roles.join(', ')}] role` });
    }
    next();
  };
}

// ==========================================
// AUTHENTICATION ROUTES
// ==========================================

// Login
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  const users = db.getUsers();
  const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());

  if (!user) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  const isMatch = bcrypt.compareSync(password, user.passwordHash);
  if (!isMatch) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  const payload = {
    id: user.id,
    email: user.email,
    role: user.role,
    name: user.name
  };

  const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' });

  // Return user without passwordHash
  const { passwordHash: _, ...userSafe } = user;
  res.json({ token, user: userSafe });
});

// Register
app.post('/api/auth/register', (req: Request, res: Response) => {
  const { name, email, password, role, organization, location, phone } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email, and password are required' });
  }

  const users = db.getUsers();
  if (users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
    return res.status(400).json({ error: 'Email already registered' });
  }

  const validRoles: User['role'][] = ['ADMIN', 'BEEKEEPER', 'PROCESSOR', 'QUALITY_INSPECTOR', 'DISTRIBUTOR', 'CUSTOMER'];
  const userRole: User['role'] = validRoles.includes(role) ? role : 'CUSTOMER';

  const passwordHash = bcrypt.hashSync(password, 10);
  const newUser: User = {
    id: `USR-${userRole.substring(0, 3)}-${Date.now().toString().slice(-4)}`,
    name,
    email,
    passwordHash,
    role: userRole,
    organization: organization || '',
    location: location || '',
    phone: phone || '',
    hasGiTag: false,
    giTagVerified: false,
    baseCostPerKg: userRole === 'BEEKEEPER' ? 25.0 : undefined,
    createdAt: new Date().toISOString()
  };

  db.addUser(newUser);

  db.logAudit({
    userId: newUser.id,
    userName: newUser.name,
    role: newUser.role,
    action: 'USER_REGISTERED',
    entityType: 'USER',
    entityId: newUser.id,
    details: `User ${newUser.name} registered with role ${newUser.role}`
  });

  const payload = { id: newUser.id, email: newUser.email, role: newUser.role, name: newUser.name };
  const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' });

  const { passwordHash: _, ...userSafe } = newUser;
  res.status(201).json({ token, user: userSafe });
});

// Get Current User Profile
app.get('/api/auth/me', authenticateToken, (req: AuthRequest, res: Response) => {
  const users = db.getUsers();
  const user = users.find(u => u.id === req.user?.id);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  const { passwordHash: _, ...userSafe } = user;
  res.json(userSafe);
});

// Update Profile & Submit GI Tag Certificate
app.patch('/api/users/profile', authenticateToken, (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const { name, phone, location, organization, baseCostPerKg, hasGiTag, giTagName, giTagNumber, giTagCertificateUrl } = req.body;

  const updates: Partial<User> = {};
  if (name !== undefined) updates.name = name;
  if (phone !== undefined) updates.phone = phone;
  if (location !== undefined) updates.location = location;
  if (organization !== undefined) updates.organization = organization;
  if (baseCostPerKg !== undefined) updates.baseCostPerKg = parseFloat(baseCostPerKg);

  if (hasGiTag !== undefined) {
    updates.hasGiTag = Boolean(hasGiTag);
    if (giTagName) updates.giTagName = giTagName;
    if (giTagNumber) updates.giTagNumber = giTagNumber;
    if (giTagCertificateUrl) updates.giTagCertificateUrl = giTagCertificateUrl;
  }

  const updatedUser = db.updateUser(userId, updates);
  if (!updatedUser) {
    return res.status(404).json({ error: 'User not found' });
  }

  // If GI tag was submitted, save to GI certificates table if not already present
  if (hasGiTag && giTagName && giTagNumber) {
    const existingCerts = db.getGiCertificates();
    const existing = existingCerts.find(c => c.beekeeperId === userId && c.registrationNumber === giTagNumber);
    if (!existing) {
      const newCert: GiCertificate = {
        id: `GI-CERT-${Date.now().toString().slice(-4)}`,
        beekeeperId: userId,
        beekeeperName: updatedUser.name,
        giName: giTagName,
        registrationNumber: giTagNumber,
        region: location || updatedUser.location || 'Declared Harvest Region',
        issuingAuthority: 'National Intellectual Property & GI Registry',
        certificateFileUrl: giTagCertificateUrl || '',
        validUntil: '2030-12-31',
        verified: false,
        createdAt: new Date().toISOString()
      };
      db.addGiCertificate(newCert);

      pushNotification({
        title: 'New GI Tag Certificate Submitted',
        message: `Beekeeper ${updatedUser.name} submitted GI Certificate (${giTagName} - ${giTagNumber}) for verification.`,
        type: 'GI_VERIFIED',
        role: 'ADMIN'
      });
    }
  }

  const { passwordHash: _, ...userSafe } = updatedUser;
  res.json(userSafe);
});

// Admin: Manage Users
app.get('/api/users', authenticateToken, requireRoles(['ADMIN']), (req: AuthRequest, res: Response) => {
  const users = db.getUsers().map(({ passwordHash, ...safe }) => safe);
  res.json(users);
});

// Admin: Verify GI Tag
app.post('/api/users/:id/verify-gi', authenticateToken, requireRoles(['ADMIN']), (req: AuthRequest, res: Response) => {
  const { id } = req.params;
  const { verified } = req.body;

  const user = db.updateUser(id, { giTagVerified: verified });
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  const certs = db.getGiCertificates();
  const cert = certs.find(c => c.beekeeperId === id);
  if (cert) {
    db.updateGiCertificate(cert.id, {
      verified: Boolean(verified),
      verifiedAt: new Date().toISOString(),
      verifiedBy: `${req.user!.name} (ADMIN)`
    });
  }

  // Add blockchain transaction for GI verification
  const tx: BlockchainTransaction = {
    id: `HC-TX-GIVERIF-${Date.now().toString().slice(-5)}`,
    batchId: 'USER-PROFILE',
    action: 'GI_TAG_VERIFIED',
    actor: {
      id: req.user!.id,
      name: req.user!.name,
      role: 'ADMIN',
      organization: 'Honey Chain Quality Bureau'
    },
    timestamp: new Date().toISOString(),
    data: {
      beekeeperId: user.id,
      beekeeperName: user.name,
      giTagName: user.giTagName,
      giTagNumber: user.giTagNumber,
      verified: Boolean(verified),
      verifiedAt: new Date().toISOString()
    },
    dataHash: db.blockchainEngine.calculateDataHash({ beekeeperId: user.id, verified })
  };
  const block = db.blockchainEngine.addBlock(tx);
  db.persist();

  pushNotification({
    userId: user.id,
    title: verified ? 'GI Tag Certificate Verified! 🏅' : 'GI Tag Certificate Status Updated',
    message: verified
      ? `Congratulations! Your GI Tag (${user.giTagName}) has been verified on the blockchain. Your verified badge is now active and premium pricing is unlocked!`
      : `Your GI Tag status was updated by Administrator.`,
    type: 'GI_VERIFIED'
  });

  broadcastRealtime({
    type: 'BLOCKCHAIN_UPDATED',
    payload: { block, transaction: tx }
  });

  const { passwordHash: _, ...userSafe } = user;
  res.json(userSafe);
});

// ==========================================
// HONEY HARVEST MODULE (Beekeeper)
// ==========================================

// Get All Batches with search & filter
app.get('/api/harvests', (req: Request, res: Response) => {
  const { status, honeyType, beekeeperId, search } = req.query;
  let batches = db.getBatches();

  if (status) {
    batches = batches.filter(b => b.status === status);
  }
  if (honeyType) {
    batches = batches.filter(b => b.honeyType.toLowerCase() === (honeyType as string).toLowerCase());
  }
  if (beekeeperId) {
    batches = batches.filter(b => b.beekeeperId === beekeeperId);
  }
  if (search) {
    const s = (search as string).toLowerCase();
    batches = batches.filter(b =>
      b.id.toLowerCase().includes(s) ||
      b.floralSource.toLowerCase().includes(s) ||
      b.location.toLowerCase().includes(s) ||
      b.beekeeperName.toLowerCase().includes(s) ||
      b.apiaryName.toLowerCase().includes(s)
    );
  }

  res.json(batches);
});

// Beekeeper: Create New Honey Harvest
app.post('/api/harvests', authenticateToken, requireRoles(['ADMIN', 'BEEKEEPER']), (req: AuthRequest, res: Response) => {
  const {
    apiaryId,
    apiaryName,
    harvestDate,
    location,
    latitude,
    longitude,
    hiveCount,
    honeyType,
    floralSource,
    quantity,
    harvestMethod,
    temperature,
    moisturePercentage,
    notes,
    imageUrl,
    costPerKg
  } = req.body;

  if (!floralSource || !quantity || !honeyType || !harvestDate) {
    return res.status(400).json({ error: 'Missing required harvest fields' });
  }

  const currentUser = db.getUsers().find(u => u.id === req.user!.id);
  const beekeeperName = currentUser?.name || req.user!.name;
  const hasGiTag = currentUser?.hasGiTag || false;
  const giTagVerified = currentUser?.giTagVerified || false;
  const giTagName = currentUser?.giTagName;
  const giTagNumber = currentUser?.giTagNumber;

  // Generate unique Batch ID: HC-BATCH-YYYYMMDD-XXXX
  const todayStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  const batchId = `HC-BATCH-${todayStr}-${randomSuffix}`;
  const txId = `HC-TX-HARV-${Date.now().toString().slice(-5)}`;

  const qty = parseFloat(quantity);
  const unitCost = costPerKg ? parseFloat(costPerKg) : (currentUser?.baseCostPerKg || 30.0);

  // 1. Create Blockchain Transaction
  const tx: BlockchainTransaction = {
    id: txId,
    batchId,
    action: 'HARVEST_CREATED',
    actor: {
      id: req.user!.id,
      name: beekeeperName,
      role: req.user!.role,
      organization: currentUser?.organization || 'Independent Artisan Apiary'
    },
    timestamp: new Date().toISOString(),
    data: {
      batchId,
      apiaryId: apiaryId || `AP-${randomSuffix}`,
      apiaryName: apiaryName || `${beekeeperName} Sanctuary Apiary`,
      harvestDate,
      honeyType,
      floralSource,
      quantityKg: qty,
      harvestMethod: harvestMethod || 'Centrifugal extraction',
      temperatureC: parseFloat(temperature || 22),
      moisturePercentage: parseFloat(moisturePercentage || 17.0),
      location: location || 'Eco Mountain Valley',
      latitude: parseFloat(latitude || 47.6),
      longitude: parseFloat(longitude || -122.3),
      giTagVerified,
      giTagName: giTagName || null,
      giTagNumber: giTagNumber || null,
      costPerKg: unitCost
    },
    dataHash: db.blockchainEngine.calculateDataHash({
      batchId,
      quantity: qty,
      moisture: moisturePercentage,
      beekeeper: beekeeperName
    })
  };

  // 2. Mine Block on Blockchain
  const newBlock = db.blockchainEngine.addBlock(tx);

  // 3. Save Batch in Database
  const newBatch: HoneyBatch = {
    id: batchId,
    apiaryId: apiaryId || `AP-${randomSuffix}`,
    apiaryName: apiaryName || `${beekeeperName} Sanctuary Apiary`,
    beekeeperId: req.user!.id,
    beekeeperName,
    harvestDate,
    location: location || 'Eco Mountain Valley',
    latitude: parseFloat(latitude || 47.6),
    longitude: parseFloat(longitude || -122.3),
    hiveCount: parseInt(hiveCount || 24, 10),
    honeyType: honeyType,
    floralSource,
    quantity: qty,
    remainingQuantity: qty,
    harvestMethod: harvestMethod || 'Centrifugal extraction',
    temperature: parseFloat(temperature || 22),
    moisturePercentage: parseFloat(moisturePercentage || 17.0),
    notes: notes || '',
    imageUrl: imageUrl || '',
    hasGiTag,
    giTagName,
    giTagNumber,
    giTagVerified,
    costPerKg: unitCost,
    status: 'HARVESTED',
    blockchainTxId: txId,
    createdAt: new Date().toISOString()
  };

  db.addBatch(newBatch);

  // 4. Log Audit
  db.logAudit({
    userId: req.user!.id,
    userName: beekeeperName,
    role: req.user!.role,
    action: 'HARVEST_SUBMISSION',
    entityType: 'HONEY_BATCH',
    entityId: batchId,
    details: `Harvested ${qty}kg of ${honeyType} honey. Mined Blockchain Block #${newBlock.index}`
  });

  // 5. Real-Time Notification & WebSocket Broadcast
  pushNotification({
    title: 'New Honey Harvest Batch Created',
    message: `Batch ${batchId} (${honeyType} - ${qty}kg) registered by ${beekeeperName} with hash ${newBlock.hash.substring(0, 10)}...`,
    type: 'BATCH_CREATED',
    batchId
  });

  broadcastRealtime({
    type: 'BLOCKCHAIN_UPDATED',
    payload: { block: newBlock, transaction: tx }
  });

  res.status(201).json({
    batch: newBatch,
    blockchainBlock: newBlock,
    transaction: tx
  });
});

// Single Batch Detail with complete history
app.get('/api/batches/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const batch = db.getBatches().find(b => b.id === id);
  if (!batch) {
    return res.status(404).json({ error: 'Honey batch not found' });
  }

  const processingRecords = db.getProcessingRecords().filter(p => p.batchId === id);
  const inspectionRecords = db.getInspectionRecords().filter(i => i.batchId === id);
  const products = db.getProducts().filter(p => p.batchId === id);
  const distributionRecords = db.getDistributionRecords().filter(d => d.batchId === id);
  const blockchainBlocks = db.blockchainEngine.getBlocksForBatch(id);

  res.json({
    batch,
    processingRecords,
    inspectionRecords,
    products,
    distributionRecords,
    blockchainBlocks
  });
});

// ==========================================
// PROCESSING MODULE (Processor)
// ==========================================

// Get all processing logs
app.get('/api/processing', (req: Request, res: Response) => {
  res.json(db.getProcessingRecords());
});

// Processor: Submit Processing Record
app.post('/api/processing', authenticateToken, requireRoles(['ADMIN', 'PROCESSOR']), (req: AuthRequest, res: Response) => {
  const {
    batchId,
    processingDate,
    facilityName,
    processingMethod,
    filtrationMethod,
    heatingTemperature,
    processingDurationMinutes,
    quantityBeforeKg,
    quantityAfterKg,
    storageContainer,
    storageTemperature,
    notes
  } = req.body;

  if (!batchId || !facilityName || !processingMethod) {
    return res.status(400).json({ error: 'Missing required processing fields' });
  }

  const batch = db.getBatches().find(b => b.id === batchId);
  if (!batch) {
    return res.status(404).json({ error: 'Target honey batch not found' });
  }

  const processorUser = db.getUsers().find(u => u.id === req.user!.id);
  const processorName = processorUser?.name || req.user!.name;

  const txId = `HC-TX-PROC-${Date.now().toString().slice(-5)}`;
  const procId = `HC-PROC-${Date.now().toString().slice(-4)}`;

  const qtyBefore = parseFloat(quantityBeforeKg || batch.quantity);
  const qtyAfter = parseFloat(quantityAfterKg || qtyBefore * 0.99);

  // 1. Commit Blockchain Transaction
  const tx: BlockchainTransaction = {
    id: txId,
    batchId,
    action: 'PROCESSING_COMPLETED',
    actor: {
      id: req.user!.id,
      name: processorName,
      role: 'PROCESSOR',
      organization: processorUser?.organization || facilityName
    },
    timestamp: new Date().toISOString(),
    data: {
      batchId,
      facilityName,
      processingMethod,
      filtrationMethod: filtrationMethod || 'Micro-mesh 200 micron',
      heatingTemperatureC: parseFloat(heatingTemperature || 34.0),
      durationMinutes: parseInt(processingDurationMinutes || 120, 10),
      quantityBeforeKg: qtyBefore,
      quantityAfterKg: qtyAfter,
      storageContainer: storageContainer || 'Stainless Steel Vat 316L',
      storageTemperatureC: parseFloat(storageTemperature || 18.0),
      notes: notes || ''
    },
    dataHash: db.blockchainEngine.calculateDataHash({
      batchId,
      procId,
      qtyAfter,
      temp: heatingTemperature
    })
  };

  const newBlock = db.blockchainEngine.addBlock(tx);

  // 2. Save Processing Record
  const newProcessingRecord: ProcessingRecord = {
    id: procId,
    batchId,
    processorId: req.user!.id,
    processorName,
    processingDate: processingDate || new Date().toISOString().slice(0, 10),
    facilityName,
    processingMethod,
    filtrationMethod: filtrationMethod || 'Micro-mesh 200 micron',
    heatingTemperature: parseFloat(heatingTemperature || 34.0),
    processingDurationMinutes: parseInt(processingDurationMinutes || 120, 10),
    quantityBeforeKg: qtyBefore,
    quantityAfterKg: qtyAfter,
    storageContainer: storageContainer || 'Stainless Steel Vat 316L',
    storageTemperature: parseFloat(storageTemperature || 18.0),
    notes: notes || '',
    blockchainTxId: txId,
    createdAt: new Date().toISOString()
  };

  db.addProcessingRecord(newProcessingRecord);

  // 3. Update Batch Status
  db.updateBatch(batchId, {
    status: 'PROCESSED',
    remainingQuantity: qtyAfter
  });

  // 4. Audit Log
  db.logAudit({
    userId: req.user!.id,
    userName: processorName,
    role: 'PROCESSOR',
    action: 'PROCESSING_LOG',
    entityType: 'PROCESSING_RECORD',
    entityId: procId,
    details: `Processed batch ${batchId} at ${facilityName}. Yield: ${qtyAfter}kg. Blockchain block #${newBlock.index}`
  });

  // 5. Notification & Broadcast
  pushNotification({
    title: 'Batch Processing Completed',
    message: `Batch ${batchId} processing completed at ${facilityName}. Ready for Quality Inspection.`,
    type: 'PROCESSING_UPDATE',
    batchId
  });

  broadcastRealtime({
    type: 'BLOCKCHAIN_UPDATED',
    payload: { block: newBlock, transaction: tx }
  });

  res.status(201).json({
    processingRecord: newProcessingRecord,
    blockchainBlock: newBlock
  });
});

// ==========================================
// QUALITY INSPECTION MODULE (Quality Inspector)
// ==========================================

// Get all inspections
app.get('/api/inspections', (req: Request, res: Response) => {
  res.json(db.getInspectionRecords());
});

// Quality Inspector: Inspect Batch
app.post('/api/inspections', authenticateToken, requireRoles(['ADMIN', 'QUALITY_INSPECTOR']), (req: AuthRequest, res: Response) => {
  const {
    batchId,
    inspectionDate,
    moisturePercentage,
    phLevel,
    colorPfund,
    aroma,
    taste,
    purityTestResult,
    adulterationTestResult,
    microbialTestResult,
    qualityGrade,
    inspectionResult,
    remarks
  } = req.body;

  if (!batchId || !qualityGrade || !inspectionResult) {
    return res.status(400).json({ error: 'Missing required inspection parameters' });
  }

  const batch = db.getBatches().find(b => b.id === batchId);
  if (!batch) {
    return res.status(404).json({ error: 'Batch not found' });
  }

  const inspectorUser = db.getUsers().find(u => u.id === req.user!.id);
  const inspectorName = inspectorUser?.name || req.user!.name;

  const txId = `HC-TX-INSP-${Date.now().toString().slice(-5)}`;
  const inspId = `HC-INSP-${Date.now().toString().slice(-4)}`;
  const certNumber = `CERT-ISO17025-HC-${Math.floor(1000 + Math.random() * 9000)}`;

  // 1. Add Blockchain Transaction
  const tx: BlockchainTransaction = {
    id: txId,
    batchId,
    action: 'QUALITY_INSPECTED',
    actor: {
      id: req.user!.id,
      name: inspectorName,
      role: 'QUALITY_INSPECTOR',
      organization: inspectorUser?.organization || 'Apex Quality Assurance Laboratories'
    },
    timestamp: new Date().toISOString(),
    data: {
      batchId,
      certificateNumber: certNumber,
      inspectionDate: inspectionDate || new Date().toISOString().slice(0, 10),
      moisturePercentage: parseFloat(moisturePercentage || 16.5),
      phLevel: parseFloat(phLevel || 3.9),
      colorPfund: colorPfund || 'Light Amber (42mm)',
      aroma: aroma || 'Clean floral bouquet with nectar undertones',
      taste: taste || 'Delicate natural sweetness, zero off-flavors',
      purityTestResult: purityTestResult || '99.9% Pure Honey (Codex Alimentarius compliant)',
      adulterationTestResult: adulterationTestResult || 'PASSED (Negative for added C4/C3 sugars)',
      microbialTestResult: microbialTestResult || 'SAFE (Zero pathogenic yeast or spores)',
      qualityGrade,
      inspectionResult,
      remarks: remarks || ''
    },
    dataHash: db.blockchainEngine.calculateDataHash({
      batchId,
      certNumber,
      qualityGrade,
      inspectionResult
    })
  };

  const newBlock = db.blockchainEngine.addBlock(tx);

  // 2. Save Inspection Record
  const newInspection: InspectionRecord = {
    id: inspId,
    batchId,
    inspectorId: req.user!.id,
    inspectorName,
    inspectionDate: inspectionDate || new Date().toISOString().slice(0, 10),
    moisturePercentage: parseFloat(moisturePercentage || 16.5),
    phLevel: parseFloat(phLevel || 3.9),
    colorPfund: colorPfund || 'Light Amber',
    aroma: aroma || 'Floral nectar',
    taste: taste || 'Rich, clean, authentic honey flavor',
    purityTestResult: purityTestResult || '99.9% Natural Honey',
    adulterationTestResult: adulterationTestResult || 'PASSED',
    microbialTestResult: microbialTestResult || 'SAFE',
    qualityGrade,
    inspectionResult,
    certificateNumber: certNumber,
    remarks: remarks || '',
    blockchainTxId: txId,
    createdAt: new Date().toISOString()
  };

  db.addInspectionRecord(newInspection);

  // 3. Update Batch Status & Grade
  const newStatus = inspectionResult === 'PASSED' ? 'INSPECTED_PASSED' : 'INSPECTED_FAILED';
  db.updateBatch(batchId, {
    status: newStatus,
    qualityGrade
  });

  // 4. Audit Log
  db.logAudit({
    userId: req.user!.id,
    userName: inspectorName,
    role: 'QUALITY_INSPECTOR',
    action: 'QUALITY_INSPECTION',
    entityType: 'INSPECTION_RECORD',
    entityId: inspId,
    details: `Inspection on batch ${batchId}: Result=${inspectionResult}, Grade=${qualityGrade}, Certificate=${certNumber}. Block #${newBlock.index}`
  });

  // 5. Notification & Broadcast
  pushNotification({
    title: `Quality Inspection ${inspectionResult}: Grade ${qualityGrade}`,
    message: `Batch ${batchId} tested by ${inspectorName}. Certified ${inspectionResult} with Grade ${qualityGrade}. Certificate: ${certNumber}`,
    type: 'INSPECTION_UPDATE',
    batchId
  });

  broadcastRealtime({
    type: 'BLOCKCHAIN_UPDATED',
    payload: { block: newBlock, transaction: tx }
  });

  res.status(201).json({
    inspectionRecord: newInspection,
    blockchainBlock: newBlock
  });
});

// ==========================================
// PACKAGING & PRODUCT MODULE
// ==========================================

// Get All Products
app.get('/api/products', (req: Request, res: Response) => {
  res.json(db.getProducts());
});

// Package Passed Batch into Product & Generate QR Code
app.post('/api/products', authenticateToken, requireRoles(['ADMIN', 'PROCESSOR']), async (req: AuthRequest, res: Response) => {
  try {
    const {
      batchId,
      productName,
      brandName,
      netQuantityGrams,
      totalUnits,
      packagingDate,
      expiryDate,
      packageType,
      mrp
    } = req.body;

    if (!batchId || !productName || !brandName) {
      return res.status(400).json({ error: 'Missing required product packaging fields' });
    }

    const batch = db.getBatches().find(b => b.id === batchId);
    if (!batch) {
      return res.status(404).json({ error: 'Batch not found' });
    }

    // Check if batch passed inspection
    if (batch.status !== 'INSPECTED_PASSED' && batch.status !== 'PROCESSED') {
      return res.status(400).json({ error: 'Batch must be inspected and passed before packaging' });
    }

    // Generate unique Product ID & Tracking ID
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const productId = `HC-PROD-${randomSuffix}`;
    const trackingId = `HC-TRK-${Math.floor(10000 + Math.random() * 90000)}`;
    const txId = `HC-TX-PACK-${Date.now().toString().slice(-5)}`;

    // Generate Public Verification QR Code
    // The QR code contains a direct URL to verify the product
    const appBaseUrl = process.env.APP_URL || `http://localhost:${PORT}`;
    const verificationUrl = `${appBaseUrl}/verify/${productId}`;
    const qrCodeDataUrl = await QRCode.toDataURL(verificationUrl, {
      errorCorrectionLevel: 'H',
      margin: 2,
      width: 400,
      color: {
        dark: '#78350F', // Warm amber-brown
        light: '#FFFBEB'  // Honey cream
      }
    });

    const harvUser = db.getUsers().find(u => u.id === batch.beekeeperId);

    // 1. Commit Blockchain Transaction
    const tx: BlockchainTransaction = {
      id: txId,
      batchId,
      productId,
      trackingId,
      action: 'PRODUCT_PACKAGED',
      actor: {
        id: req.user!.id,
        name: req.user!.name,
        role: req.user!.role,
        organization: 'Honey Chain Packaging & Authentication Hub'
      },
      timestamp: new Date().toISOString(),
      data: {
        productId,
        trackingId,
        batchId,
        productName,
        brandName,
        netQuantityGrams: parseInt(netQuantityGrams || 500, 10),
        totalUnits: parseInt(totalUnits || 100, 10),
        packagingDate: packagingDate || new Date().toISOString().slice(0, 10),
        expiryDate: expiryDate || '2028-12-31',
        packageType: packageType || 'Hexagonal Glass Jar with Dipper',
        mrp: parseFloat(mrp || 29.99),
        qualityGrade: batch.qualityGrade || 'A',
        harvesterName: batch.beekeeperName,
        harvesterGiVerified: batch.giTagVerified || false,
        verificationUrl
      },
      dataHash: db.blockchainEngine.calculateDataHash({
        productId,
        trackingId,
        batchId,
        mrp
      })
    };

    const newBlock = db.blockchainEngine.addBlock(tx);

    // 2. Save Product
    const newProduct: Product = {
      id: productId,
      batchId,
      trackingId,
      productName,
      honeyType: batch.honeyType,
      floralSource: batch.floralSource,
      brandName,
      netQuantityGrams: parseInt(netQuantityGrams || 500, 10),
      totalUnits: parseInt(totalUnits || 100, 10),
      packagingDate: packagingDate || new Date().toISOString().slice(0, 10),
      expiryDate: expiryDate || '2028-12-31',
      packageType: packageType || 'Hexagonal Glass Jar with Dipper',
      mrp: parseFloat(mrp || 29.99),
      qualityGrade: batch.qualityGrade || 'A',
      qrCodeUrl: qrCodeDataUrl,
      harvesterName: batch.beekeeperName,
      harvesterGiVerified: batch.giTagVerified || false,
      apiaryLocation: batch.location,
      status: 'IN_STOCK',
      blockchainTxId: txId,
      createdAt: new Date().toISOString()
    };

    db.addProduct(newProduct);

    // 3. Update Batch
    db.updateBatch(batchId, { status: 'PACKAGED' });

    // 4. Create Initial Logistics Record for this tracking ID
    const distRecord: DistributionRecord = {
      id: `HC-DIST-${randomSuffix}`,
      batchId,
      productId,
      trackingId,
      distributorId: '',
      distributorName: 'Pending Dispatch Assignment',
      carrierName: 'Honey Chain Logistics Network',
      sourceLocation: batch.location,
      sourceCoords: [batch.latitude, batch.longitude],
      destinationLocation: 'Global Central Distribution Network',
      destinationCoords: [37.7749, -122.4194],
      transportMethod: 'Climate-Controlled Cold Chain',
      dispatchDate: new Date().toISOString().slice(0, 10),
      expectedDeliveryDate: new Date(Date.now() + 5 * 86400000).toISOString().slice(0, 10),
      storageTemperature: 18.0,
      quantityUnits: newProduct.totalUnits,
      transportStatus: 'PREPARING',
      notes: 'Packaged and waiting for logistics pickup.',
      checkpoints: [
        {
          id: `CP-INIT-${randomSuffix}`,
          timestamp: new Date().toISOString(),
          location: `${brandName} Packaging Facility (${batch.location})`,
          coordinates: [batch.latitude, batch.longitude],
          status: 'PACKAGED_AND_SEALED',
          note: `Sealed in tamper-evident packaging. QR Code & Tracking ID ${trackingId} assigned.`,
          temperature: 18.0
        }
      ],
      blockchainTxId: txId,
      createdAt: new Date().toISOString()
    };
    db.addDistributionRecord(distRecord);

    // 5. Audit Log
    db.logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      role: req.user!.role,
      action: 'PACKAGING_CREATION',
      entityType: 'PRODUCT',
      entityId: productId,
      details: `Created product ${productName} (Track ID: ${trackingId}) from batch ${batchId}. Block #${newBlock.index}`
    });

    // 6. Notification & Broadcast
    pushNotification({
      title: 'Honey Product Packaged & QR Minted',
      message: `${productName} (${newProduct.totalUnits} units) packaged. Tracking ID: ${trackingId}. QR Code ready for customer scanning.`,
      type: 'PRODUCT_PACKAGED',
      batchId,
      productId,
      trackingId
    });

    broadcastRealtime({
      type: 'BLOCKCHAIN_UPDATED',
      payload: { block: newBlock, transaction: tx }
    });

    res.status(201).json({
      product: newProduct,
      trackingId,
      blockchainBlock: newBlock
    });
  } catch (err: any) {
    console.error('Packaging error:', err);
    res.status(500).json({ error: 'Failed to package product: ' + err.message });
  }
});

// ==========================================
// DISTRIBUTION & TRACKING MODULE
// ==========================================

// Get All Distribution Records
app.get('/api/distribution', (req: Request, res: Response) => {
  res.json(db.getDistributionRecords());
});

// Live Tracking Lookup by Track ID or Product ID
app.get('/api/distribution/track/:trackId', (req: Request, res: Response) => {
  const { trackId } = req.params;
  const dist = db.getDistributionRecords().find(d =>
    d.trackingId.toLowerCase() === trackId.toLowerCase() ||
    d.productId.toLowerCase() === trackId.toLowerCase()
  );

  if (!dist) {
    return res.status(404).json({ error: 'Tracking record not found' });
  }

  const product = db.getProducts().find(p => p.id === dist.productId || p.trackingId === dist.trackingId);
  const batch = db.getBatches().find(b => b.id === dist.batchId);
  const blocks = db.blockchainEngine.getBlocksForTracking(dist.trackingId);

  res.json({
    distribution: dist,
    product,
    batch,
    blockchainBlocks: blocks
  });
});

// Distributor: Update Logistics / Add Checkpoint
app.post('/api/distribution/update', authenticateToken, requireRoles(['ADMIN', 'DISTRIBUTOR']), (req: AuthRequest, res: Response) => {
  const {
    trackingId,
    distributorName,
    carrierName,
    sourceLocation,
    destinationLocation,
    transportMethod,
    transportStatus,
    storageTemperature,
    checkpointLocation,
    checkpointLat,
    checkpointLng,
    checkpointNote,
    actualDeliveryDate
  } = req.body;

  if (!trackingId || !transportStatus) {
    return res.status(400).json({ error: 'Tracking ID and status are required' });
  }

  const dist = db.getDistributionRecords().find(d => d.trackingId === trackingId);
  if (!dist) {
    return res.status(404).json({ error: 'Distribution record not found' });
  }

  const distributorUser = db.getUsers().find(u => u.id === req.user!.id);
  const dName = distributorName || distributorUser?.name || req.user!.name;

  const txId = `HC-TX-DIST-${Date.now().toString().slice(-5)}`;

  // Construct new checkpoint if provided
  const newCheckpoints = [...dist.checkpoints];
  if (checkpointLocation && checkpointLat && checkpointLng) {
    const cp: Checkpoint = {
      id: `CP-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString(),
      location: checkpointLocation,
      coordinates: [parseFloat(checkpointLat), parseFloat(checkpointLng)],
      status: transportStatus,
      note: checkpointNote || `Logistics status updated to ${transportStatus}`,
      temperature: storageTemperature ? parseFloat(storageTemperature) : dist.storageTemperature
    };
    newCheckpoints.push(cp);
  }

  // 1. Commit Blockchain Transaction
  const tx: BlockchainTransaction = {
    id: txId,
    batchId: dist.batchId,
    productId: dist.productId,
    trackingId: dist.trackingId,
    action: transportStatus === 'DELIVERED' ? 'DELIVERY_COMPLETED' : 'DISTRIBUTION_DISPATCHED',
    actor: {
      id: req.user!.id,
      name: dName,
      role: 'DISTRIBUTOR',
      organization: distributorUser?.organization || carrierName || 'Cold-Chain Global Logistics'
    },
    timestamp: new Date().toISOString(),
    data: {
      trackingId,
      distributorName: dName,
      carrierName: carrierName || dist.carrierName,
      transportStatus,
      storageTemperatureC: storageTemperature ? parseFloat(storageTemperature) : dist.storageTemperature,
      latestCheckpoint: checkpointLocation || dist.checkpoints[dist.checkpoints.length - 1]?.location,
      actualDeliveryDate: actualDeliveryDate || (transportStatus === 'DELIVERED' ? new Date().toISOString().slice(0, 10) : undefined)
    },
    dataHash: db.blockchainEngine.calculateDataHash({
      trackingId,
      transportStatus,
      time: new Date().toISOString()
    })
  };

  const newBlock = db.blockchainEngine.addBlock(tx);

  // 2. Update Distribution Record
  const updates: Partial<DistributionRecord> = {
    distributorId: req.user!.id,
    distributorName: dName,
    carrierName: carrierName || dist.carrierName,
    transportStatus,
    checkpoints: newCheckpoints,
    blockchainTxId: txId
  };

  if (sourceLocation) updates.sourceLocation = sourceLocation;
  if (destinationLocation) updates.destinationLocation = destinationLocation;
  if (transportMethod) updates.transportMethod = transportMethod;
  if (storageTemperature) updates.storageTemperature = parseFloat(storageTemperature);
  if (actualDeliveryDate || transportStatus === 'DELIVERED') {
    updates.actualDeliveryDate = actualDeliveryDate || new Date().toISOString().slice(0, 10);
  }

  const updatedDist = db.updateDistributionRecord(dist.id, updates);

  // If delivered, update product status as well
  if (transportStatus === 'DELIVERED') {
    db.updateProduct(dist.productId, { status: 'DELIVERED' });
    db.updateBatch(dist.batchId, { status: 'COMPLETED' });
  } else if (transportStatus === 'IN_TRANSIT') {
    db.updateProduct(dist.productId, { status: 'SHIPPED' });
  }

  // 3. Audit Log
  db.logAudit({
    userId: req.user!.id,
    userName: dName,
    role: 'DISTRIBUTOR',
    action: transportStatus === 'DELIVERED' ? 'SHIPMENT_DELIVERED' : 'LOGISTICS_UPDATE',
    entityType: 'DISTRIBUTION_RECORD',
    entityId: dist.id,
    details: `Tracking ${trackingId} updated to ${transportStatus}. Checkpoint: ${checkpointLocation || 'Waypoint logged'}. Block #${newBlock.index}`
  });

  // 4. Notification & Broadcast
  pushNotification({
    title: transportStatus === 'DELIVERED' ? 'Shipment Delivered Successfully 🎉' : `Shipment Status: ${transportStatus}`,
    message: `Tracking ID ${trackingId} is now ${transportStatus}. Location: ${checkpointLocation || dist.destinationLocation}`,
    type: 'DISTRIBUTION_UPDATE',
    batchId: dist.batchId,
    productId: dist.productId,
    trackingId: dist.trackingId
  });

  broadcastRealtime({
    type: 'BLOCKCHAIN_UPDATED',
    payload: { block: newBlock, transaction: tx }
  });

  broadcastRealtime({
    type: 'TRACKING_UPDATED',
    payload: updatedDist
  });

  res.json({
    distribution: updatedDist,
    blockchainBlock: newBlock
  });
});

// ==========================================
// PUBLIC QR VERIFICATION & PROVENANCE ENDPOINT
// ==========================================

// Public Traceability & Authenticity Engine
app.get('/api/verify/:code', async (req: Request, res: Response) => {
  const { code } = req.params;
  const cleanCode = code.trim();

  // Search product by ID, tracking ID, or batch ID
  const product = db.getProducts().find(p =>
    p.id.toLowerCase() === cleanCode.toLowerCase() ||
    p.trackingId.toLowerCase() === cleanCode.toLowerCase() ||
    p.batchId.toLowerCase() === cleanCode.toLowerCase()
  );

  let batch: HoneyBatch | undefined;
  if (product) {
    batch = db.getBatches().find(b => b.id === product.batchId);
  } else {
    // If no direct product match, search batch
    batch = db.getBatches().find(b => b.id.toLowerCase() === cleanCode.toLowerCase());
  }

  if (!batch && !product) {
    return res.status(404).json({
      error: 'Product or batch not found',
      message: 'No cryptographic record matches the scanned code or ID.'
    });
  }

  const batchId = batch?.id || product?.batchId || '';
  const resolvedBatch = batch || db.getBatches().find(b => b.id === batchId);

  // Gather complete lifecycle records
  const beekeeperUser = resolvedBatch ? db.getUsers().find(u => u.id === resolvedBatch.beekeeperId) : null;
  const giCert = resolvedBatch?.hasGiTag ? db.getGiCertificates().find(c => c.beekeeperId === resolvedBatch?.beekeeperId) : null;
  const processingRecords = db.getProcessingRecords().filter(p => p.batchId === batchId);
  const inspectionRecords = db.getInspectionRecords().filter(i => i.batchId === batchId);
  const distRecord = product ? db.getDistributionRecords().find(d => d.productId === product.id || d.trackingId === product.trackingId) : null;

  // Blockchain Provenance
  const blockchainBlocks = db.blockchainEngine.chain.filter(b =>
    b.transaction.batchId === batchId ||
    (product && (b.transaction.productId === product.id || b.transaction.trackingId === product.trackingId))
  );

  // Verify blockchain integrity for this specific lineage
  const chainAudit = db.blockchainEngine.verifyChain();

  res.json({
    verified: true,
    authenticityScore: 100,
    product: product || null,
    batch: resolvedBatch || null,
    harvester: beekeeperUser ? {
      name: beekeeperUser.name,
      organization: beekeeperUser.organization,
      location: beekeeperUser.location,
      hasGiTag: beekeeperUser.hasGiTag,
      giTagVerified: beekeeperUser.giTagVerified,
      giTagName: beekeeperUser.giTagName,
      giTagNumber: beekeeperUser.giTagNumber,
      giCertificate: giCert || null
    } : null,
    processing: processingRecords,
    inspection: inspectionRecords,
    distribution: distRecord || null,
    blockchain: {
      blocks: blockchainBlocks,
      totalBlocksInChain: db.blockchainEngine.chain.length,
      isChainIntact: chainAudit.isValid,
      hashAlgorithm: 'SHA-256 (NIST FIPS 180-4)'
    }
  });
});

// ==========================================
// BLOCKCHAIN EXPLORER & AUDIT LEDGER
// ==========================================

// Get entire ledger
app.get('/api/blockchain/ledger', (req: Request, res: Response) => {
  res.json({
    chain: db.blockchainEngine.chain,
    length: db.blockchainEngine.chain.length,
    latestBlock: db.blockchainEngine.chain[db.blockchainEngine.chain.length - 1]
  });
});

// Cryptographic Ledger Verification
app.get('/api/blockchain/verify', (req: Request, res: Response) => {
  const audit = db.blockchainEngine.verifyChain();
  res.json(audit);
});

// ==========================================
// NOTIFICATIONS API
// ==========================================

app.get('/api/notifications', (req: Request, res: Response) => {
  const notifs = db.getNotifications();
  res.json(notifs);
});

app.patch('/api/notifications/:id/read', (req: Request, res: Response) => {
  const { id } = req.params;
  const success = db.markNotificationAsRead(id);
  res.json({ success });
});

app.post('/api/notifications/read-all', (req: Request, res: Response) => {
  db.markAllNotificationsAsRead();
  res.json({ success: true });
});

// ==========================================
// ADMIN DASHBOARD & ANALYTICS METRICS
// ==========================================

app.get('/api/stats/dashboard', (req: Request, res: Response) => {
  const users = db.getUsers();
  const batches = db.getBatches();
  const products = db.getProducts();
  const inspections = db.getInspectionRecords();
  const distribution = db.getDistributionRecords();
  const blocks = db.blockchainEngine.chain;

  const totalUsers = users.length;
  const totalBeekeepers = users.filter(u => u.role === 'BEEKEEPER').length;
  const totalBatches = batches.length;
  const totalProducts = products.length;
  const totalTransactions = blocks.length; // 1 transaction per block in this engine
  const pendingInspections = batches.filter(b => b.status === 'PROCESSED' || b.status === 'HARVESTED').length;
  const deliveredBatches = distribution.filter(d => d.transportStatus === 'DELIVERED').length;
  const verifiedProducts = products.length;

  // Monthly honey production (kg) aggregation
  const monthsMap: Record<string, number> = {
    'Nov 2025': 420,
    'Dec 2025': 380,
    'Jan 2026': 550,
    'Feb 2026': 850,
    'Mar 2026': 280
  };

  batches.forEach(b => {
    if (b.harvestDate) {
      const d = new Date(b.harvestDate);
      const key = d.toLocaleString('en-US', { month: 'short', year: 'numeric' });
      monthsMap[key] = (monthsMap[key] || 0) + b.quantity;
    }
  });

  const monthlyProduction = Object.entries(monthsMap).map(([month, quantityKg]) => ({
    month,
    quantityKg: Math.round(quantityKg)
  }));

  // Batches by Status
  const statusMap: Record<string, number> = {};
  batches.forEach(b => {
    statusMap[b.status] = (statusMap[b.status] || 0) + 1;
  });
  const batchesByStatus = Object.entries(statusMap).map(([status, count]) => ({ status, count }));

  // Production by Location & Floral Source
  const floralMap: Record<string, number> = {};
  batches.forEach(b => {
    floralMap[b.honeyType] = (floralMap[b.honeyType] || 0) + b.quantity;
  });
  const productionByHoneyType = Object.entries(floralMap).map(([honeyType, quantityKg]) => ({
    honeyType,
    quantityKg
  }));

  // Quality Inspection Results
  const inspectionResults = {
    passed: inspections.filter(i => i.inspectionResult === 'PASSED').length,
    failed: inspections.filter(i => i.inspectionResult === 'FAILED').length,
    gradeA: inspections.filter(i => i.qualityGrade === 'A').length,
    gradeB: inspections.filter(i => i.qualityGrade === 'B').length,
    gradeC: inspections.filter(i => i.qualityGrade === 'C').length
  };

  res.json({
    metrics: {
      totalUsers,
      totalBeekeepers,
      totalBatches,
      totalProducts,
      totalBlockchainTransactions: totalTransactions,
      pendingQualityInspections: pendingInspections,
      deliveredBatches,
      verifiedProducts
    },
    charts: {
      monthlyProduction,
      batchesByStatus,
      productionByHoneyType,
      inspectionResults
    }
  });
});

// Audit Logs
app.get('/api/audit-logs', authenticateToken, requireRoles(['ADMIN']), (req: AuthRequest, res: Response) => {
  res.json(db.getAuditLogs());
});

// ==========================================
// VITE MIDDLEWARE & SPA FALLBACK
// ==========================================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    app.use(express.static(path.resolve(process.cwd(), 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(process.cwd(), 'dist', 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`🍯 HONEY CHAIN server running on http://0.0.0.0:${PORT}`);
    console.log(`📡 WebSocket server running on ws://0.0.0.0:${PORT}/ws`);
    console.log(`⛓️ Blockchain Genesis block hash: ${db.blockchainEngine.chain[0]?.hash.substring(0, 16)}...`);
  });
}

startServer();
